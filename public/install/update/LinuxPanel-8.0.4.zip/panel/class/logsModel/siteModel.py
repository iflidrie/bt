# coding: utf-8
# -------------------------------------------------------------------
# 宝塔Linux面板
# -------------------------------------------------------------------
# Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# -------------------------------------------------------------------
# Author: cjxin <bt_ahong@qq.com>
# -------------------------------------------------------------------

# ------------------------------
# 面板日志类
# ------------------------------

import os, re, json, time
import traceback
from datetime import datetime, timedelta
from logsModel.base import logsBase
import public, db
from html import unescape, escape


class main(logsBase):

    def __init__(self):
        self.serverType = public.get_webserver()

    def __get_iis_log_files(self, path):
        """
        @name 获取IIS日志文件列表
        @param path 日志文件路径
        @return list
        """
        file_list = []
        if os.path.exists(path):
            for filename in os.listdir(path):
                if filename.find('.log') == -1: continue
                file_list.append('{}/{}'.format(path, filename))

        file_list = sorted(file_list, reverse=False)
        return file_list

    def get_iis_logs(self, get):
        """
        @name 获取IIS网站日志
        """

        p, limit, search = 1, 2000, ''
        if 'p' in get: limit = int(get.p)
        if 'limit' in get: limit = int(get.limit)
        if 'search' in get: search = get.search

        import panelSite
        site_obj = panelSite.panelSite()
        data = site_obj.get_site_info(get.siteName)
        if not data:
            return public.returnMsg(False, '【{}】网站路径获取失败，请检查IIS是否存在此站点，如IIS不存在请通过面板删除此网站后重新创建.'.format(get.siteName))

        log_path = '{}/wwwlogs/W3SVC{}'.format(public.get_soft_path(), data['id'])
        file_list = self.__get_iis_log_files(log_path)

        find_idx = 0
        log_list = []
        for log_path in file_list:
            if not os.path.exists(log_path):  continue
            if len(log_list) >= limit: break

            p_num = 0  # 分页计数器
            next_file = False
            while not next_file:
                if len(log_list) >= limit:
                    break
                p_num += 1
                result = self.GetNumLines(log_path, 10001, p_num).split('\r\n')
                if len(result) < 10000:
                    next_file = True

                for _line in result:
                    if not _line: continue
                    if len(log_list) >= limit:
                        break

                    try:
                        if self.find_line_str(_line, search):
                            find_idx += 1
                            if find_idx > (p - 1) * limit:
                                info = escape(_line)
                                log_list.append(info)
                    except:
                        pass
        return log_list

    # 取网站日志
    def get_site_logs(self, get):
        logPath = ''
        if self.serverType == 'iis':
            return self.get_iis_logs(get)

        elif self.serverType == 'apache':
            logPath = self.setupPath + '/wwwlogs/' + get.siteName + '-access.log'
        else:
            logPath = self.setupPath + '/wwwlogs/' + get.siteName + '.log'

        data = {}
        data['path'] = ''
        data['path'] = os.path.dirname(logPath)
        if os.path.exists(logPath):
            data['status'] = True
            data['msg'] = public.GetNumLines(logPath, 1000)
            return data
        data['status'] = False
        data['msg'] = '日志为空'
        return data

    # 取网站日志
    def get_site_access_logs(self, get):
        try:
            logsPath = '/www/wwwlogs/'
            res = public.M('sites').where('name=?', (get.siteName,)).select()[0]['project_type'].lower()
            if res == 'php':
                res = ''
            else:
                res = res + '_'

            serverType = public.get_webserver()
            if serverType == "nginx":
                config_path = '/www/server/panel/vhost/nginx/{}.conf'.format(res + get.siteName)
                config = public.readFile(config_path)
                if not config:
                    print('|-正在处理网站:未检测到{}站点的日志'.format(get.siteName))
                    return
                log_file = self.nginx_get_log_file_path(config, get.siteName, is_error_log=False)
            elif serverType == 'apache':
                config_path = '/www/server/panel/vhost/apache/{}.conf'.format(res + get.siteName)
                config = public.readFile(config_path)
                if not config:
                    print('|-正在处理网站:未检测到{}站点的日志'.format(get.siteName))
                    return
                log_file = self.apache_get_log_file_path(config, get.siteName, is_error_log=False)
            else:
                log_file = self.open_ols_log_file_path(get.siteName, is_error_log=False)

            if log_file is None:
                return public.returnMsg(False, '日志为空')
            logs = public.GetNumLines(log_file, 1000)
            # 时间查找和关键字查找
            if not hasattr(get, 'time_search') or get.time_search == '[]':
                time_search = []
                start_time = 0
                import time
                end_time = int(time.time())
            else:
                time_search = json.loads(get.time_search)
                start_time = int(time_search[0])
                end_time = int(time_search[1])
            print(end_time, start_time)
            search = get.get('search', '')
            if serverType == "nginx" or serverType == 'apache':
                if time_search or search:
                    s_logs = []
                    logs = logs.strip().split('\n')
                    for log in logs:
                        is_time_search = True
                        is_search = True
                        if time_search:
                            try:
                                time = datetime.strptime(re.findall('\[(.*?)\]', log)[0].split(' ')[0], '%d/%b/%Y:%H:%M:%S').timestamp()
                            except:
                                time = 0
                            if time != 0 and not (start_time < time < end_time):
                                is_time_search = False
                        if search:
                            if search not in log:
                                is_search = False
                        if is_time_search and is_search:
                            s_logs.append(log)
                    logs = '\n'.join(s_logs)
            return public.returnMsg(True, public.xsssec(logs))
        except:
            return traceback.format_exc()

    # 取网站错误日志
    def get_site_error_logs(self, get):
        try:
            logsPath = '/www/wwwlogs/'
            res = public.M('sites').where('name=?', (get.siteName,)).select()[0]['project_type'].lower()
            if res == 'php':
                res = ''
            else:
                res = res + '_'
            serverType = public.get_webserver()
            if serverType == "nginx":
                config_path = '/www/server/panel/vhost/nginx/{}.conf'.format(res + get.siteName)
                config = public.readFile(config_path)
                if not config:
                    print('|-正在处理网站:未检测到{}站点的日志'.format(get.siteName))
                    return
                log_file = self.nginx_get_log_file_path(config, get.siteName, is_error_log=True)
            elif serverType == 'apache':
                config_path = '/www/server/panel/vhost/apache/{}.conf'.format(res + get.siteName)
                config = public.readFile(config_path)
                if not config:
                    print('|-正在处理网站:未检测到{}站点的日志'.format(get.siteName))
                    return
                log_file = self.apache_get_log_file_path(config, get.siteName, is_error_log=True)
            else:
                log_file = self.open_ols_log_file_path(get.siteName, is_error_log=True)

            if log_file is None:
                return public.returnMsg(False, '日志为空')
            logs = public.GetNumLines(log_file, 1000)
            # 时间查找和关键字查找
            if not hasattr(get, 'time_search') or get.time_search == '[]':
                time_search = []
                start_time = 0
                import time
                end_time = time.time()
            else:
                time_search = json.loads(get.time_search)
                start_time = int(time_search[0])
                end_time = int(time_search[1])
            search = get.get('search', '')
            if serverType == "nginx":
                if time_search or search:
                    s_logs = []
                    logs = logs.strip().split('\n')
                    for log in logs:
                        is_time_search = True
                        is_search = True
                        if time_search:
                            try:
                                time = datetime.strptime(' '.join(log.split(' ')[0:2]), '%Y/%m/%d %H:%M:%S').timestamp()
                            except:
                                print(traceback.format_exc())
                                time = 0
                            if time != 0 and not (start_time < time < end_time):
                                is_time_search = False
                        if search:
                            if search not in log:
                                is_search = False
                        if is_time_search and is_search:
                            s_logs.append(log)
                    logs = '\n'.join(s_logs)
            elif serverType == 'apache':
                if time_search or search:
                    s_logs = []
                    logs = logs.strip().split('\n')
                    for log in logs:
                        is_time_search = True
                        is_search = True
                        if time_search:
                            try:
                                time = datetime.strptime(re.findall('\[(.*?)\]', log)[0], '%a %b %d %H:%M:%S.%f %Y').timestamp()
                            except:
                                time = 0
                            if time != 0 and start_time < time < end_time:
                                is_time_search = False
                        if search:
                            if search not in log:
                                is_search = False
                        if is_time_search and is_search:
                            s_logs.append(log)
                    logs = '\n'.join(s_logs)
            return public.returnMsg(True, public.xsssec(logs))
        except:
            return traceback.format_exc()

    def download_logs(self, get):
        try:
            if not (hasattr(get, 'siteName') and hasattr(get, 'logType') and hasattr(get, 'time_search')):
                return public.returnMsg(False, '参数错误！')
            siteName = get.siteName
            logType = get.logType
            if logType == 'access':
                data = self.get_site_access_logs(get)
                if data['status']:
                    path = '/tmp/{}-access.log'.format(siteName)
                    public.writeFile(path, data['msg'])
                    return public.returnMsg(True, path)
                else:
                    return public.returnMsg(False, '导出日志失败！')
            elif logType == 'error':
                data = self.get_site_error_logs(get)
                if data['status']:
                    path = '/tmp/{}-error.log'.format(siteName)
                    public.writeFile(path, data['msg'])
                    return public.returnMsg(True, path)
                else:
                    return public.returnMsg(False, '导出日志失败！')
            return public.returnMsg(False, '类型参数错误！')
        except:
            return public.returnMsg(False, traceback.format_exc())

    def clear_logs(self, get):
        try:
            logsPath = '/www/wwwlogs/'
            res = public.M('sites').where('name=?', (get.siteName,)).select()[0]['project_type'].lower()
            if res == 'php':
                res = ''
            else:
                res = res + '_'
            serverType = public.get_webserver()
            if serverType == "nginx":
                config_path = '/www/server/panel/vhost/nginx/{}.conf'.format(res + get.siteName)
                config = public.readFile(config_path)
                if not config:
                    print('|-正在处理网站:未检测到{}站点的日志'.format(get.siteName))
                    return
                error_log_file = self.nginx_get_log_file_path(config, get.siteName, is_error_log=True)
                access_log_file = self.nginx_get_log_file_path(config, get.siteName, is_error_log=False)
            elif serverType == 'apache':
                config_path = '/www/server/panel/vhost/apache/{}.conf'.format(res + get.siteName)
                config = public.readFile(config_path)
                if not config:
                    print('|-正在处理网站:未检测到{}站点的日志'.format(get.siteName))
                    return
                error_log_file = self.apache_get_log_file_path(config, get.siteName, is_error_log=True)
                access_log_file = self.apache_get_log_file_path(config, get.siteName, is_error_log=False)
            else:
                error_log_file = self.open_ols_log_file_path(get.siteName, is_error_log=True)
                access_log_file = self.open_ols_log_file_path(get.siteName, is_error_log=False)
            if not (hasattr(get, 'siteName') and hasattr(get, 'logType') and hasattr(get, 'time_search')):
                return public.returnMsg(False, '参数错误！')

            logType = get.logType
            if logType == 'access':
                data = self.get_site_access_logs(get)
                if data['status']:
                    if hasattr(get, 'time_search') and get.time_search != '[]':
                        public.writeFile(access_log_file, data['msg'])
                        return public.returnMsg(True, '清理成功！')
                    else:
                        public.writeFile(access_log_file, '')
                        return public.returnMsg(True, '清理成功！')
            elif logType == 'error':
                data = self.get_site_error_logs(get)
                if data['status']:
                    if hasattr(get, 'time_search') and get.time_search != '[]':
                        public.writeFile(error_log_file, data['msg'])
                        return public.returnMsg(True, '清理成功！')
                    else:
                        public.writeFile(error_log_file, '')
                        return public.returnMsg(True, '清理成功！')
            return public.returnMsg(False, '清理失败！')
        except:
            return public.returnMsg(False, traceback.format_exc())

    def get_site_list(self, get):
        data = public.M('sites').select()
        return data

    @staticmethod
    def nginx_get_log_file_path(nginx_config: str, site_name: str, is_error_log: bool = False):
        log_file = None
        if is_error_log:
            re_data = re.findall(r"error_log +(/(\S+/?)+) ?(.*?);", nginx_config)
        else:
            re_data = re.findall(r"access_log +(/(\S+/?)+) ?(.*?);", nginx_config)
        if re_data is None:
            log_file = None
        else:
            for i in re_data:
                file_path = i[0].strip(";")
                if log_file != "/dev/null":
                    if os.path.isfile(file_path):
                        log_file = file_path
                        break

        logsPath = '/www/wwwlogs/'
        if log_file is None:
            if is_error_log:
                log_file = logsPath + site_name + '.log'
            else:
                log_file = logsPath + site_name + '.error.log'
            if not os.path.isfile(log_file):
                log_file = None

        return log_file

    @staticmethod
    def apache_get_log_file_path(apache_config: str, site_name: str, is_error_log: bool = False):
        log_file = None
        if is_error_log:
            re_data = re.findall(r'''ErrorLog +['"]?(/(\S+/?)+)['"]? ?(.*?)\n''', apache_config)
        else:
            re_data = re.findall(r'''CustomLog +['"]?(/(\S+/?)+)['"]? ?(.*?)\n''', apache_config)
        if re_data is None:
            log_file = None
        else:
            for i in re_data:
                file_path = i[0].strip('"').strip("'")
                if log_file != "/dev/null":
                    if os.path.isfile(file_path):
                        log_file = file_path
                        break

        logsPath = '/www/wwwlogs/'
        if log_file is None:
            if is_error_log:
                log_file = logsPath + site_name + '-access_log'
            else:
                log_file = logsPath + site_name + '-error_log'
            if not os.path.isfile(log_file):
                log_file = None

        return log_file

    @staticmethod
    def open_ols_log_file_path(site_name: str, is_error_log: bool = False):
        if not is_error_log:
            return '/www/wwwlogs/' + site_name + '_ols.access_log'
        else:
            return '/www/wwwlogs/' + site_name + '_ols.error_log'
