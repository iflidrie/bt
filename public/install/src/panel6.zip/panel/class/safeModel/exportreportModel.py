# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: lwh <2023-07-24>
# +-------------------------------------------------------------------
import datetime, os, json, sys
from safeModel.base import safeBase
os.chdir("/www/server/panel")
sys.path.append("class/")
import os, public, config, time
try:
    from docxtpl import DocxTemplate
    from docxtpl import RichText
except:
    public.ExecShell("btpip install docxtpl")
    time.sleep(2)
    from docxtpl import DocxTemplate
    from docxtpl import RichText


class main(safeBase):
    __path = '/www/server/panel/data/warning_report'
    __img = __path + '/img'
    __tpl = '/www/server/panel/class/safeModel/tpl.docx'
    __data = __path + '/data.json'
    all_cve = 0
    cve_num = 0
    high_cve = 0
    mid_cve = 0
    low_cve = 0
    cve_list = []
    high_warn = 0
    mid_warn = 0
    low_warn = 0
    high_warn_list = []
    mid_warn_list = []
    low_warn_list = []
    final_obj = {}

    def __init__(self):
        self.configs = config.config()
        if not os.path.exists(self.__path):
            os.makedirs(self.__path, 384)

    def get_pdf(self, get):
        public.set_module_logs("exportreport", "get_pdf")
        self.cve_list = []
        self.high_warn_list = []
        self.mid_warn_list = []
        self.low_warn_list = []
        if not os.path.exists(self.__data):
            return public.returnMsg(False, '导出失败，未发现扫描结果')
        tpl = DocxTemplate(self.__tpl)
        data = json.loads(public.readFile(self.__data))
        long_date = data["check_time"]  # 带有时间的检测日期
        self.final_obj["host"] = public.get_hostname()  # 主机名
        self.final_obj["ip"] = public.get_server_ip()  # 外网IP
        self.final_obj["local_ip"] = public.GetLocalIp()  # 内网IP
        date_obj = datetime.datetime.strptime(long_date, "%Y/%m/%d %H:%M:%S")
        self.final_obj["date"] = date_obj.strftime("%Y/%m/%d")
        self.final_obj["last_date"] = (date_obj - datetime.timedelta(days=6)).strftime("%Y/%m/%d")
        self.total(data)
        self.secondPage(date_obj)
        self.thirdPage()
        self.focusPage(data)
        self.lowPage(data)

        tpl.render(self.final_obj)
        tpl.save(self.__path + '/堡塔安全风险检测报告.docx')
        return {"status": True, "msg": "导出成功", "path": self.__path + '/堡塔安全风险检测报告.docx'}

    def total(self, data):
        if os.path.exists("/www/server/panel/data/warning/result.json"):
            with open("/www/server/panel/data/warning/result.json") as f:
                cve_result = json.load(f)
                self.cve_list = cve_result["risk"]
                self.high_cve = cve_result["count"]["serious"]
                self.mid_cve = cve_result["count"]["high_risk"]
                self.low_cve = cve_result["count"]["moderate_risk"]
                self.all_cve = cve_result["vul_count"]
        for d in data["risk"]:
            if "title" in d:
                if d["level"] == 3:
                    self.high_warn += 1
                    self.high_warn_list.append(d)
                elif d["level"] == 2:
                    self.mid_warn += 1
                    self.mid_warn_list.append(d)
                else:
                    self.low_warn += 1.
                    self.low_warn_list.append(d)
        if self.high_warn + self.high_cve > 1:
            total_level = '差'
            level_color = RichText('差', font='Microsoft YaHei', color='ff0000', size=120, bold=True)
        elif self.mid_warn + self.mid_cve > 10 or self.high_warn + self.high_cve == 1:
            total_level = '良'
            level_color = RichText('良', font='Microsoft YaHei', color='6d9eeb', size=120, bold=True)
        else:
            total_level = '优'
            level_color = RichText('优', font='Microsoft YaHei', color='6aa84f', size=120, bold=True)
        self.cve_num = self.high_cve + self.mid_cve + self.low_cve
        level_reason = "服务器未发现较大的安全风险，继续保持！"
        if total_level == "差":
            level_reason = "服务器存在高危安全风险或系统漏洞，可能会导致黑客入侵，请尽快修复！"
        if total_level == "良":
            level_reason = "服务器发现潜在的安全风险，建议尽快修复！"
        warn_level = RichText('优', color='6aa84f', font='微软雅黑', size=34)
        first_warn = ""
        if self.high_warn > 0:
            warn_level = RichText('差', color='ff0000', font='微软雅黑', size=34)
            first_warn = "发现高危安全风险{}个".format(self.high_warn)
        elif self.mid_warn > 5:
            warn_level = RichText('良', color='6d9eeb', font='微软雅黑', size=34)
            first_warn = "发现较多中危安全风险"
        else:
            first_warn = "未发现较大的安全风险"
        cve_level = RichText('优', color='6aa84f', font='微软雅黑', size=34)
        first_cve = ""
        if self.cve_num > 1:
            cve_level = RichText('差', color='ff0000', font='微软雅黑', size=34)
            first_cve = "发现较多系统漏洞{}个".format(self.cve_num)
        elif self.cve_num == 1:
            cve_level = RichText('良', color='6d9eeb', font='微软雅黑', size=34)
            first_cve = "发现少量系统漏洞"
        else:
            first_cve = "未发现存在系统漏洞"
        self.final_obj["level_color"] = level_color
        self.final_obj["total_level"] = total_level
        self.final_obj["level_reason"] = level_reason
        self.final_obj["warn_level"] = warn_level
        self.final_obj["first_warn"] = first_warn
        self.final_obj["cve_level"] = cve_level
        self.final_obj["first_cve"] = first_cve

    def secondPage(self, date_obj):
        with open(self.__path+"/record.json", "r") as f:
            record = json.load(f)
        warn_times = 0
        repair_times = 0
        for r in record["scan"]:
            warn_times += r["times"]
        for r in record["repair"]:
            repair_times += r["times"]
        self.final_obj["warn_times"] = warn_times
        self.final_obj["cve_times"] = warn_times
        self.final_obj["repair_times"] = repair_times
        self.final_obj["last_month"] = (date_obj - datetime.timedelta(days=6)).strftime("%m")
        self.final_obj["last_day"] = (date_obj - datetime.timedelta(days=6)).strftime("%d")
        self.final_obj["month"] = date_obj.strftime("%m")
        self.final_obj["day"] = date_obj.strftime("%d")
        self.final_obj["second_warn"] = "每日登陆面板，例行服务器安全风险检测。"
        if self.cve_num > 0:
            self.final_obj["second_cve"] = "对系统内核版本以及流行应用进行漏洞扫描，发现存在漏洞风险。"
        else:
            self.final_obj["second_cve"] = "对系统内核版本以及流行应用进行漏洞扫描，未发现漏洞风险。"
        self.final_obj["repair"] = "执行一键修复，解决安全问题。"

    def thirdPage(self):
        self.final_obj["warn_num"] = len(self.high_warn_list)
        self.final_obj["cve_num"] = self.cve_num
        self.final_obj["web_num"] = 41
        self.final_obj["sys_num"] = 29
        self.final_obj["cve_num"] = 670
        self.final_obj["kernel_num"] = 550
        self.final_obj["high_cve"] = RichText(str(self.high_cve) + "个", font='Microsoft YaHei', color='ff0000', size=41)
        if self.high_cve == 0:
            self.final_obj["high_cve"] = "未发现"
        self.final_obj["mid_cve"] = RichText(str(self.mid_cve) + "个", font='Microsoft YaHei', color='ff9900', size=41)
        if self.mid_cve == 0:
            self.final_obj["mid_cve"] = "未发现"
        self.final_obj["low_cve"] = RichText(str(self.low_cve) + "个", font='Microsoft YaHei', color='ecec39', size=41)
        if self.low_cve == 0:
            self.final_obj["low_cve"] = "未发现"
        self.final_obj["high_warn"] = RichText(str(self.high_warn) + "个", font='Microsoft YaHei', color='ff0000', size=41)
        if self.high_warn == 0:
            self.final_obj["high_warn"] = "无"
        self.final_obj["mid_warn"] = RichText(str(self.mid_warn) + "个", font='Microsoft YaHei', color='ff9900', size=41)
        if self.mid_warn == 0:
            self.final_obj["mid_warn"] = "无"
        self.final_obj["low_warn"] = RichText(str(int(self.low_warn)) + "个", font='Microsoft YaHei', color='ecec39', size=41)
        if self.low_warn == 0:
            self.final_obj["low_warn"] = "无"

    def focusPage(self, data):
        num = 1  # 序号
        focus_high_list = []
        for hwl in self.high_warn_list:
            focus_high_list.append(
                {
                    "num": str(num),
                    "name": "高危风险\n\n"+str(hwl["msg"]),
                    "ps": str(hwl["ps"]),
                    "tips": '\n'.join(hwl["tips"]),
                    "auto": self.is_autofix(hwl)
                }
            )
            num += 1
        self.final_obj["focus_high_list"] = focus_high_list
        focus_mid_list = []
        for mwl in self.mid_warn_list:
            focus_mid_list.append(
                {
                    "num": num,
                    "name": "中危风险\n\n"+mwl["msg"],
                    "ps": mwl["ps"],
                    "tips": '\n'.join(mwl["tips"]),
                    "auto": self.is_autofix(mwl)
                }
            )
            num += 1
        self.final_obj["focus_mid_list"] = focus_mid_list
        focus_cve_list = []
        for cl in self.cve_list:
            tmp_cve = {
                    "num": num,
                    "name": "高危漏洞\n\n"+cl["cve_id"],
                    "ps": cl["vuln_name"],
                    "tips": "将【{}】版本升级至{}或更高版本。".format('、'.join(cl["soft_name"]), cl["vuln_version"]),
                    "auto": self.is_autofix(cl)
                }
            if cl["level"] == 2:
                tmp_cve["name"] = "中危漏洞\n\n"+cl["cve_id"]
            elif cl["level"] == 1:
                tmp_cve["name"] = "低危漏洞\n\n"+cl["cve_id"]
            focus_cve_list.append(tmp_cve)
            num += 1
        self.final_obj["focus_cve_list"] = focus_cve_list

    def is_autofix(self, warn):
        data = json.loads(public.readFile(self.__data))
        if "title" in warn:
            if warn["m_name"] in data["is_autofix"]:
                return "支持"
            else:
                return "不支持"
        if "cve_id" in warn:
            if list(warn["soft_name"].keys())[0] == "kernel":
                return "不支持"
            else:
                return "支持"

    def lowPage(self, data):
        num = 1  # 序号
        low_warn_list = []
        for lwl in self.low_warn_list:
            low_warn_list.append(
                {
                    "num": str(num),
                    "name": "低危风险\n\n"+str(lwl["msg"]),
                    "ps": str(lwl["ps"]),
                    "tips": '\n'.join(lwl["tips"]),
                    "auto": self.is_autofix(lwl)
                }
            )
            num += 1
        self.final_obj["low_warn_list"] = low_warn_list
        ignore_list = []
        for ig in data["ignore"]:
            if "title" in ig:
                ignore_list.append(
                    {
                        "num": num,
                        "name": "忽略项\n\n"+ig["msg"],
                        "ps": ig["ps"],
                        "tips": '\n'.join(ig["tips"]),
                        "auto": self.is_autofix(ig)
                    }
                )
            elif "cve_id" in ig:
                ignore_list.append(
                    {
                        "num": num,
                        "name": "忽略项\n\n"+ig["cve_id"],
                        "ps": ig["vuln_name"],
                        "tips": "将【{}】版本升级至{}或更高版本。".format('、'.join(ig["soft_name"]), ig["vuln_version"]),
                        "auto": self.is_autofix(ig)
                    }
                )
            num += 1
        self.final_obj["ignore_list"] = ignore_list

