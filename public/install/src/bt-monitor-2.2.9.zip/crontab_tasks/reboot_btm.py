#!/www/server/bt-monitor/pyenv/bin/python3 -u
#  -*- coding: utf-8 -*-

import os, time

os.chdir('/www/server/bt-monitor')

if __name__ == '__main__':
    print('[{}]'.format(time.strftime('%Y-%m-%d %X')))
    os.system('./init.sh restart')
    print('\n', end='')