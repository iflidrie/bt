# -*- coding: utf-8 -*-
from time import time
import os, struct

try:
    import cPickle as pickle
except ImportError:  # pragma: no cover
    import pickle

from cachelib.base import BaseCache
import threading
# import core.include.public as public


class SimpleCache(BaseCache):
    """Simple memory cache for single process environments.  This class exists
    mainly for the development server and is not 100% thread safe.  It tries
    to use as many atomic operations as possible and no locks for simplicity
    but it could happen under heavy load that keys are added multiple times.

    :param threshold: the maximum number of items the cache stores before
                      it starts deleting some.
    :param default_timeout: the default timeout that is used if no timeout is
                            specified on :meth:`~BaseCache.set`. A timeout of
                            0 indicates that the cache never expires.
    """
    __session_key = 'BT_:'
    __session_basedir = '/www/server/bt-monitor/data/session'

    __SHM_PREFIX = 'SHM_:'
    __SHM_BASEDIR = '/dev/shm/bt-monitor-shm'
    # __session_basedir = '/dev/shm/bt_monitor_session'

    def __init__(self, threshold=5000, default_timeout=30 * 86400):
        BaseCache.__init__(self, default_timeout)
        self._cache = {}
        self.clear = self._cache.clear
        self._threshold = threshold
        self.__LAST_PRUNE_TIME = int(time())
        self.__PRUNE_INTERVAL = 60  # 每隔60秒清理一次缓存
        self.__LOCK = threading.Lock()

    # def clear(self):
    #     public.print_log('【clear】 session', _level='error')
    #     ks = list(self._cache.keys())
    #
    #     for k in ks:
    #         self.delete(k)
    #
    #     self._cache.clear()


    def _prune(self):
        now = int(time())

        # 每隔一段时间清理一次缓存
        # 缓存占95%以上时
        # 清理出至少1/3的空间
        cur_caches = len(self._cache)
        if now > self.__LAST_PRUNE_TIME + self.__PRUNE_INTERVAL\
                or cur_caches > int(self._threshold * 0.95):
            try:
                self.__LOCK.acquire(timeout=1)
                if now <= self.__LAST_PRUNE_TIME + self.__PRUNE_INTERVAL:
                    return
                self.__LAST_PRUNE_TIME = now
            finally:
                self.__LOCK.release()

            i = 0
            toremove = []
            maybe_remove = []
            for key, (expires, _) in self._cache.items():
                if expires != 0:
                    if expires <= now:
                        toremove.append(key)
                        continue
                i += 1
                if i % 3 == 0:
                    maybe_remove.append(key)

            for key in toremove:
                self._cache.pop(key, None)
                cur_caches -= 1

            if cur_caches > int(self._threshold * 0.67):
                for key in maybe_remove:
                    self._cache.pop(key, None)
                    cur_caches -= 1


    def _normalize_timeout(self, timeout):
        timeout = BaseCache._normalize_timeout(self, timeout)
        if timeout > 0:
            timeout = time() + timeout
        return timeout

    def get(self, key):
        try:
            # 优先从shm中查找
            _shm_val = self.__get_shm(key)

            if _shm_val is not None:
                return _shm_val
        except: pass

        try:
            expires, value = self._cache[key]
            if expires == 0 or expires > time():
                return pickle.loads(value)
        except (KeyError, pickle.PickleError):
            try:
                if key[:4] == self.__session_key:
                    filename = '/'.join((self.__session_basedir, self.md5(key)))
                    if not os.path.exists(filename): return None

                    with open(filename, 'rb') as fp:
                        _val = fp.read()

                    expires = struct.unpack('f', _val[:4])[0]
                    if expires == 0 or expires > time():
                        value = _val[4:]
                        self._cache[key] = (expires, value)
                        return pickle.loads(value)
            except:
                pass
            return None

    def set(self, key, value, timeout=None):
        try:
            # 优先写入shm
            if self.__set_shm(key, value, timeout):
                return True
        except: pass

        expires = self._normalize_timeout(timeout)
        self._prune()

        _val = pickle.dumps(value, pickle.HIGHEST_PROTOCOL)
        self._cache[key] = (expires, _val)
        try:
            if key[:4] == self.__session_key:
                # if key[4:] == 'c2547c27-01e1-4a67-98a0-086d1bd71acd':
                #     public.print_log('【update】 session-[{}]: {}'.format(key, len(_val)), _level='error')
                # if len(_val) < 256: return True
                from core import session
                if 'request_token_head' in session:
                    if not os.path.exists(self.__session_basedir): os.makedirs(self.__session_basedir, 384)
                    expires = struct.pack('f', expires)
                    filename = '/'.join((self.__session_basedir, self.md5(key)))
                    with open(filename, 'wb+') as fp:
                        fp.write(expires + _val)
                    os.chmod(filename, 384)
        except:
            pass
        return True

    def add(self, key, value, timeout=None):
        try:
            # 优先写入shm
            if self.__add_shm(key, value, timeout):
                return True
        except: pass

        expires = self._normalize_timeout(timeout)
        self._prune()
        item = (expires, pickle.dumps(value,
                                      pickle.HIGHEST_PROTOCOL))
        if key in self._cache:
            return False
        self._cache.setdefault(key, item)
        return True

    def delete(self, key):
        try:
            # 优先删除shm
            if self.__del_shm(key):
                return True
        except: pass

        result = self._cache.pop(key, None) is not None
        try:
            if key[:4] == self.__session_key:
                # if key[4:] == 'c2547c27-01e1-4a67-98a0-086d1bd71acd':
                #     public.print_log('【delete】 session-[{}]'.format(key), _level='error')
                filename = '/'.join((self.__session_basedir, self.md5(key)))
                if os.path.exists(filename): os.remove(filename)
        except:
            pass
        return result

    def has(self, key):
        try:
            # 优先shm
            if self.__has_shm(key):
                return True
        except: pass

        try:
            expires, value = self._cache[key]
            return expires == 0 or expires > time()
        except KeyError:
            return False

    def md5(self, strings):
        """
        生成MD5
        @strings 要被处理的字符串
        return string(32)
        """
        import hashlib
        m = hashlib.md5()

        m.update(strings.encode('utf-8'))
        return m.hexdigest()

    def __set_shm(self, key, value, timeout=None):
        '''
            @name 尝试将缓存写入shm目录
            @author Zhj<2022-10-08>
            @param  key<string>     键名
            @param  value<mixed>    值
            @param  timeout<int>    存活时间/秒
            @return bool
        '''
        if key[:5] != self.__SHM_PREFIX:
            return False

        self.__makesure_shm_basedir()

        expires = struct.pack('f', self._normalize_timeout(timeout))
        filename = '/'.join((self.__SHM_BASEDIR, self.md5(key)))
        with open(filename, 'wb+') as fp:
            fp.write(expires + pickle.dumps(value, pickle.HIGHEST_PROTOCOL))
        os.chmod(filename, 384)

        return True

    def __get_shm(self, key):
        '''
            @name 尝试从shm目录下读取缓存
            @author Zhj<2022-10-08>
            @param  key<string> 键名
            @return mixed|None
        '''
        if key[:5] != self.__SHM_PREFIX:
            return None

        self.__makesure_shm_basedir()

        filename = '/'.join((self.__SHM_BASEDIR, self.md5(key)))
        if not os.path.exists(filename): return None

        with open(filename, 'rb') as fp:
            _val = fp.read()

        expires = struct.unpack('f', _val[:4])[0]

        # 过期 删除缓存文件
        if expires > 0 and expires <= time():
            os.remove(filename)
            return None

        return pickle.loads(_val[4:])

    def __del_shm(self, key):
        '''
            @name 删除shm目录下的缓存
            @author Zhj<2022-10-08>
            @param  key<string> 键名
            @return bool
        '''
        if key[:5] != self.__SHM_PREFIX:
            return False

        self.__makesure_shm_basedir()

        filename = '/'.join((self.__SHM_BASEDIR, self.md5(key)))
        if os.path.exists(filename):
            os.remove(filename)

        return True

    def __has_shm(self, key):
        '''
            @name 检查shm目录下的缓存是否存在
            @author Zhj<2022-10-08>
            @param  key<string> 键名
            @return bool
        '''
        if key[:5] != self.__SHM_PREFIX:
            return False

        self.__makesure_shm_basedir()

        filename = '/'.join((self.__SHM_BASEDIR, self.md5(key)))
        if not os.path.exists(filename): return False

        # 获取缓存过期时间
        with open(filename, 'rb') as fp:
            expires = struct.unpack('f', fp.read(4))[0]

        # 过期 删除缓存文件
        if expires > 0 and expires <= time():
            os.remove(filename)
            return False

        return True

    def __add_shm(self, key, value, timeout=None):
        '''
            @name 尝试添加缓存到shm目录下
            @author Zhj<2022-10-08>
            @param  key<string>  键名
            @param  value<mixed> 值
            @param  timeout<int> 缓存存活时间/秒
            @return bool
        '''
        if self.__has_shm(key):
            return False

        return self.__set_shm(key, value, timeout)

    def __makesure_shm_basedir(self):
        '''
            @name 确保shm下的缓存目录存在
            @author Zhj<2022-10-08>
            @return void
        '''
        if not os.path.exists(self.__SHM_BASEDIR):
            os.makedirs(self.__SHM_BASEDIR, 384)
