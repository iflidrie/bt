# encoding: utf-8
#
# 事件模块
# Author Zhj<2023-03-23>

import core.include.public as public


class BaseEvent:
    '''
        @name 事件基类
        @author Zhj<2023-03-23>
    '''
    def __str__(self):
        return '<class \'core.include.monitor_events.{}\'>'.format(self.__class__.__name__)


class UserLoginSuccess(BaseEvent):
    '''
        @name 用户登录成功事件
        @author Zhj<2023-03-23>
    '''
    def __init__(self, user_info):
        self.user_info = user_info


class AccountBoundSuccess(BaseEvent):
    '''
        @name 堡塔账号绑定成功事件
        @author Zhj<2023-03-23>
    '''
    def __init__(self):
        pass


class ServerAuthorization(BaseEvent):
    '''
        @name 主机授权事件
        @author Zhj<2023-03-29>
    '''
    def __init__(self, sid, status):
        self.sid = tuple(map(lambda x: int(x), sid))
        self.status = int(status)


class ServerRemoved(BaseEvent):
    '''
        @name 主机删除成功事件
        @author Zhj<2023-04-11>
    '''
    def __init__(self, server_info):
        self.server_info = server_info


# 主机分组删除事件
class ServerGroupRemoved(BaseEvent):
    """
        @name 主机分组删除事件
        @author Zhj<2023-07-04>
    """
    def __init__(self, group_id):
        self.group_id = tuple(sorted(map(lambda x: int(x), group_id)))


# 主机分组设置事件
class ServerGroupSetting(BaseEvent):
    """
        @name 主机分组设置事件
        @author Zhj<2023-07-05>
    """
    def __init__(self, group_id, sid):
        self.group_id = int(group_id)
        self.sid = tuple(map(lambda x: int(x), sid))
