#coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: hwliang <hwl@bt.cn>
# +-------------------------------------------------------------------

#--------------------------------
# 宝塔公共库
#--------------------------------
import json,os,sys,time,re,socket, binascii,base64, string, json
import traceback
from random import choice

_LAN_PUBLIC = None
_LAN_LOG = None
_LAN_TEMPLATE = None

def M(table):
    """
        @name 访问面板数据库
        @author hwliang<hwl@bt.cn>
        @table 被访问的表名(必需)
        @return db.Sql object

        ps: 默认访问data/default.db
    """
    import core.include.sqlite as sqlite
    with sqlite.Sql() as sql:
        return sql.table(table)

def HttpGet(url,timeout = 6,headers = {}):
    """
        @name 发送GET请求
        @author hwliang<hwl@bt.cn>
        @url 被请求的URL地址(必需)
        @timeout 超时时间默认60秒
        @return string
    """
    if url.find('GetAuthToken') == -1:
        if is_local(): return False

    try:
        import core.include.http_requests as http_requests
        res = http_requests.get(url,timeout=timeout,headers = headers)
        if res.status_code == 0:
            if headers: return False
            s_body = res.text
            return s_body
        s_body = res.text
        del res
        return s_body
    except BaseException as e:
        print_exc_stack(e)
        return False

def httpGet(url,timeout=6):
    return HttpGet(url,timeout)

def HttpPost(url,data,timeout = 6,headers = {}):
    """
        发送POST请求
        @url 被请求的URL地址(必需)
        @data POST参数，可以是字符串或字典(必需)
        @timeout 超时时间默认60秒
        return string
    """
    if url.find('GetAuthToken') == -1:
        if is_local(): return False

    try:
        import core.include.http_requests as http_requests
        res = http_requests.post(url,data=data,timeout=timeout,headers = headers)
        if res.status_code == 0:
            if headers: return False
            s_body = res.text
            return s_body
        s_body = res.text
        return s_body
    except BaseException as e:
        print_exc_stack(e)
        return False

def httpPost(url,data,timeout=6):
    """
        @name 发送POST请求
        @author hwliang<hwl@bt.cn>
        @param url 被请求的URL地址(必需)
        @param data POST参数，可以是字符串或字典(必需)
        @param timeout 超时时间默认60秒
        @return string
    """
    return HttpPost(url,data,timeout)

def check_home():
    return True

def Md5(strings):
    """
        @name 生成MD5
        @author hwliang<hwl@bt.cn>
        @param strings 要被处理的字符串
        @return string(32)
    """
    if type(strings) != bytes:
        strings = strings.encode()
    import hashlib
    m = hashlib.md5()
    m.update(strings)
    return m.hexdigest()

def md5(strings):
    return Md5(strings)

def FileMd5(filename):
    """
        @name 生成文件的MD5
        @author hwliang<hwl@bt.cn>
        @param filename 文件名
        @return string(32) or False
    """
    if not os.path.isfile(filename): return False
    import hashlib
    blocksize = 8192
    my_hash = hashlib.md5()
    with open(filename,'rb') as fp:
        while True:
            b = fp.read(blocksize)
            if not b :
                break
            my_hash.update(b)

    return my_hash.hexdigest()

def GetRandomString(length):
    """
       @name 取随机字符串
       @author hwliang<hwl@bt.cn>
       @param length 要获取的长度
       @return string(length)
    """
    from random import Random
    strings = ''
    chars = 'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz0123456789'
    chrlen = len(chars) - 1
    random = Random()
    for i in range(length):
        strings += chars[random.randint(0, chrlen)]
    return strings

def ReturnJson(status,msg,args=()):
    """
        @name 取通用Json返回
        @author hwliang<hwl@bt.cn>
        @param status  返回状态
        @param msg  返回消息
        @return string(json)
    """
    return GetJson(ReturnMsg(status,msg,args))

def returnJson(status,msg,args=()):
    """
        @name 取通用Json返回
        @author hwliang<hwl@bt.cn>
        @param status  返回状态
        @param msg  返回消息
        @return string(json)
    """
    return ReturnJson(status,msg,args)

def ReturnMsg(status,msg,args = ()):
    """
        @name 取通用dict返回
        @author hwliang<hwl@bt.cn>
        @param status  返回状态
        @param msg  返回消息
        @return dict  {"status":bool,"msg":string}
    """
    return {'status':status,'msg':msg}

def returnMsg(status,msg,args = ()):
    """
        @name 取通用dict返回
        @author hwliang<hwl@bt.cn>
        @param status  返回状态
        @param msg  返回消息
        @return dict  {"status":bool,"msg":string}
    """
    return ReturnMsg(status,msg,args)


def GetFileMode(filename):
    """
        @name 取文件权限字符串
        @author hwliang<hwl@bt.cn>
        @param filename  文件全路径
        @return string  如：644/777/755
    """
    stat = os.stat(filename)
    accept = str(oct(stat.st_mode)[-3:])
    return accept

def get_mode_and_user(path):
    '''取文件或目录权限信息'''
    import pwd
    data = {}
    if not os.path.exists(path): return None
    stat = os.stat(path)
    data['mode'] = str(oct(stat.st_mode)[-3:])
    try:
        data['user'] = pwd.getpwuid(stat.st_uid).pw_name
    except:
        data['user'] = str(stat.st_uid)
    return data


def GetJson(data):
    """
    将对象转换为JSON
    @data 被转换的对象(dict/list/str/int...)
    """
    if data == bytes: data = data.decode('utf-8')
    try:
        return json.dumps(data,ensure_ascii=False)
    except:
        return json.dumps(returnMsg(False,"错误的响应: %s" % str(data)))

def getJson(data):
    return GetJson(data)

def ReadFile(filename,mode = 'r'):
    """
    读取文件内容
    @filename 文件名
    return string(bin) 若文件不存在，则返回None
    """
    import os
    if not os.path.exists(filename): return False
    fp = None
    try:
        fp = open(filename, mode)
        f_body = fp.read()
    except Exception as ex:
        if sys.version_info[0] != 2:
            try:
                fp = open(filename, mode,encoding="utf-8")
                f_body = fp.read()
            except:
                fp = open(filename, mode,encoding="GBK")
                f_body = fp.read()
        else:
            return False
    finally:
        if fp and not fp.closed:
            fp.close()
    return f_body

def readFile(filename,mode='r'):
    '''
        @name 读取指定文件数据
        @author hwliang<2021-06-09>
        @param filename<string> 文件名
        @param mode<string> 文件打开模式，默认r
        @return string or bytes or False 如果返回False则说明读取失败
    '''
    return ReadFile(filename,mode)

def WriteFile(filename,s_body,mode='w+'):
    """
    写入文件内容
    @filename 文件名
    @s_body 欲写入的内容
    return bool 若文件不存在则尝试自动创建
    """
    try:
        fp = open(filename, mode)
        fp.write(s_body)
        fp.close()
        return True
    except:
        try:
            fp = open(filename, mode,encoding="utf-8")
            fp.write(s_body)
            fp.close()
            return True
        except:
            return False

def writeFile(filename,s_body,mode='w+'):
    '''
        @name 写入到指定文件
        @author hwliang<2021-06-09>
        @param filename<string> 文件名
        @param s_boey<string/bytes> 被写入的内容，字节或字符串
        @param mode<string> 文件打开模式，默认w+
        @return bool
    '''
    return WriteFile(filename,s_body,mode)

def WriteLog(type,logMsg,status_code = 1,error_info = ''):
    '''
        @name 写日志信息
        @author hwliang
        @param type<string> 日志类型
        @param logMsg<string> 日志信息
        @param status_code<int> 日志状态码 0.失败 1.成功 默认1
        @param error_info<string> 错误信息 默认''
        @return void
    '''
    #写日志
    try:
        import time
        import core.include.sqlite as sqlite
        username = 'system'
        uid = 0
        tmp_msg = ''
        try:
            from core import session
            if 'username' in session:
                username = session['username']
                uid = session['uid']
                print_log(session.get('debug'))
                if session.get('debug') == 1: return
        except:
            pass

        sql = sqlite.Sql()
        mDate = time.strftime('%Y-%m-%d %X',time.localtime())
        data = (uid or 0, username or 'system', type, logMsg + tmp_msg, mDate, status_code, error_info)
        sql.table('logs').add('uid,username,type,log,addtime,status_code,error_info',data)
    except:
        pass


def GetConfigValue(key):
    if key == 'home': return 'https://ifli.cn'
    '''
    取配置值
    '''
    config = GetConfig()
    if not key in config.keys():
        return None
    return config[key]

def SetConfigValue(key,value):
    config = GetConfig()
    config[key] = value
    WriteConfig(config)

def GetConfig():
    '''
    取所有配置项
    '''
    path = "config/config.json"
    if not os.path.exists(path): return {}
    f_body = ReadFile(path)
    if not f_body: return {}
    return json.loads(f_body)

def WriteConfig(config):
    path = "config/config.json"
    WriteFile(path,json.dumps(config))


def get_preexec_fn(run_user):
    '''
        @name 获取指定执行用户预处理函数
        @author hwliang<2021-08-19>
        @param run_user<string> 运行用户
        @return 预处理函数
    '''
    import pwd
    pid = pwd.getpwnam(run_user)
    uid = pid.pw_uid
    gid = pid.pw_gid

    def _exec_rn():
        os.setgid(gid)
        os.setuid(uid)
    return _exec_rn


def ExecShell(cmdstring, timeout=None, shell=True,cwd=None,env=None,user = None):
    '''
        @name 执行命令
        @author hwliang<2021-08-19>
        @param cmdstring 命令 [必传]
        @param timeout 超时时间
        @param shell 是否通过shell运行
        @param cwd 进入的目录
        @param env 环境变量
        @param user 执行用户名
        @return 命令执行结果
    '''
    a = ''
    e = ''
    import subprocess,tempfile
    preexec_fn = None
    tmp_dir = '/dev/shm'
    if user:
        preexec_fn = get_preexec_fn(user)
        tmp_dir = '/tmp'
    try:
        rx = md5(cmdstring)
        succ_f = tempfile.SpooledTemporaryFile(max_size=4096,mode='wb+',suffix='_succ',prefix='btex_' + rx ,dir=tmp_dir)
        err_f = tempfile.SpooledTemporaryFile(max_size=4096,mode='wb+',suffix='_err',prefix='btex_' + rx ,dir=tmp_dir)
        sub = subprocess.Popen(cmdstring, close_fds=True, shell=shell,bufsize=128,stdout=succ_f,stderr=err_f,cwd=cwd,env=env,preexec_fn=preexec_fn)
        if timeout:
            s = 0
            d = 0.01
            while sub.poll() == None:
                time.sleep(d)
                s += d
                if s >= timeout:
                    if not err_f.closed: err_f.close()
                    if not succ_f.closed: succ_f.close()
                    return 'Timed out'
        else:
            sub.wait()

        err_f.seek(0)
        succ_f.seek(0)
        a = succ_f.read()
        e = err_f.read()
        if not err_f.closed: err_f.close()
        if not succ_f.closed: succ_f.close()
    except:
        return '',get_error_info()
    try:
        #编码修正
        if type(a) == bytes: a = a.decode('utf-8')
        if type(e) == bytes: e = e.decode('utf-8')
    except:
        a = str(a)
        e = str(e)

    return a,e

def GetLocalIp():
    #取本地外网IP
    filename = 'data/iplist.txt'
    try:
        ipaddress = readFile(filename)
        if not ipaddress or not check_ip(ipaddress) or is_local_ip(ipaddress):
            url = 'http://pv.sohu.com/cityjson?ie=utf-8'
            m_str = HttpGet(url)
            ipaddress = re.search(r'\d+.\d+.\d+.\d+', m_str).group(0)
            if is_local_ip(ipaddress):
                raise Exception('Local IP')
            WriteFile(filename, ipaddress)
        c_ip = check_ip(ipaddress)
        if not c_ip: return GetHost()
        return ipaddress
    except:
        try:
            url = GetConfigValue('home') + '/Api/getIpAddress'
            ipaddress = HttpGet(url)
            WriteFile(filename, ipaddress)
            return ipaddress
        except:
            return GetHost()

def is_ipv4(ip):
    '''
        @name 是否是IPV4地址
        @author hwliang
        @param ip<string> IP地址
        @return True/False
    '''
    #验证基本格式
    if not re.match(r"^\d{1,3}.\d{1,3}.\d{1,3}.\d{1,3}$", ip):
        return False

    # 验证每个段是否在合理范围
    try:
        socket.inet_pton(socket.AF_INET, ip)
    except AttributeError:
        try:
            socket.inet_aton(ip)
        except socket.error:
            return False
    except socket.error:
        return False
    return True


def is_ipv6(ip):
    '''
        @name 是否为IPv6地址
        @author hwliang
        @param ip<string> 地址
        @return True/False
    '''
    # 验证基本格式
    if not re.match(r"^[\w:]+$", ip):
        return False

    # 验证IPv6地址
    try:
        socket.inet_pton(socket.AF_INET6, ip)
    except socket.error:
        return False
    return True


def check_ip(ip):
    return is_ipv4(ip) or is_ipv6(ip)

def is_domain(domain):
    '''
        @name 域名格式验证
        @author hwliang
        @param domain<string> 域名
        @return True/False
    '''
    if not re.match(r"^[\w\-\.]+$", domain):
        return False
    return True

def GetHost(port = False):
    from flask import request
    host_tmp = request.headers.get('host')
    # 验证基本格式
    if not host_tmp or not re.match("^[\w\.\-]+$", str(host_tmp)):
        host_tmp = ''

    if not host_tmp:
        if request.url_root:
            tmp = re.findall(r"(https|http)://([\w:\.-]+)", request.url_root)
            if tmp: host_tmp = tmp[0][1]

    port_no = get_panel_port()

    if not host_tmp:
        # host_tmp = '{}:{}'.format(GetLocalIp(), port_no)
        host_tmp = '{}:{}'.format('127.0.0.1', port_no)

    # try:
    #     if host_tmp.find(':') == -1: host_tmp += ':80'
    # except:
    #     host_tmp = '127.0.0.1:{}'.format(port_no)

    h = host_tmp.split(':')
    if port: return h[-1]

    return ':'.join(h[0:-1])


def get_panel_port():
    '''
        @name 获取面板端口
        @author hwliang
        @return int
    '''
    try:
        server_port = get_config_value('config','port', None)

        if server_port is None:
            return 806

        # return int(readFile('data/port.pl').strip())
        return int(server_port)
    except:
        return 806


def GetClientIp():
    from flask import request
    ipaddr = request.remote_addr
    if ipaddr[:7] == '::ffff:':
        ipaddr = ipaddr[7:]
    # ipaddr =  request.remote_addr.replace('::ffff:','')
    if not check_ip(ipaddr): return '未知IP地址'
    return ipaddr

def get_client_ip():
    return GetClientIp()


def get_timeout(url,timeout=3):
    try:
        start = time.time()
        result = int(httpGet(url,timeout))
        return result,int((time.time() - start) * 1000 - 500)
    except: return 0,False


#过滤输入
def checkInput(data):
   if not data: return data
   if type(data) != str: return data
   checkList = [
                {'d':'<','r':'＜'},
                {'d':'>','r':'＞'},
                {'d':'\'','r':'‘'},
                {'d':'"','r':'“'},
                {'d':'&','r':'＆'},
                {'d':'#','r':'＃'},
                {'d':'<','r':'＜'}
                ]
   for v in checkList:
       data = data.replace(v['d'],v['r'])
   return data

#取文件指定尾行数
def GetNumLines(path,num,p=1):
    pyVersion = sys.version_info[0]
    max_len = 1024*128
    try:
        from cgi import html
        if not os.path.exists(path): return ""
        start_line = (p - 1) * num
        count = start_line + num
        fp = open(path,'r')
        buf = ""
        fp.seek(-1, 2)
        if fp.read(1) == "\n": fp.seek(-1, 2)
        data = []
        total_len = 0
        b = True
        n = 0
        for i in range(count):
            while True:
                newline_pos = str.rfind(str(buf), "\n")
                pos = fp.tell()
                if newline_pos != -1:
                    if n >= start_line:
                        line = buf[newline_pos + 1:]
                        line_len = len(line)
                        total_len += line_len
                        sp_len = total_len - max_len
                        if sp_len > 0:
                            line = line[sp_len:]
                        try:
                            data.insert(0,html.escape(line))
                        except: pass
                    buf = buf[:newline_pos]
                    n += 1
                    break
                else:
                    if pos == 0:
                        b = False
                        break
                    to_read = min(4096, pos)
                    fp.seek(-to_read, 1)
                    t_buf = fp.read(to_read)
                    if pyVersion == 3:
                        try:
                            if type(t_buf) == bytes: t_buf = t_buf.decode('utf-8')
                        except:t_buf = str(t_buf)
                    buf = t_buf + buf
                    fp.seek(-to_read, 1)
                    if pos - to_read == 0:
                        buf = "\n" + buf
                if total_len >= max_len: break
            if not b: break
        fp.close()
        result = "\n".join(data)
        if not result: raise Exception('null')
    except:
        result = ExecShell("tail -n {} {}".format(num,path))[0]
        if len(result) > max_len:
            result = result[-max_len:]

    try:
        try:
            result = json.dumps(result)
            return json.loads(result).strip()
        except:
            if pyVersion == 2:
                result = result.decode('utf8',errors='ignore')
            else:
                result = result.encode('utf-8',errors='ignore').decode("utf-8",errors="ignore")
        return result.strip()
    except: return ""

#验证证书
def CheckCert(certPath = 'ssl/certificate.pem'):
    openssl = '/usr/local/openssl/bin/openssl'
    if not os.path.exists(openssl): openssl = 'openssl'
    certPem = readFile(certPath)
    s = "\n-----BEGIN CERTIFICATE-----"
    tmp = certPem.strip().split(s)
    for tmp1 in tmp:
        if tmp1.find('-----BEGIN CERTIFICATE-----') == -1:  tmp1 = s + tmp1
        writeFile(certPath,tmp1)
        result = ExecShell(openssl + " x509 -in "+certPath+" -noout -subject")
        if result[1].find('-bash:') != -1: return True
        if len(result[1]) > 2: return False
        if result[0].find('error:') != -1: return False
    return True


# 获取面板地址
def getPanelAddr():
    from flask import request
    protocol = 'https://' if os.path.exists("data/ssl.pl") else 'http://'
    return protocol + request.headers.get('host')


#字节单位转换
def to_size(size):
    if not size: return '0.00 b'
    size = float(size)
    d = ('b','KB','MB','GB','TB')
    s = d[0]
    for b in d:
        if size < 1024: return ("%.2f" % size) + ' ' + b
        size = size / 1024
        s = b
    return ("%.2f" % size) + ' ' + b


def checkCode(code,outime = 120):
    #校验验证码
    from core import session,cache
    try:
        codeStr = cache.get('codeStr')
        cache.delete('codeStr')
        if not codeStr:
            session['login_error'] ='验证码已过期，请重新获取'
            return False

        if md5(code.lower()) != codeStr:
            session['login_error'] = '验证码错误'
            return False
        return True
    except:
        session['login_error'] = '验证码错误'
        return False

#写进度
def writeSpeed(title,used,total,speed = 0):
    import json
    if not title:
        data = {'title':None,'progress':0,'total':0,'used':0,'speed':0}
    else:
        progress = int((100.0 * used / total))
        data = {'title':title,'progress':progress,'total':total,'used':used,'speed':speed}
    writeFile('/tmp/panelSpeed.pl',json.dumps(data))
    return True

#取进度
def getSpeed():
    import json;
    data = readFile('/tmp/panelSpeed.pl')
    if not data:
        data = json.dumps({'title':None,'progress':0,'total':0,'used':0,'speed':0})
        writeFile('/tmp/panelSpeed.pl',data)
    return json.loads(data)

def get_requests_headers():
    return {"Content-type": "application/x-www-form-urlencoded", "User-Agent": "BT-Panel"}

def downloadFile(url, filename, timeout=30):
    try:
        import requests
        from requests.packages.urllib3.exceptions import InsecureRequestWarning
        requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
        # import requests.packages.urllib3.util.connection as urllib3_conn
        # old_family = urllib3_conn.allowed_gai_family
        # urllib3_conn.allowed_gai_family = lambda: socket.AF_INET
        res = requests.get(url, headers=get_requests_headers(), timeout=timeout, stream=True)
        with open(filename, "wb") as f:
            for _chunk in res.iter_content(chunk_size=8192):
                f.write(_chunk)
        # urllib3_conn.allowed_gai_family = old_family
    except:
        ExecShell("wget -O {} {} --no-check-certificate".format(filename,url))

def exists_args(args,get):
    '''
        @name 检查参数是否存在
        @author hwliang<2021-06-08>
        @param args<list or str> 参数列表 允许是列表或字符串
        @param get<dict_obj> 参数对像
        @return bool 都存在返回True，否则抛出KeyError异常
    '''
    if type(args) == str:
        args = args.split(',')
    for arg in args:
        if not arg in get:
            raise KeyError('缺少必要参数: {}'.format(arg))
    return True


def get_error_info():
    import traceback
    errorMsg = traceback.format_exc()
    return errorMsg


def get_plugin_replace_rules():
    '''
        @name 获取插件文件内容替换规则
        @author hwliang<2021-06-28>
        @return list
    '''
    return [
        {
            "find":"[PATH]",
            "replace": "[PATH]"
        }
    ]


def get_plugin_title(plugin_name):
    '''
        @name 获取插件标题
        @author hwliang<2021-06-24>
        @param plugin_name<string> 插件名称
        @return string
    '''

    info_file = '{}/{}/info.json'.format(get_plugin_path(),plugin_name)
    try:
        return json.loads(readFile(info_file))['title']
    except:
        return plugin_name

def version():
    '''
        @name 获取软件版本号
        @author hwliang
        @return string
    '''
    v_file = '{}/version.pl'.format(get_panel_path())
    if not os.path.exists(v_file):
        return '1.0.0'
    return readFile(v_file).strip()

def get_error_object(plugin_title = None,plugin_name = None):
    '''
        @name 获取格式化错误响应对像
        @author hwliang<2021-06-21>
        @return Resp
    '''
    if not plugin_title: plugin_title = get_plugin_title(plugin_name)
    try:
        from core import request,Resp
        is_cli = False
    except:
        is_cli = True

    if is_cli:
        raise get_error_info()
    ss = '''404 Not Found: The requested URL was not found on the server. If you entered the URL manually please check your spelling and try again.

During handling of the above exception, another exception occurred:'''
    error_info = get_error_info().strip().split(ss)[-1].strip()
    request_info = '''REQUEST_DATE: {request_date}
 PAN_VERSION: {panel_version}
  OS_VERSION: {os_version}
 REMOTE_ADDR: {remote_addr}
 REQUEST_URI: {method} {full_path}
REQUEST_FORM: {request_form}
  USER_AGENT: {user_agent}'''.format(
    request_date = getDate(),
    remote_addr = GetClientIp(),
    method = request.method,
    full_path = request.full_path,
    request_form = request.form.to_dict(),
    user_agent = request.headers.get('User-Agent'),
    panel_version = version(),
    os_version = get_os_version()
)

    result =readFile('{}/BTPanel/templates/default/plugin_error.html'.format(get_panel_path())).format(
        plugin_name=plugin_title,
        request_info=request_info,
        error_title=error_info.split("\n")[-1],
        error_msg=error_info
        )
    return Resp(result,500)



#搜索数据中是否存在
def inArray(arrays,searchStr):
    for key in arrays:
        if key == searchStr: return True

    return False

#格式化指定时间戳
def format_date(format="%Y-%m-%d %H:%M:%S",times = None):
    if not times: times = int(time.time())
    time_local = time.localtime(times)
    return time.strftime(format, time_local)


#检查是否为IPv4地址
def checkIp(ip):
    p = re.compile(r'^((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$')
    if p.match(ip):
        return True
    else:
        return False

#检查端口是否合法
def checkPort(port):
    if not re.match("^\d+$",port): return False
    ports = ['21','25','443','8080','888','8888','8443']
    if port in ports: return False
    intport = int(port)
    if intport < 1 or intport > 65535: return False
    return True

#字符串取中间
def getStrBetween(startStr,endStr,srcStr):
    start = srcStr.find(startStr)
    if start == -1: return None
    end = srcStr.find(endStr)
    if end == -1: return None
    return srcStr[start+1:end]

#取CPU类型
def getCpuType():
    cpuinfo = open('/proc/cpuinfo','r').read()
    rep = "model\s+name\s+:\s+(.+)"
    tmp = re.search(rep,cpuinfo,re.I)
    cpuType = ''
    if tmp:
        cpuType = tmp.groups()[0]
    else:
        cpuinfo = ExecShell('LANG="en_US.UTF-8" && lscpu')[0]
        rep = "Model\s+name:\s+(.+)"
        tmp = re.search(rep,cpuinfo,re.I)
        if tmp: cpuType = tmp.groups()[0]
    return cpuType


#加密密码字符
def hasPwd(password):
    import crypt;
    return crypt.crypt(password,password)

def getDate(format='%Y-%m-%d %X'):
    #取格式时间
    return time.strftime(format,time.localtime())


def GetSSHPort():
    try:
        file = '/etc/ssh/sshd_config'
        conf = ReadFile(file)
        rep = "#*Port\s+([0-9]+)\s*\n"
        port = re.search(rep,conf).groups(0)[0]
        return int(port)
    except:
        return 22

def get_sshd_port():
    '''
        @name 获取sshd端口
        @author hwliang
        @return int
    '''
    # 先尝试从进程中获取当前实际的监听端口
    sshd_port = 22
    is_ok = 0
    pid = get_sshd_pid_of_pidfile()
    if not pid: pid = get_sshd_pid_of_binfile()
    if pid:
        try:
            import psutil
            p = psutil.Process(pid)
            for conn in p.connections():
                if conn.status == 'LISTEN':
                    sshd_port = conn.laddr[1]
                    is_ok = 1
                    break
        except:pass

    # 如果从进程获取失败，则尝试从配置文件获取
    if not is_ok: sshd_port = GetSSHPort()

    return sshd_port



def get_sshd_pid_of_pidfile():
    '''
        @name 通过PID文件获取SSH状态
        @author hwliang
        @return int 0:关闭 pid:开启
    '''
    sshd_pid_list =['/run/sshd.pid','/var/run/sshd.pid','/run/ssh.pid','/var/run/ssh.pid']
    sshd_pid_file = None
    for spid_file in sshd_pid_list:
        if os.path.exists(spid_file):
            sshd_pid_file = spid_file
            break

    if sshd_pid_file:
        sshd_pid = readFile(sshd_pid_file)
        if not sshd_pid: return 0
        try:
            sshd_pid = int(sshd_pid)
            if not sshd_pid: return 0
            if pid_exists(sshd_pid):
                return sshd_pid
        except:
            pass
    return 0

def get_sshd_pid_of_binfile():
    '''
        @name 通过执行文件获取SSH状态
        @author hwliang
        @return int 进程pid
    '''
    sshd_bin_list = ['/usr/sbin/sshd', '/usr/bin/sshd','/usr/sbin/ssh','/usr/bin/ssh']
    sshd_bin = None
    pid = 0
    for sbin in sshd_bin_list:
        if os.path.exists(sbin):
            sshd_bin = sbin
            break

    if sshd_bin:
        pid = get_process_pid(sshd_bin.split('/')[-1],sshd_bin,'-D')

    return pid

def GetSSHStatus():
    '''
        @name 获取SSH状态
        @author hwliang
        @return bool
    '''
    if get_sshd_pid_of_pidfile():
        return True
    elif get_sshd_pid_of_binfile():
        return True
    return False


def get_sshd_status():
    '''
        @name 获取SSH状态
        @author hwliang
        @return bool
    '''
    return GetSSHStatus()


#检查端口是否合法
def CheckPort(port,other=None):
    if type(port) == str: port = int(port)
    if port < 1 or port > 65535: return False
    if other:
        checks = [22,20,21,8888,3306,11211,888,25]
        if port in checks: return False
    return True


def to_btint(string):
    m_list = []
    for s in string:
        m_list.append(ord(s))
    return m_list


#获取识别码
def get_uuid():
    import uuid
    return uuid.UUID(int=uuid.getnode()).hex[-12:]

#取计算机名
def get_hostname():
    import socket
    return socket.gethostname()


#取mysql datadir
def get_datadir():
    mycnf_file = '/etc/my.cnf'
    if not os.path.exists(mycnf_file): return ''
    mycnf = readFile(mycnf_file)
    import re
    tmp = re.findall(r"datadir\s*=\s*(.+)",mycnf)
    if not tmp: return ''
    return tmp[0]


#进程是否存在
def process_exists(pname,exe = None,cmdline = None):
    try:
        import psutil
        pids = psutil.pids()
        for pid in pids:
            try:
                p = psutil.Process(pid)
                if p.name() == pname:
                    if not exe and not cmdline:
                        return True
                    else:
                        if exe:
                            if p.exe() == exe: return True
                        if cmdline:
                            if cmdline in  p.cmdline(): return True
            except:pass
        return False
    except: return True

def get_process_pid(pname,exe = None,cmdline = None):
    '''
        @name 通过进程名获取进程PID
        @author hwliang
        @param pname 进程名
        @param exe 进程路径
        @param cmdline 进程任意命令行参数
        @return  int 返回进程PID
    '''
    import psutil
    pids = psutil.pids()
    for pid in pids:
        try:
            p = psutil.Process(pid)
            if p.name() == pname:
                if not exe and not cmdline:
                    return pid
                else:
                    if exe:
                        if p.exe() != exe:
                            if not cmdline:
                                return pid
                            return 0
                    if cmdline:
                        if cmdline in  p.cmdline(): return pid
        except:pass
    return 0

#pid是否存在
def pid_exists(pid):
    if os.path.exists('/proc/{}/exe'.format(pid)):
        return True
    return False

#获取mac
def get_mac_address():
    import uuid
    mac=uuid.UUID(int = uuid.getnode()).hex[-12:]
    return ":".join([mac[e:e+2] for e in range(0,11,2)])


#转码
def to_string(lites):
    if type(lites) != list: lites = [lites]
    m_str = ''
    for mu in lites:
        if sys.version_info[0] == 2:
            m_str += unichr(mu).encode('utf-8')
        else:
            m_str += chr(mu)
    return m_str

#解码
def to_ord(string):
    o  = []
    for s in string:
        o.append(ord(s))
    return o

#xss 防御
def xssencode(text):
    try:
        from cgi import html
        list=['`','~','&','#','/','*','$','@','<','>','\"','\'',';','%',',','.','\\u']
        ret=[]
        for i in text:
            if i in list:
                i=''
            ret.append(i)
        str_convert = ''.join(ret)
        text2=html.escape(str_convert, quote=True)
        return text2
    except:
        return text.replace('&', '&amp;').replace('"', '&quot;').replace('<', '&lt;').replace('>', '&gt;')


#xss 防御
def xsssec(text):
    return text.replace('&', '&amp;').replace('"', '&quot;').replace('<', '&lt;').replace('>', '&gt;')

#xss version
def xss_version(text):
    try:
        if not text or not isinstance(text,str): return text
        text = text.strip()
        list=['`','~','&','#','/','*','$','@','<','>','\"','\'',';','%',',','\\u']
        ret=[]
        for i in text:
            if i in list:
                i=''
            ret.append(i)
        str_convert = ''.join(ret)
        return str_convert
    except:
        return text.replace('&', '&amp;').replace('"', '&quot;').replace('<', '&lt;').replace('>', '&gt;')

#xss 防御
def xssencode2(text):
    try:
        from cgi import html
        text2=html.escape(text, quote=True)
        return text2
    except:
        return text.replace('&', '&amp;').replace('"', '&quot;').replace('<', '&lt;').replace('>', '&gt;')
# 取缓存
def cache_get(key):
    from core import cache
    return cache.get(key)

# 设置缓存
def cache_set(key,value,timeout = None):
    from core import cache
    return cache.set(key,value,timeout)

# 删除缓存
def cache_remove(key):
    from core import cache
    return cache.delete(key)

# 取session值
def sess_get(key):
    from core import session
    if key in session: return session[key]
    return None

# 设置或修改session值
def sess_set(key,value):
    from core import session
    session[key] = value
    return True

# 删除指定session值
def sess_remove(key):
    from core import session
    if key in session: del(session[key])
    return True

# 构造分页
def get_page(count,p=1,rows=12,callback='',result='1,2,3,4,5,8'):
    import core.include.page as page
    from core import request
    page = page.Page()
    info = { 'count':count,  'row':rows,  'p':p, 'return_js':callback ,'uri':url_encode(request.full_path)}
    data = { 'page': page.GetPage(info,result),  'shift': str(page.SHIFT), 'row': str(page.ROW) , 'count': count}
    return data


def get_os_version():
    '''
        @name 取操作系统版本
        @author hwliang<2021-08-07>
        @return string
    '''
    p_file = '/etc/.productinfo'
    if os.path.exists(p_file):
        s_tmp = readFile(p_file).split("\n")
        if s_tmp[0].find('Kylin') != -1 and len(s_tmp) > 1:
            version = s_tmp[0] + ' ' + s_tmp[1].split('/')[0].strip()
    else:
        version = readFile('/etc/redhat-release')
    if not version:
        version = readFile('/etc/issue').strip().split("\n")[0].replace('\\n','').replace('\l','').strip()
    else:
        version = version.replace('release ','').replace('Linux','').replace('(Core)','').strip()
    v_info = sys.version_info
    try:
        version = "{} {}(Py{}.{}.{})".format(version,os.uname().machine,v_info.major,v_info.minor,v_info.micro)
    except:
        version = "{} (Py{}.{}.{})".format(version,v_info.major,v_info.minor,v_info.micro)
    return xsssec(version)

#取文件或目录大小
def get_path_size(path, exclude=[]):
    """根据排除目录获取路径的总大小

    :path 目标路径
    :exclude 排除路径单个字符串或者多个列表。匹配路径是基于path的相对路径,规则是
        tar命令的--exclude规则的子集。
    """
    import fnmatch
    if not os.path.exists(path): return 0
    if os.path.isfile(path): return os.path.getsize(path)
    if type(exclude) != type([]):
        exclude = [exclude]

    path = path[0:-1] if path[-1] == "/" else path
    path = os.path.normcase(path)
    # print("path:"+ path)
    # print("exclude:"+ str(exclude))
    _exclude = exclude[0:]
    for i, e in enumerate(_exclude):
        if not e.startswith(path):
            basename = os.path.basename(path)
            if not e.startswith(basename):
                exclude.append(os.path.join(path, e))
            else:
                new_exc = e.replace(basename+"/", "")
                new_exc = os.path.join(path, new_exc)
                exclude.append(new_exc)

    # print(exclude)
    total_size = 0
    count = 0
    for root, dirs, files in os.walk(path, topdown=True):
        # filter path
        for exc in exclude:
            for d in dirs:
                sub_dir = os.path.normcase(root+os.path.sep+d)
                if fnmatch.fnmatch(sub_dir, exc) or d==exc:
                    # print("排除目录:"+sub_dir)
                    dirs.remove(d)
        count += 1
        for f in files:
            to_exclude = False
            count += 1
            filename = os.path.normcase(root+os.path.sep+f)
            if not os.path.exists(filename): continue
            if os.path.islink(filename): continue
            # filter file
            norm_filename = os.path.normcase(filename)
            for fexc in exclude:
                if fnmatch.fnmatch(norm_filename, fexc) or fexc==f:
                    to_exclude = True
                    # print("排除文件:"+norm_filename)
                    break
            if to_exclude:
                continue
            total_size += os.path.getsize(filename)
    return total_size

#写关键请求日志
def write_request_log(reques = None):
    return
    try:
        from core import request,g,session
        if session.get('debug') == 1: return
        if request.path in ['/service_status','/favicon.ico','/task','/system','/ajax','/control','/data','/ssl']:
            return False

        log_path = '{}/logs/request'.format(get_panel_path())
        log_file = getDate(format='%Y-%m-%d') + '.json'
        if not os.path.exists(log_path): os.makedirs(log_path)

        log_data = []
        log_data.append(getDate())
        log_data.append(GetClientIp() + ':' + str(request.environ.get('REMOTE_PORT')))
        log_data.append(request.method)
        log_data.append(request.full_path)
        log_data.append(request.headers.get('User-Agent'))
        if request.method == 'POST':
            args = str(request.form.to_dict())
            if len(args) < 2048 and args.find('pass') == -1 and args.find('user') == -1:
                log_data.append(args)
            else:
                log_data.append('{}')
        else:
            log_data.append('{}')
        log_data.append(int((time.time() - g.request_time) * 1000))
        WriteFile(log_path + '/' + log_file,json.dumps(log_data) + "\n",'a+')
        rep_sys_path()
    except: pass


#设置权限
def set_mode(filename,mode):
    if not os.path.exists(filename): return False
    mode = int(str(mode),8)
    os.chmod(filename,mode)
    return True

def create_linux_user(user,group):
    '''
        @name 创建系统用户
        @author hwliang<2022-01-15>
        @param user<string> 用户名
        @param group<string> 所属组
        @return bool
    '''
    ExecShell("groupadd {}".format(group))
    ExecShell('useradd -s /sbin/nologin -g {} {}'.format(user,group))
    return True

#设置用户组
def set_own(filename,user,group=None):
    if not os.path.exists(filename): return False
    from pwd import getpwnam
    try:
        user_info = getpwnam(user)
        user = user_info.pw_uid
        if group:
            user_info = getpwnam(group)
        group = user_info.pw_gid
    except:
        if user == 'www': create_linux_user(user)
        #如果指定用户或组不存在，则使用www
        try:
            user_info = getpwnam('www')
        except:
            create_linux_user(user)
            user_info = getpwnam('www')
        user = user_info.pw_uid
        group = user_info.pw_gid
    os.chown(filename,user,group)
    return True

#校验路径安全
def path_safe_check(path,force=True):
    if len(path) > 256: return False
    checks = ['..','./','\\','%','$','^','&','*','~','"',"'",';','|','{','}','`']
    for c in checks:
        if path.find(c) != -1: return False
    if force:
        rep = r"^[\w\s\.\/-]+$"
        if not re.match(rep,path): return False
    return True

def en_punycode(domain):
    if sys.version_info[0] == 2:
        domain = domain.encode('utf8')
    tmp = domain.split('.')
    newdomain = ''
    for dkey in tmp:
        if dkey == '*': continue
        #匹配非ascii字符
        match = re.search(u"[\x80-\xff]+",dkey)
        if not match: match = re.search(u"[\u4e00-\u9fa5]+",dkey)
        if not match:
            newdomain += dkey + '.'
        else:
            if sys.version_info[0] == 2:
                newdomain += 'xn--' + dkey.decode('utf-8').encode('punycode') + '.'
            else:
                newdomain += 'xn--' + dkey.encode('punycode').decode('utf-8') + '.'
    if tmp[0] == '*': newdomain = "*." + newdomain
    return newdomain[0:-1]



#punycode 转中文
def de_punycode(domain):
    tmp = domain.split('.')
    newdomain = ''
    for dkey in tmp:
        if dkey.find('xn--') >=0:
            newdomain += dkey.replace('xn--','').encode('utf-8').decode('punycode') + '.'
        else:
            newdomain += dkey + '.'
    return newdomain[0:-1]

#取计划任务文件路径
def get_cron_path():
    u_file = '/var/spool/cron/crontabs/root'
    if not os.path.exists(u_file):
        file='/var/spool/cron/root'
    else:
        file=u_file
    return file

#加密字符串
def en_crypt(key,strings):
    try:
        if type(strings) != bytes: strings = strings.encode('utf-8')
        from cryptography.fernet import Fernet
        f = Fernet(key)
        result = f.encrypt(strings)
        return result.decode('utf-8')
    except:
        return strings

#解密字符串
def de_crypt(key,strings):
    try:
        if type(strings) != bytes: strings = strings.decode('utf-8')
        from cryptography.fernet import Fernet
        f = Fernet(key)
        result =  f.decrypt(strings).decode('utf-8')
        return result
    except:
        return strings


#获取IP限制列表
def get_limit_ip():
    iplong_list = []
    try:
        from core import cache,app
        iplist = app.config.get('ACCEPT_IP',[])
        if not iplist: return iplong_list

        ikey = 'limit_ip'
        iplong_list = cache.get(ikey)
        if iplong_list: return iplong_list

        iplong_list = []
        for limit_ip in iplist:
            if not limit_ip: continue
            limit_ip = limit_ip.split('-')
            iplong = {}
            iplong['min'] = ip2long(limit_ip[0])
            if len(limit_ip) > 1:
                iplong['max'] = ip2long(limit_ip[1])
            else:
                iplong['max'] = iplong['min']
            iplong_list.append(iplong)

        cache.set(ikey,iplong_list,3600)
    except:pass
    return iplong_list


def is_api_limit_ip(ip_list,client_ip):
    '''
        @name 判断IP是否在限制列表中
        @author hwliang<2022-02-10>
        @param ip_list<list> 限制IP列表
        @param client_ip<string> 客户端IP
        @return bool
    '''
    iplong_list = []
    for limit_ip in ip_list:
        if not limit_ip: continue
        if limit_ip in ['*','all','0.0.0.0','0.0.0.0/0','0.0.0.0/24','0.0.0.0/32']: return True
        limit_ip = limit_ip.split('-')
        iplong = {}
        iplong['min'] = ip2long(limit_ip[0])
        if len(limit_ip) > 1:
            iplong['max'] = ip2long(limit_ip[1])
        else:
            iplong['max'] = iplong['min']
        iplong_list.append(iplong)

    client_ip_long = ip2long(client_ip)
    for limit_ip in iplong_list:
        if client_ip_long >= limit_ip['min'] and client_ip_long <= limit_ip['max']:
            return True
    return False





#检查IP白名单
def check_ip_panel():
    iplong_list = get_limit_ip()
    if not iplong_list: return False
    client_ip = GetClientIp()
    if client_ip in ['127.0.0.1','localhost','::1']: return False
    client_ip_long = ip2long(client_ip)
    for limit_ip in iplong_list:
        if client_ip_long >= limit_ip['min'] and client_ip_long <= limit_ip['max']:
            return False

    errorStr = ReadFile('./template/error2.html')
    return error_not_login(errorStr.format(
        '访问被拒绝',
        '你的请求已经被拒绝',
        '拒绝原因：',
        '1.没有使用正确的IP访问',
        '2.没有使用正确的域名进行访问'
    ),True)

#检查面板域名
def check_domain_panel():
    tmp = GetHost()
    from core import app
    domain = app.config.get('ACCEPT_DOMAIN','')
    if domain:
        client_ip = GetClientIp()
        if client_ip in ['127.0.0.1','localhost','::1']: return False
        if tmp.strip().lower() != domain.strip().lower():
            errorStr = ReadFile('./template/error2.html')
            return error_not_login(errorStr.format(
                '访问被拒绝',
                '你的请求已经被拒绝',
                '拒绝原因：',
                '1.没有使用正确的IP访问',
                '2.没有使用正确的域名进行访问'
            ), True)
    return False

#是否离线模式
def is_local():
    s_file = '{}/data/not_network.pl'.format(get_panel_path())
    return os.path.exists(s_file)


#自动备份面板数据
def auto_backup_panel():
    try:
        panel_paeh = get_panel_path()
        paths = panel_paeh + '/data/not_auto_backup.pl'
        if os.path.exists(paths): return False
        b_path = '{}/panel'.format(get_backup_path())
        day_date = format_date('%Y-%m-%d')
        backup_path = b_path + '/' + day_date
        backup_file = backup_path + '.zip'
        if os.path.exists(backup_path) or os.path.exists(backup_file): return True
        ignore_default = ''
        ignore_system = ''
        max_size = 100 * 1024 * 1024
        if os.path.getsize('{}/data/default.db'.format(panel_paeh)) > max_size:
            ignore_default = 'default.db'
        if os.path.getsize('{}/data/system.db'.format(panel_paeh)) > max_size:
            ignore_system = 'system.db'
        os.makedirs(backup_path,384)
        import shutil
        shutil.copytree(panel_paeh + '/data',backup_path + '/data',ignore = shutil.ignore_patterns(ignore_system,ignore_default))
        shutil.copytree(panel_paeh + '/config',backup_path + '/config')
        shutil.copytree(panel_paeh + '/vhost',backup_path + '/vhost')
        ExecShell("cd {} && zip {} -r {}/".format(b_path,backup_file,day_date))
        ExecShell("chmod -R 600 {path};chown -R root.root {path}".format(path=backup_file))
        if os.path.exists(backup_path): shutil.rmtree(backup_path)

        time_now = time.time() - (86400 * 15)
        for f in os.listdir(b_path):
            if time.mktime(time.strptime(f, "%Y-%m-%d")) < time_now:
                path = b_path + '/' + f
                b_file = path + '.zip'
                if os.path.exists(path):
                    shutil.rmtree(path)
                if os.path.exists(b_file):
                    os.remove(b_file)
    except:pass




#检查端口状态
def check_port_stat(port,localIP = '127.0.0.1'):
    import socket
    temp = {}
    temp['port'] = port
    temp['local'] = True
    try:
        s = socket.socket()
        s.settimeout(0.15)
        s.connect((localIP,port))
        s.close()
    except:
        temp['local'] = False

    result = 0
    if temp['local']: result +=2
    return result


#同步时间
def sync_date():
    tip_file = "/dev/shm/last_sync_time.pl"
    s_time = int(time.time())
    try:
        if os.path.exists(tip_file):
            if s_time - int(readFile(tip_file)) < 60: return False
            os.remove(tip_file)
        time_str = HttpGet(GetConfigValue('home') + '/api/index/get_time')
        new_time = int(time_str)
        time_arr = time.localtime(new_time)
        date_str = time.strftime("%Y-%m-%d %H:%M:%S", time_arr)
        ExecShell('date -s "%s"' % date_str)
        writeFile(tip_file,str(s_time))
        return True
    except:
        if os.path.exists(tip_file): os.remove(tip_file)
        return False



def de_hexb(data):
    if sys.version_info[0] != 2:
        if type(data) == str: data = data.encode('utf-8')
    pdata = base64.b64encode(data)
    if sys.version_info[0] != 2:
        if type(pdata) == str: pdata = pdata.encode('utf-8')
    return binascii.hexlify(pdata)

def en_hexb(data):
    if sys.version_info[0] != 2:
        if type(data) == str: data = data.encode('utf-8')
    result = base64.b64decode(binascii.unhexlify(data))
    if type(result) != str: result = result.decode('utf-8')
    return result

def upload_file_url(filename):
    try:
        if os.path.exists(filename):
            data = ExecShell('/usr/bin/curl https://scanner.baidu.com/enqueue -F archive=@%s' % filename)
            data = json.loads(data[0])
            time.sleep(1)
            import requests
            default_headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36'
            }
            data_list = requests.get(url=data['url'], headers=default_headers, verify=False)
            return (data_list.json())
        else:
            return False
    except:
        return False



def check_tcp(ip,port):
    '''
        @name 使用TCP的方式检测指定IP:端口是否能连接
        @author hwliang<2021-06-01>
        @param ip<string> IP地址
        @param port<int> 端口
        @return bool
    '''
    import socket
    try:
        s = socket.socket()
        s.settimeout(5)
        s.connect((ip.strip(),int(port)))
        s.close()
    except:
        return False
    return True

def url_encode(data):
    if type(data) != str: return data
    if sys.version_info[0] != 2:
        import urllib.parse
        pdata = urllib.parse.quote(data)
    else:
        import urllib
        pdata = urllib.urlencode(data)
    return pdata

def url_decode(data):
    if type(data) != str: return data
    if sys.version_info[0] != 2:
        import urllib.parse
        pdata = urllib.parse.unquote(data)
    else:
        import urllib
        pdata = urllib.urldecode(data)
    return pdata


def unicode_encode(data):
    try:
        if sys.version_info[0] == 2:
            result = unicode(data,errors='ignore')
        else:
            result = data.encode('utf8',errors='ignore')
        return result
    except: return data

def unicode_decode(data,charset = 'utf8'):
    try:
        if sys.version_info[0] == 2:
            result = unicode(data,errors='ignore')
        else:
            result = data.decode('utf8',errors='ignore')
        return result
    except: return data



def get_python_bin():
    bin_file = '{}/pyenv/bin/python3'.format(get_panel_path())
    if os.path.exists(bin_file):
        return bin_file
    return '/usr/bin/python'

def aes_encrypt(data,key):
    import core.include.aes as aes
    if sys.version_info[0] == 2:
        aes_obj = panelAes.aescrypt_py2(key)
        return aes_obj.aesencrypt(data)
    else:
        aes_obj = aes.aescrypt_py3(key)
        return aes_obj.aesencrypt(data)

def aes_decrypt(data,key):
    import core.include.aes as aes
    if sys.version_info[0] == 2:
        aes_obj = panelAes.aescrypt_py2(key)
        return aes_obj.aesdecrypt(data)
    else:
        aes_obj = aes.aescrypt_py3(key)
        return aes_obj.aesdecrypt(data)

#清理大日志文件
def clean_max_log(log_file,max_size = 100,old_line = 100):
    if not os.path.exists(log_file): return False
    max_size = 1024 * 1024 * max_size
    if os.path.getsize(log_file) > max_size:
        try:
            old_body = GetNumLines(log_file,old_line)
            writeFile(log_file,old_body)
        except:
            print(get_error_info())

# 获取系统发行版
def get_linux_distribution():
    distribution = 'ubuntu'
    redhat_file = '/etc/redhat-release'
    if os.path.exists(redhat_file):
        try:
            tmp = readFile(redhat_file).split()[3][0]
            distribution = 'centos{}'.format(tmp)
        except:
            distribution = 'centos7'
    return distribution

def long2ip(ips):
    '''
        @name 将整数转换为IP地址
        @author hwliang<2020-06-11>
        @param ips string(ip地址整数)
        @return ipv4
    '''
    i1 = int(ips / (2 ** 24))
    i2 = int((ips - i1 * ( 2 ** 24 )) / ( 2 ** 16 ))
    i3 = int(((ips - i1 * ( 2 ** 24 )) - i2 * ( 2 ** 16 )) / ( 2 ** 8))
    i4 = int(((ips - i1 * ( 2 ** 24 )) - i2 * ( 2 ** 16 )) - i3 * ( 2 ** 8))
    return "{}.{}.{}.{}".format(i1,i2,i3,i4)

def ip2long(ip):
    '''
        @name 将IP地址转换为整数
        @author hwliang<2020-06-11>
        @param ip string(ipv4)
        @return long
    '''
    ips = ip.split('.')
    if len(ips) != 4: return 0
    iplong = 2 ** 24 * int(ips[0]) + 2 ** 16 * int(ips[1])  + 2 ** 8 * int(ips[2])  + int(ips[3])
    return iplong

def is_local_ip(ip):
    '''
        @name 判断是否为本地(内网)IP地址
        @author hwliang<2021-03-26>
        @param ip string(ipv4)
        @return bool
    '''
    patt = r"^(192\.168|127|10|172\.(16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31))\."
    if re.match(patt,ip): return True
    return False

#提交关键词
def submit_keyword(keyword):
    pdata = {"keyword":keyword}
    httpPost(GetConfigValue('home') + '/api/panel/total_keyword',pdata)

#统计关键词
def total_keyword(keyword):
    import threading
    p = threading.Thread(target=submit_keyword,args=(keyword,))
    # p.setDaemon(True)
    p.start()

#获取debug日志
def get_debug_log():
    from core import request
    return GetClientIp() +':'+ str(request.environ.get('REMOTE_PORT')) + '|' + str(int(time.time())) + '|' + get_error_info()

#获取sessionid
def get_session_id():
    from core import request,app
    session_id =  request.cookies.get(app.config['SESSION_COOKIE_NAME'],'')
    if not re.findall(r"^([\w\.-]{64,64})$",session_id):
        return GetRandomString(64)
    return session_id




def package_path_append(path):
    if not path in sys.path:
        sys.path.insert(0,path)


def rep_sys_path():
    sys_path = []
    for p in sys.path:
        if p in sys_path: continue
        sys_path.append(p)
    sys.path = sys_path


def get_ssh_port():
    '''
        @name 获取本机SSH端口
        @author hwliang<2020-08-07>
        @return int
    '''
    s_file = '/etc/ssh/sshd_config'
    conf = readFile(s_file)
    if not conf: conf = ''
    port_all = re.findall(r".*Port\s+[0-9]+",conf)
    ssh_port = 22
    for p in port_all:
        rep = r"^\s*Port\s+([0-9]+)\s*"
        tmp1 = re.findall(rep,p)
        if tmp1:
            ssh_port = int(tmp1[0])

    return ssh_port

def set_error_num(key,empty = False,expire=3600):
    '''
        @name 设置失败次数(每调用一次+1)
        @author hwliang<2020-08-21>
        @param key<string> 索引
        @param empty<bool> 是否清空计数
        @param expire<int> 计数器生命周期(秒)
        @return bool
    '''
    from core import cache
    key = md5(key)
    num = cache.get(key)
    if not num:
        num = 0
    else:
        if empty:
            cache.delete(key)
            return True
    cache.set(key,num + 1,expire)
    return True

def get_error_num(key,limit=False):
    '''
        @name 获取失败次数
        @author hwliang<2020-08-21>
        @param key<string> 索引
        @param limit<False or int> 如果为False，则直接返回失败次数，否则与失败次数比较，若大于失败次数返回True，否则返回False
        @return int or bool
    '''
    from core import cache
    key = md5(key)
    num = cache.get(key)
    if not num: num = 0
    if not limit:
        return num
    if limit > num:
        return True
    return False


def get_menus():
    '''
        @name 获取菜单列表
        @author hwliang<2020-08-31>
        @return list
    '''
    from core import session
    data = json.loads(ReadFile('config/menu.json'))
    hide_menu = ReadFile('config/hide_menu.json')
    debug = session.get('debug')
    if hide_menu:
        hide_menu = json.loads(hide_menu)
        show_menu = []
        for i in range(len(data)):
            if data[i]['id'] in hide_menu: continue
            if data[i]['id'] == "memuAxterm":
                if debug: continue
            show_menu.append(data[i])
        data = show_menu
        del(hide_menu)
        del(show_menu)
    menus = sorted(data, key=lambda x: x['sort'])
    return menus


#取CURL路径
def get_curl_bin():
    '''
        @name 取CURL执行路径
        @author hwliang<2020-09-01>
        @return string
    '''
    c_bin = ['/usr/local/curl2/bin/curl','/usr/local/curl/bin/curl','/usr/bin/curl']
    for cb in c_bin:
        if os.path.exists(cb): return cb
    return 'curl'

def run_thread(fun,args = (),daemon=False):
    '''
        @name 使用线程执行指定方法
        @author hwliang<2020-10-27>
        @param fun {def} 函数对像
        @param args {tuple} 参数元组
        @param daemon {bool} 是否守护线程
        @return bool
    '''
    import threading
    p = threading.Thread(target=fun,args=args)
    p.setDaemon(daemon)
    p.start()
    return True


def get_mac_address():
    import uuid
    mac=uuid.UUID(int = uuid.getnode()).hex[-12:]
    return ":".join([mac[e:e+2] for e in range(0,11,2)])


flask_version_pattern = re.compile(r'^(?:[2-9]|[1-9]\d+)\.(?:[2-9]|[1-9]\d+)\.\d+$')
def send_file(data, fname='', mimetype = ''):
    '''
        @name 以文件流的形式返回
        @author heliang<2020-10-27>
        @param data {bytes|string} 文件数据或路径
        @param mimetype {string} 文件类型
        @param fname {string} 文件名
        @return Response
    '''
    from io import BytesIO,StringIO
    import flask

    if not isinstance(data, BytesIO):
        d_type = type(data)
        if d_type == bytes:
            fp = BytesIO(data)
        else:
            if len(data) < 128:
                if os.path.exists(data):
                    fp = data
                    if not fname:
                        fname = os.path.basename(fname)
                else:
                    fp = StringIO(data)
            else:
                fp = StringIO(data)
    else:
        fp = data

    if not mimetype: mimetype = "application/octet-stream"
    if not fname: fname = 'doan.txt'

    if flask_version_pattern.match(flask.__version__) is not None:
        return flask.send_file(fp,
                    mimetype=mimetype,
                    as_attachment=True,
                    etag=True,
                    conditional=True,
                    download_name=fname,
                    max_age=0)

    return flask.send_file(fp,
                    mimetype=mimetype,
                    as_attachment=True,
                    add_etags=True,
                    conditional=True,
                    attachment_filename=fname,
                    cache_timeout=0)

def gen_password(length=8,chars=string.ascii_letters+string.digits):
    return ''.join([choice(chars) for i in range(length)])

def get_ipaddress():
    '''
        @name 获取本机IP地址
        @author hwliang<2020-11-24>
        @return list
    '''
    ipa_tmp = ExecShell("ip a |grep inet|grep -v inet6|grep -v 127.0.0.1|grep -v 'inet 192.168.'|grep -v 'inet 10.'|awk '{print $2}'|sed 's#/[0-9]*##g'")[0].strip()
    iplist = ipa_tmp.split('\n')
    return iplist


# 名称输入系列化
def xssdecode(text):
    try:
        cs = {"&quot":'"',"&#x27":"'"}
        for c in cs.keys():
            text = text.replace(c,cs[c])

        str_convert = text
        if sys.version_info[0] == 3:
            import html
            text2 = html.unescape(str_convert)
        else:
            text2 = cgi.unescape(str_convert)
        return text2
    except:
        return text


def get_root_domain(domain_name):
			'''
				@name 根据域名查询根域名和记录值
				@author cjxin<2020-12-17>
				@param domain {string} 被验证的根域名
				@return void
			'''
			top_domain_list = ['.ac.cn', '.ah.cn', '.bj.cn', '.com.cn', '.cq.cn', '.fj.cn', '.gd.cn',
								'.gov.cn', '.gs.cn', '.gx.cn', '.gz.cn', '.ha.cn', '.hb.cn', '.he.cn',
								'.hi.cn', '.hk.cn', '.hl.cn', '.hn.cn', '.jl.cn', '.js.cn', '.jx.cn',
								'.ln.cn', '.mo.cn', '.net.cn', '.nm.cn', '.nx.cn', '.org.cn','.cn.com']
			old_domain_name = domain_name
			top_domain = "."+".".join(domain_name.rsplit('.')[-2:])
			new_top_domain = "." + top_domain.replace(".", "")
			is_tow_top = False
			if top_domain in top_domain_list:
				is_tow_top = True
				domain_name = domain_name[:-len(top_domain)] + new_top_domain

			if domain_name.count(".") > 1:
				zone, middle, last = domain_name.rsplit(".", 2)
				if is_tow_top:
					last = top_domain[1:]
				root = ".".join([middle, last])
			else:
				zone = ""
				root = old_domain_name
			return root, zone

def query_dns(domain,dns_type = 'A',is_root = False):
    '''
        @name 查询域名DNS解析
        @author cjxin<2020-12-17>
        @param domain {string} 被验证的根域名
        @param dns_type {string} dns记录
        @param is_root {bool} 是否查询根域名
        @return void
    '''
    try:
        import dns.resolver
    except :
        os.system('{} -m pip install dnspython'.format(get_python_bin()))
        import dns.resolver

    if is_root: domain,zone = get_root_domain(domain)
    try:
        ret = dns.resolver.query(domain, dns_type)
        data = []
        for i in ret.response.answer:
            for j in i.items:
                tmp = {}
                tmp['flags'] = j.flags
                tmp['tag'] = j.tag.decode()
                tmp['value'] = j.value.decode()
                data.append(tmp)
        return data
    except :
        return False

#取通用对象
re_key_match = re.compile(r'^[\w\s\[\]\-]+$')
re_key_match2 = re.compile(r'^__[\w\s\-]+__$')
class dict_obj:
    def __contains__(self, key):
        return getattr(self,key,None)
    def __setitem__(self, key, value):
        if key in ['get','get_items','exists','__contains__','__setitem__','__getitem__','__delitem__','__delattr__','__setattr__','__getattr__','__class__']:
            raise PanelError("错误的字段名")
        if not re_key_match.match(key) or re_key_match2.match(key):
            raise PanelError("错误的字段名")
        setattr(self,key,value)
    def __getitem__(self, key): return getattr(self,key,None)
    def __delitem__(self,key): delattr(self,key)
    def __delattr__(self, key): delattr(self,key)
    def get_items(self): return self
    def exists(self,keys):
        return exists_args(keys,self)
    def get(self,key,default='',format='',limit = []):
        '''
            @name 获取指定参数
            @param key<string> 参数名称，允许在/后面限制参数格式，请参考参数值格式(format)
            @param default<string> 默认值，默认空字符串
            @param format<string>  参数值格式(int|str|port|float|json|xss|path|url|ip|ipv4|ipv6|letter|mail|phone|正则表达式|>1|<1|=1)，默认为空
            @param limit<list> 限制参数值内容
            @param return mixed
        '''
        if key.find('/') != -1:
            key,format = key.split('/')

        result = getattr(self, key, None)

        if result is None:
            return default

        if isinstance(result,str): result = result.strip()
        if format:
            if format in ['str','string','s']:
                result = str(result)
            elif format in ['int','d']:
                try:
                    result = int(result)
                except:
                    raise ValueError("参数：{}，要求int类型数据".format(key))
            elif format in ['float','f']:
                try:
                    result = float(result)
                except:
                    raise ValueError("参数：{}，要求float类型数据".format(key))
            elif format in ['json','j']:
                try:
                    result = json.loads(result)
                except:
                    raise ValueError("参数：{}, 要求JSON字符串".format(key))
            elif format in ['xss','x']:
                result = xssencode(result)
            elif format in ['path','p']:
                if not path_safe_check(result):
                    raise ValueError("参数：{}，要求正确的路径格式".format(key))
                result = result.replace('//','/')
            elif format in ['url','u']:
                regex = re.compile(
                     r'^(?:http|ftp)s?://'
                     r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|'
                     r'localhost|'
                     r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'
                     r'(?::\d+)?'
                     r'(?:/?|[/?]\S+)$', re.IGNORECASE)
                if not re.match(regex,result):
                    raise ValueError('参数：{}，要求正确的URL格式'.format(key))
            elif format in ['ip','ipaddr','i','ipv4','ipv6']:
                if format == 'ipv4':
                    if not is_ipv4(result):
                        raise ValueError('参数：{}，要求正确的ipv4地址'.format(key))
                elif format == 'ipv6':
                    if not is_ipv6(result):
                        raise ValueError('参数：{}，要求正确的ipv6地址'.format(key))
                else:
                    if not is_ipv4(result) and not is_ipv6(result):
                        raise ValueError('参数：{}，要求正确的ipv4/ipv6地址'.format(key))
            elif format in ['w','letter']:
                if not re.match(r'^\w+$',result):
                    raise ValueError('参数：{}，要求只能是英文字母或数据组成'.format(key))
            elif format in ['email','mail','m']:
                if not re.match(r"^.+\@(\[?)[a-zA-Z0-9\-\.]+\.([a-zA-Z]{2,3}|[0-9]{1,3})(\]?)$",result):
                    raise ValueError("参数：{}，要求正确的邮箱地址格式".format(key))
            elif format in ['phone','mobile','p']:
                if not re.match("^[0-9]{11,11}$",result):
                    raise ValueError("参数：{}，要求手机号码格式".format(key))
            elif format in ['port']:
                result_port = int(result)
                if result_port > 65535 or result_port < 0:
                    raise ValueError("参数：{}，要求端口号为0-65535".format(key))
                result = result_port
            elif re.match(r"^[<>=]\d+$",result):
                operator = format[0]
                length = int(format[1:].strip())
                result_len = len(result)
                error_obj = ValueError("参数：{}，要求长度为{}".format(key,format))
                if operator == '=':
                    if result_len != length:
                        raise error_obj
                elif operator == '>':
                    if result_len < length:
                        raise error_obj
                else:
                    if result_len > length:
                        raise error_obj
            elif format[0] in ['^','(','[','\\','.'] or format[-1] in ['$',')',']','+','}']:
                if not re.match(format,result):
                    raise ValueError("指定参数格式不正确, {}:{}".format(key,format))

        if limit:
            if not result in limit:
                raise ValueError("指定参数值范围不正确, {}:{}".format(key,limit))
        return result

#实例化定目录下的所有模块
class get_modules:

    def __contains__(self, key):
        return self.get_attr(key)

    def __setitem__(self, key, value):
        setattr(self,key,value)

    def get_attr(self,key):
        '''
            尝试获取模块，若为字符串，则尝试实例化模块，否则直接返回模块对像
        '''
        res = getattr(self,key)
        if isinstance(res,str):
            try:
                tmp_obj = __import__(key)
                setattr(self,key,tmp_obj)
                return tmp_obj
            except:
                raise Exception(get_error_info())
        return res

    def __getitem__(self, key):
        return self.get_attr(key)

    def __delitem__(self,key):
        delattr(self,key)

    def __delattr__(self, key):
        delattr(self,key)

    def get_items(self):
        return self

    def __init__(self,path = "class",limit = None):
        '''
            @name 加载指定目录下的模块
            @author hwliang<2020-08-03>
            @param path<string> 指定目录，可指定绝对目录，也可指定相对于/www/server/panel的相对目录 默认加载class目录
            @param limit<string/list/tuple> 指定限定加载的模块名称，默认加载path目录下的所有模块
            @param object

            @example
                p = get_modules('class')
                if 'public' in p:
                    md5_str = p.public.md5('test')
                    md5_str = p['public'].md5('test')
                    md5_str = getattr(p['public'],'md5')('test')
                else:
                    print(p.__dict__)
        '''
        os.chdir(get_panel_path())
        exp_files = ['__init__.py','__pycache__']
        if not path in sys.path:
            sys.path.insert(0,path)
        for fname in os.listdir(path):
            if fname in exp_files: continue
            filename = '/'.join([path,fname])
            if os.path.isfile(filename):
                if not fname[-3:] in ['.py','.so']: continue
                mod_name = fname[:-3]
            else:
                c_file = '/'.join((filename,'__init__.py'))
                if not os.path.exists(c_file):
                    continue
                mod_name = fname

            if limit:
                if not isinstance(limit,list) and not isinstance(limit,tuple):
                    limit = (limit,)
                if not mod_name in limit:
                    continue

            setattr(self,mod_name,mod_name)



#获取服务器IP
def get_ip():
    iplist_file = '{}/data/iplist.txt'.format(get_panel_path())
    if os.path.exists(iplist_file):
        data=ReadFile(iplist_file)
        return data.strip()
    else:return '127.0.0.1'

#获取服务器内网Ip
def get_local_ip():
    try:
        ret=ExecShell("ip addr | grep -E -o '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | grep -E -v \"^127\.|^255\.|^0\.\" | head -n 1")
        local_ip=ret[0].strip()
        return local_ip
    except:return '127.0.0.1'

def check_ip_white(path,ip):
    if os.path.exists(path):
        try:
            path_json=json.loads(ReadFile(path))
        except:
            WriteFile(path,'[]')
            return False
        if ip in path_json:return True
        else:return False
    else:
        return False

def get_sys_path():
    '''
        @name 关键目录
        @author hwliang<2021-06-11>
        @return tuple
    '''
    a = ['/www','/usr','/','/dev','/home','/media','/mnt','/opt','/tmp','/var']
    c = ['/www/.Recycle_bin/','/www/backup/','/www/php_session/','/www/wwwlogs/','/www/server/','/etc/','/usr/','/var/','/boot/','/proc/','/sys/','/tmp/','/root/','/lib/','/bin/','/sbin/','/run/','/lib64/','/lib32/','/srv/']
    return a,c


def check_site_path(site_path):
    '''
        @name 检查网站根目录是否为系统关键目录
        @author hwliang<2021-05-31>
        @param site_path<string> 网站根目录全路径
        @return bool
    '''
    whites = ['/www/server/tomcat','/www/server/stop','/www/server/phpmyadmin']
    for w in whites:
        if site_path.find(w) == 0: return True
    a,error_paths = get_sys_path()
    site_path = site_path.strip()
    if site_path[-1] == '/': site_path = site_path[:-1]
    if site_path in a:
        return False
    site_path += '/'
    for ep in error_paths:
        if site_path.find(ep) == 0: return False
    return True

def is_debug():
    debug_file = "{}/data/debug.pl".format(get_panel_path())
    return os.path.exists(debug_file)


class PanelError(Exception):
    '''
        @name 宝塔通用异常对像
        @author hwliang<2021-06-25>
    '''
    def __init__(self, value):
        self.value = value

    def __str__(self):
        return ("面板运行时发生错误: {}".format(str(self.value)))


def get_sysbit():
    '''
        @name 获取操作系统位数
        @author hwliang<2021-07-07>
        @return int 32 or 64
    '''
    import struct
    return struct.calcsize('P') * 8

def get_setup_path():
    '''
        @name 获取安装路径
        @author hwliang<2021-07-22>
        @return string
    '''
    return '/www/server'

def get_panel_path():
    '''
        @name 取面板根目录
        @author hwliang<2021-07-14>
        @return string
    '''
    return '{}/bt-monitor'.format(get_setup_path())

def get_plugin_path(plugin_name = None):
    '''
        @name 取指定插件目录
        @author hwliang<2021-07-14>
        @param plugin_name<string> 插件名称 不传则返回插件根目录
        @return string
    '''

    root_path = "{}/plugin".format(get_panel_path())
    if not plugin_name: return root_path
    return "{}/{}".format(root_path,plugin_name)

def get_modules_path():
    '''
        @name 取类库所在路径
        @author hwliang<2021-07-14>
        @return string
    '''
    return "{}/modules".format(get_panel_path())


def get_backup_path():
    '''
        @name 取备份目录
        @author hwliang<2021-07-14>
        @return string
    '''
    default_backup_path = '/www/backup'
    backup_path = M('config').where("id=?",(1,)).getField('backup_path')
    if not backup_path: return default_backup_path
    if os.path.exists(backup_path): return backup_path
    return default_backup_path


def read_config(config_name,ext_name = 'json'):
    '''
        @name 读取指定配置文件
        @author hwliang<2021-07-14>
        @param config_name<string> 配置文件名称(不含扩展名)
        @param ext_name<string> 配置文件扩展名，默认为json
        @return string 如果发生错误，将抛出PanelError异常
    '''
    config_file = "{}/config/{}.{}".format(get_panel_path(),config_name,ext_name)
    if not os.path.exists(config_file):
        raise PanelError('指定配置文件{} 不存在'.format(config_name))

    config_str = readFile(config_file)
    if ext_name == 'json':
        try:
            config_body = json.loads(config_str)
        except Exception as ex:
            raise PanelError('配置文件不是标准的可解析JSON内容!\n{}'.format(ex))
        return config_body
    return config_str

def save_config(config_name,config_body,ext_name = 'json'):
    '''
        @name 保存配置文件
        @author hwliang<2021-07-14>
        @param config_name<string> 配置文件名称(不含扩展名)
        @param config_body<mixed> 被保存的内容, ext_name为json，请传入可解析为json的参数类型，如list,dict,int,str等
        @param ext_name<string> 配置文件扩展名，默认为json
        @return string 如果发生错误，将抛出PanelError异常
    '''

    config_file = "{}/config/{}.{}".format(get_panel_path(),config_name,ext_name)
    if ext_name == 'json':
        try:
            config_body = json.dumps(config_body)
        except Exception as ex:
            raise PanelError('配置内容无法被转换为json格式!\n{}'.format(ex))

    return writeFile(config_file,config_body)

def get_config_value(config_name,key,default='',ext_name='json'):
    '''
        @name 获取指定配置文件的指定配置项
        @author hwliang<2021-07-14>
        @param config_name<string> 配置文件名称(不含扩展名)
        @param key<string> 配置项
        @param default<mixed> 获不存在则返回的默认值，默认为空字符串
        @param ext_name<string> 配置文件扩展名，默认为json
        @return mixed 如果发生错误，将抛出PanelError异常
    '''
    config_data = read_config(config_name,ext_name)
    return config_data.get(key,default)

def set_config_value(config_name,key,value,ext_name='json'):
    '''
        @name 设置指定配置文件的指定配置项
        @author hwliang<2021-07-14>
        @param config_name<string> 配置文件名称(不含扩展名)
        @param key<string> 配置项
        @param value<mixed> 配置值
        @param ext_name<string> 配置文件扩展名，默认为json
        @return mixed  如果发生错误，将抛出PanelError异常
    '''
    config_data = read_config(config_name,ext_name)
    config_data[key] = value
    return save_config(config_name,config_data,ext_name)


def return_data(status, data = {}, status_code=None,error_msg = None):
    '''
        @name 格式化响应内容
        @author hwliang<2021-07-14>
        @param status<bool> 状态
        @param data<mixed> 响应数据
        @param status_code<int> 状态码
        @param error_msg<string> 错误消息内容
        @return dict

    '''
    if status_code == None:
        status_code = 1 if status else 0
    if error_msg == None:
        error_msg = '' if status else data

    if not status and data == error_msg: data = ''


    result = {
                'status':status,
                "status_code":status_code,
                'error_msg':str(error_msg),
                'data':data
            }
    return result


def return_error(error_msg,status_code = -1,data = []):
    '''
        @name 格式化错误响应内容
        @author hwliang<2021-07-15>
        @param error_msg<string> 错误消息
        @param status_code<int> 状态码，默认为-1
        @param data<mixed> 响应数据
        @return dict
    '''
    return return_data(False,data,status_code,str(error_msg))


def error(error_msg,status_code = -1,data = []):
    '''
        @name 格式化错误响应内容
        @author hwliang<2021-07-15>
        @param error_msg<string> 错误消息
        @param status_code<int> 状态码，默认为-1
        @param data<mixed> 响应数据
        @return dict
    '''
    return return_error(error_msg,status_code,data)

def success(data = [],status_code = 1,error_msg = ''):
    '''
        @name 格式化成功响应内容
        @author hwliang<2021-07-15>
        @param data<mixed> 响应数据
        @param status_code<int> 状态码，默认为0
        @return dict
    '''
    return return_data(True,data,status_code,error_msg)


def return_status_code(status_code,format_body,data = []):
    '''
        @name 按状态码返回
        @author hwliang<2021-07-15>
        @param status_code<int> 状态码
        @param format_body<string> 错误内容
        @param data<mixed> 响应数据
        @return dict
    '''
    error_msg = get_config_value('status_code',str(status_code))
    if not error_msg: raise PanelError('指定状态码不存在!')
    return return_data(error_msg[0],data,status_code,error_msg[1].format(format_body))


def to_dict_obj(data):
    '''
        @name 将dict转换为dict_obj
        @author hwliang<2021-07-15>
        @param data<dict> 要被转换的数据
        @return dict_obj
    '''
    if not isinstance(data,dict):
        raise PanelError('错误的数据类型，只支持将dict转换为dict_obj')
    pdata = dict_obj()
    for key in data.keys():
        pdata[key] = data[key]
    return pdata

def get_script_object(filename):
    '''
        @name 从脚本文件获取对像
        @author hwliang<2021-07-19>
        @param filename<string> 文件名
        @return object
    '''
    _obj =  sys.modules.get(filename,None)
    if _obj: return _obj
    from types import ModuleType
    _obj = sys.modules.setdefault(filename, ModuleType(filename))
    _code = readFile(filename)
    _code_object = compile(_code,filename, 'exec')
    _obj.__file__ = filename
    _obj.__package__ = ''
    exec(_code_object, _obj.__dict__)
    return _obj




def get_session_timeout():
    '''
        @name 获取session过期时间
        @author hwliang<2021-07-28>
        @return int
    '''
    from core import cache
    skey = 'session_timeout'
    session_timeout = cache.get(skey)
    if not session_timeout == None: return session_timeout

    sess_out_path = '{}/data/session_timeout.pl'.format(get_panel_path())
    session_timeout = 86400
    if not os.path.exists(sess_out_path):
        return session_timeout
    try:
        session_timeout = int(readFile(sess_out_path))
    except:
        session_timeout = 86400
    cache.set(skey,session_timeout,3600)
    return session_timeout


def get_login_token_auth():
    '''
        @name 获取登录token
        @author hwliang<2021-07-28>
        @return string
    '''
    from core import cache
    skey = 'login_token'
    login_token = cache.get(skey)
    if not login_token == None: return login_token

    login_token_file = '{}/data/login_token.pl'.format(get_panel_path())
    login_token = '1234567890'
    if not os.path.exists(login_token_file):
        return login_token
    login_token = readFile(login_token_file)
    cache.set(skey,login_token,3600)
    return login_token


def listen_ipv6():
    '''
        @name 是否监听ipv6
        @author hwliang<2021-08-12>
        @return bool
    '''
    ipv6_file = '{}/data/ipv6.pl'.format(get_panel_path())
    return os.path.exists(ipv6_file)

def get_panel_log_file(daliy = False):
    '''
        @name 获取panel日志文件
        @author hwliang<2021-08-12>
        @param daliy<?bool> 按天记录[可选]
        @return string
    '''
    log_file = 'error'

    if daliy:
        if not os.path.exists('{}/logs/debug'.format(get_panel_path())):
            os.makedirs('{}/logs/debug'.format(get_panel_path()), 0o755)
        log_file = 'debug/{}'.format(time.strftime('%Y-%m-%d'))

    return "{}/logs/{}.log".format(get_panel_path(), log_file)


def print_log(*_info, _level='DEBUG'):
    '''
        @name 写入日志
        @author hwliang<2021-08-12>
        @param _info<string> 要写入到日志文件的信息
        @param _level<string> 日志级别
        @return void
    '''
    import core.include.monitor_enums as monitor_enums

    # 低于预设级别时，不写入日志
    if monitor_enums.LOG_LEVEL__MAP.get(_level.lower(), monitor_enums.LOG_LEVEL__DEBUG) < monitor_enums.LOG_LEVEL__CUR:
        return False

    log_body = "[{}][{}] - {}\n".format(format_date(), _level.upper(), '\n'.join(map(lambda x: '{}'.format(x), _info)))
    return WriteFile(get_panel_log_file(True), log_body, 'a+')



def to_date(format = "%Y-%m-%d %H:%M:%S",times = None):
    '''
        @name 格式时间转时间戳
        @author hwliang<2021-08-17>
        @param format<string> 时间格式
        @param times<date> 时间
        @return int
    '''
    if times:
        if isinstance(times,int): return times
        if isinstance(times,float): return int(times)
        if re.match("^\d+$",times): return int(times)
    else: return 0
    ts = time.strptime(times, "%Y-%m-%d %H:%M:%S")
    return time.mktime(ts)


def get_glibc_version():
    '''
        @name 获取glibc版本
        @author hwliang<2021-08-17>
        @return string
    '''
    try:
        cmd_result = ExecShell("ldd --version")[0]
        if not cmd_result: return ''
        glibc_version = cmd_result.split("\n")[0].split()[-1]
    except:
        return ''
    return glibc_version

def error_not_login(e = None,_src = None):
    '''
        @name 未登录时且未输入正确的安全入口时的响应
        @author hwliang<2021-12-16>
        @return Response
    '''
    from core import Response,render_template,redirect

    try:
        abort_code = read_config('abort')
        if not abort_code in [None,1,0,'0','1']:
            if abort_code == 404: return error_404(e)
            if abort_code == 403: return error_403(e)
            return Response(status=int(abort_code))
    except:
        pass

    if e in ['/login']:
        return redirect(e)

    if _src:
        return e
    else:
        return render_template('autherr.html')

def error_403(e):
    from core import Response,session
    if not session.get('login',None): return error_not_login()
    errorStr = '''<html>
<head><title>403 Forbidden</title></head>
<body>
<center><h1>403 Forbidden</h1></center>
<hr><center>nginx</center>
</body>
</html>'''
    headers = {
        "Content-Type": "text/html"
    }
    return Response(errorStr, status=403, headers=headers)

def error_404(e):
    from core import Response,session
    if not session.get('login',None): return error_not_login()
    errorStr = '''<html>
<head><title>404 Not Found</title></head>
<body>
<center><h1>404 Not Found</h1></center>
<hr><center>nginx</center>
</body>
</html>'''
    headers = {
        "Content-Type": "text/html"
    }
    return Response(errorStr, status=404, headers=headers)




def get_full_session_file():
    '''
        @name 获取临时SESSION文件
        @author hwliang<2021-12-28>
        @return string
    '''
    from core import app
    full_session_key = app.config['SESSION_KEY_PREFIX'] + get_session_id()
    sess_path = get_panel_path() + '/data/session/'
    return sess_path + '/' + md5(full_session_key)



def install_mysql_client():
    '''
        @name 安装mysql客户端
        @author hwliang<2022-01-14>
        @return void
    '''
    if os.path.exists('/usr/bin/yum'):
        os.system("yum install mariadb -y")
        if not os.path.exists('/usr/bin/mysql'):
            os.system("yum reinstall mariadb -y")
    elif os.path.exists('/usr/bin/apt-get'):
        os.system('apt-get install mariadb-client -y')
        if not os.path.exists('/usr/bin/mysql'):
            os.system('apt-get reinstall mariadb-client* -y')

def get_mysqldump_bin():
    '''
        @name 获取mysqldump路径
        @author hwliang<2022-01-14>
        @return string
    '''
    bin_files = [
        '{}/mysql/bin/mysqldump'.format(get_setup_path()),
        '/usr/bin/mysqldump',
        '/usr/local/bin/mysqldump',
        '/usr/sbin/mysqldump',
        '/usr/local/sbin/mysqldump'
    ]

    for bin_file in bin_files:
        if os.path.exists(bin_file):
            return bin_file

    install_mysql_client()

    for bin_file in bin_files:
        if os.path.exists(bin_file):
            return bin_file

    return bin_files[0]

def get_mysql_bin():
    '''
        @name 获取mysql路径
        @author hwliang<2022-01-14>
        @return string
    '''
    bin_files = [
        '{}/mysql/bin/mysql'.format(get_setup_path()),
        '/usr/bin/mysql',
        '/usr/local/bin/mysql',
        '/usr/sbin/mysql',
        '/usr/local/sbin/mysql'
    ]

    for bin_file in bin_files:
        if os.path.exists(bin_file):
            return bin_file

    install_mysql_client()

    for bin_file in bin_files:
        if os.path.exists(bin_file):
            return bin_file
    return bin_files[0]

def error_conn_cloud(text):
    '''
        @name 连接云端失败
        @author hwliang<2021-12-18>
        @return void
    '''
    code_msg = ''
    if text.find("502 Bad Gateway") != -1:
        code_msg = '502 Bad Gateway'
    if text.find("504 Bad Gateway") != -1:
        code_msg = '504 Bad Gateway'
    elif text.find("Connection refused") != -1:
        code_msg = 'Connection refused'
    elif text.find("Connection timed out") != -1:
        code_msg = 'Connection timed out'
    elif text.find("Connection reset by peer") != -1:
        code_msg = 'Connection reset by peer'
    elif text.find("Name or service not known") != -1:
        code_msg = 'Name or service not known'
    elif text.find("No route to host") != -1:
        code_msg = 'No route to host'
    elif text.find("No such file or directory") != -1:
        code_msg = 'No such file or directory'
    elif text.find("404 Not Found") != -1:
        code_msg = '404 Not Found'
    elif text.find("403 Forbidden") != -1:
        code_msg = '403 Forbidden'
    elif text.find("401 Unauthorized") != -1:
        code_msg = '401 Unauthorized'
    elif text.find("400 Bad Request") != -1:
        code_msg = '400 Bad Request'
    elif text.find("Remote end closed connection without response") != -1:
        code_msg = 'Remote end closed connection'
    err_template_file = '{}/BTPanel/templates/default/error_connect.html'.format(get_panel_path())
    msg = readFile(err_template_file)
    msg = msg.format(code=code_msg)
    return PanelError(msg)

def get_mountpoint_list():
    '''
        @name 获取挂载点列表
        @author hwliang<2021-12-18>
        @return list
    '''
    import psutil
    mount_list = []
    for mount in psutil.disk_partitions():
        mountpoint = mount.mountpoint if mount.mountpoint[-1] == '/' else mount.mountpoint + '/'
        mount_list.append(mountpoint)
    # 根据挂载点字符长度排序
    mount_list.sort(key = lambda i:len(i),reverse=True)
    return mount_list

def get_path_in_mountpoint(path):
    '''
        @name 获取文件或目录目录所在挂载点
        @author hwliang<2022-03-30>
        @param path<string> 文件或目录路径
        @return string
    '''
    # 判断是否是绝对路径
    if path.find('./') != -1 or path[0] != '/': raise PanelError("不能使用相对路径")
    if not path: raise PanelError("文件或目录路径不能为空")

    # 在目录尾加/
    if os.path.isdir(path):
        path = path if path[-1] == '/' else path + '/'

    # 匹配挂载点
    mount_list = get_mountpoint_list()
    for mountpoint in mount_list:
        if path.startswith(mountpoint):
            return mountpoint

    # 没有匹配到挂载点
    return '/'

def set_module_logs(mod_name, fun_name, count=1):
    """
    @模块使用次数
    @mod_name 模块名称
    @fun_name 函数名
    """
    import datetime
    data = {}
    path = '{}/data/mod_log.json'.format(get_panel_path())
    if os.path.exists(path):
        try:
            data = json.loads(readFile(path))
        except:
            pass

    key = datetime.datetime.now().strftime("%Y-%m-%d")
    if not key in data: data[key] = {}

    if not mod_name in data[key]:
        data[key][mod_name] = {}

    if not fun_name in data[key][mod_name]:
        data[key][mod_name][fun_name] = 0

    data[key][mod_name][fun_name] += count

    writeFile(path, json.dumps(data))
    return True


def get_admin_path():
    '''
        @name 获取安全入口路径
        @author hwliang
        @return string
    '''
    default_path = '/login'
    admin_path = get_config_value('config','admin_path', None)
    # admin_path_file = '{}/data/AdminPath.pl'.format(get_panel_path())
    # if not os.path.exists(admin_path_file):
    #    return default_path
    # admin_path = readFile(admin_path_file).strip()

    if not admin_path:
        return default_path

    return admin_path

def response(status, content='', http_status=200):
    '''
        @name 返回响应
        @author hwliang
        @param status<bool> 状态
        @param content<string> 响应内容
        @param status<int> 响应状态码
        @return void
    '''
    from flask import Response
    headers = {}
    mimetype = 'application/json'
    content_type = 'application/json; charset=utf-8'
    res = json.dumps(return_data(status, content),ensure_ascii=False)

    headers['Content-Type'] = content_type
    headers['Content-Length'] = len(res)
    return Response(res, status=http_status, headers=headers, mimetype=mimetype)


def reload():
    '''
        @name 重启服务
        @author hwliang
        @return void
    '''
    # run_file = '{}/BT-MONITOR'.format(get_panel_path())
    run_file = '{}/init.sh'.format(get_panel_path())
    if os.path.exists(run_file):
        set_mode(run_file, '700')
    # ExecShell("nohup {} >/dev/null 2>&1 &".format(run_file))
    ExecShell("bash {} reload > /dev/null 2>&1 &".format(run_file))


def set_server_ws(ws,server_id):
    '''
        @name 缓存ws对象
        @author hwliang
        @param ws<object> ws对象
        @param server_id<int> 服务器id
        @return void
    '''
    from core import servers_ws

    # print('--current ws connections: {}'.format(servers_ws))

    if server_id in servers_ws:
        if servers_ws[server_id].connected:
            try:
                servers_ws[server_id].close()
            except BaseException as e:
                # 记录异常堆栈
                print_exc_stack(e)

        del(servers_ws[server_id])

    servers_ws[server_id] = ws


def get_server_ws(server_id):
    '''
        @name 获取ws对象
        @author hwliang
        @param server_id<int> 服务器id
        @return object
    '''
    from core import servers_ws
    
    # print(servers_ws)
    return servers_ws.get(server_id,None)


def send_agent_msg(server_id, module, action, callback=None, pdata={}, timeout=60):
    '''
        @name 发送消息给agent
        @author hwliang
        @param server_id<int> 服务器id
        @param msg<string> 消息内容
        @return void
    '''
    ws = get_server_ws(server_id)

    # print_log('--send msg to agent[{}] {}'.format(server_id, ws))

    if not ws:
        return False  # 未连接

    if callback is None:
        callback = 'recv/{}/{}/{}/{}/{}'.format(module, action, server_id, int(time.time() * 1000000), GetRandomString(16))

    data = {
        'module': module,
        'action': action,
        'callback': callback,
        'pdata': pdata,
    }

    pdata = agent_encrypt(server_id, data)
    try:
        from core.loader import ws_send_help
        #  发送消息
        if not ws_send_help(ws, pdata):
            raise Exception('WS已断开连接')

        # ws.send(pdata)
    except BaseException as e:
        # 中断连接？
        from core import servers_ws
        del (servers_ws[server_id],)

        print_exc_stack(e)

        # print_log('--send msg to agent[{}] failed: connections maybe disconnected'.format(server_id))

        return False

    # 获取响应消息
    from core import cache
    n = 0
    result = "没有响应"
    timeout_n = timeout * 20
    while n < timeout_n:
        time.sleep(0.05)
        result = cache.get(callback)
        if result:
            cache.delete(callback)
            break
        n += 1
    if not result:
        # print('连接失败，客户端6秒内没有回复')
        print_log('--send msg to agent[{}] {}/{} failed: timeout'.format(server_id, module, action), _level='error')

    # print_log('--send msg to agent success [{}] {}'.format(server_id, result))

    return result

def get_server_info(server_id):
    '''
        @name 获取服务器信息
        @author hwliang
        @param server_id<int> 服务器id
        @return object
    '''
    server_info = M('server_list').where("server_id=?",server_id).find()
    return server_info


def agent_decrypt(server_id,pdata):
    '''
        @name 数据解密
        @author hwliang
        @param server_id<int> 服务器id
        @param pdata<string> 待解密数据
        @return dict
    '''
    server_info = get_server_info(server_id)
    if not server_info: return False
    access_key = server_info['access_key']
    secret_key = server_info['secret_key']
    iv = access_key[:8] + access_key[-8:]
    import core.include.aes as aes
    aes_obj = aes.aescrypt_py3(secret_key,"CBC",iv.encode())

    try:
        decode_data =  aes_obj.aesdecrypt(pdata)
        result = json.loads(decode_data)
        return result
    except:
        return None

def agent_encrypt(server_id,pdata):
    '''
        @name 数据加密
        @author hwliang
        @param server_id<int> 服务器id
        @param pdata<string> 待加密数据
        @return dict
    '''
    server_info = get_server_info(server_id)
    if not server_info: return False
    access_key = server_info['access_key']
    secret_key = server_info['secret_key']
    iv = access_key[:8] + access_key[-8:]
    import core.include.aes as aes
    aes_obj = aes.aescrypt_py3(secret_key,"CBC",iv.encode())

    try:
        encode_data =  aes_obj.aesencrypt(json.dumps(pdata))
        return encode_data
    except:
        return None


def get_server_list():
    '''
        @name 获取服务器列表
        @author hwliang
        @return list
    '''
    server_list = M('server_list').select()
    return server_list

def invoke_func(module_name, func_name, args = ()):
    '''
        @name 动态调用函数
        @author Zhj<2022-06-25>
        @param module_name<string>  模块名
        @param func_name<string>    函数名
        @param args<list>           参数列表
        @return mixed
    '''
    import core.include.c_loader.PluginLoader as plugin_loader
    # m_obj = __import__(module_name, fromlist=[module_name])

    m_obj = plugin_loader.get_module('{}/{}.py'.format(get_panel_path(), module_name.replace('.', '/')))

    if not hasattr(m_obj, func_name):
        print_log(m_obj, _level='error')
        raise PanelError('func %s() not found' % func_name)

    return getattr(m_obj, func_name)(*args)

def db(db_name):
    import core.include.sqlite as sqlite
    return sqlite.Sql().dbfile(db_name)

def db_monitor(table_name = None):
    '''
        @name 获取monitor数据库查询对象
        @author Zhj<2022-06-28>
        @param table_name<string> 表名
        @return sqlite.Sql
    '''
    if table_name == None:
        return db('monitor')

    return db('monitor').table(table_name)

def add_retrieve_sort_query(query, args):
    '''
        @name 添加排序条件到查询构造器
        @author Zhj<2022-07-20>
        @param  query<core.include.sqlite_easy.SqliteEasy> 查询构造器对象
        @param  args<dict>                                 请求参数列表
        @return core.include.sqlite_easy.SqliteEasy
    '''
    # import core.include.sqlite_easy as sqlite_easy
    #
    #
    # if not isinstance(query, sqlite_easy.SqliteEasy):
    #     raise Exception('cannot add sort condition to query, because query is not a instance of core.include.sqlite_easy.SqliteEasy.')

    # 检查是否可以添加排序条件
    if 'sort' in args and re.match(r'^[-+]\w+(?:[|][-+]\w+)*$', args.get('sort', '')):
        # 排序方式映射字典
        m = {
            '+': 'ASC',
            '-': 'DESC',
        }

        # 添加排序条件
        for sort_el in args.get('sort', '').split('|'):
            query.order(sort_el[1:], m.get(sort_el[0], 'ASC'))

    return query

# 获取排序参数列表
def get_sort_params(args):
    """
        @param  args<dict>  请求参数列表
        @return {
            "参数名": "是否倒序"
        }
    """
    result = {}

    if 'sort' in args and re.match(r'^[-+]\w+(?:[|][-+]\w+)*$', args.get('sort', '')):
        # 排序方式映射字典
        m = {
            '+': False,
            '-': True,
        }

        for sort_el in args.get('sort', '').split('|'):
            result[sort_el[1:]] = m.get(sort_el[0], 'ASC')

    return result

def add_retrieve_keyword_query(query, args, handler):
    '''
        @name 添加关键字条件到查询构造器
        @author Zhj<2022-07-20>
        @param  query<core.include.sqlite_easy.SqliteEasy> 查询构造器对象
        @param  args<dict>                                 请求参数列表
        @param  handler<function(query, keyword)>          处理函数
        @return core.include.sqlite_easy.SqliteEasy
    '''
    # import core.include.sqlite_easy as sqlite_easy
    #
    # if not isinstance(query, sqlite_easy.SqliteEasy):
    #     raise Exception(
    #         'cannot add sort condition to query, because query is not a instance of core.include.sqlite_easy.SqliteEasy.')

    # 检查是否传了关键字
    # 且关键字不为空
    if 'keyword' in args and args.get('keyword', '') != '':
        from inspect import isfunction
        if isfunction(handler):
            handler(query, args.get('keyword', ''))

    return query

def simple_page(query, args, offset=0):
    '''
        @name 简单分页
        @author Zhj<2022-06-29>
        @param query<sqlite.Sql>    数据库查询对象
        @param args<dict>           请求参数列表
        @param offset<int>          分页偏移量
        @return dict
    '''
    import copy
    import core.include.sqlite_easy as sqlite_easy
    from sqlite_server import SqliteEasy

    p = int(args.get('p', 1))
    p_size = int(args.get('p_size', 20))
    ret = []

    if isinstance(query, sqlite_easy.SqliteEasy) or isinstance(query, SqliteEasy):
        total = query.fork().count()
        ret = query.limit(p_size, ((p - 1) * p_size) + offset).select()
    else:
        total = copy.deepcopy(query).count()
        ret = query.limit(((p - 1) * p_size) + offset, p_size).select()

    return {
        'total': total,
        'list': ret,
    }

def retrieve_by_result(ret, db_name, table_name, local_key, rel_key, fields = '*'):
    '''
        @name 使用sqlite查询结果查询其他表的关联数据
        @author Zhj<2022-06-29>
        @param ret<list> sqlite     查询结果
        @param db_name<string>      数据库名称
        @param table_name<string>   关联表名
        @param local_key<string>    当前表的关联字段名
        @param rel_key<string>      关联表的关联字段名
        @param fields<string>       关联表的查询字段列表
        @return dict                关联字段值 => 关联表数据dict
    '''
    rels = set()
    where_str = '{} IN ('.format(rel_key)
    tmp = ''
    where_params = []

    for item in ret:
        k = item.get(local_key, None)
        if k is None or k in rels:
            continue
        tmp += '?,'
        where_params.append(k)
        rels.add(k)

    if tmp == '':
        where_str = '0'
    else:
        where_str += tmp[:-1] + ')'

    d = {}

    res = db(db_name).table(table_name).field(fields).where(where_str, where_params).select()

    if not isinstance(res, list):
        return d

    for item in res:
        if rel_key not in item:
            continue
        d[str(item[rel_key])] = item

    return d

def get_disk_info():
    #取磁盘分区信息
    temp = ExecShell("df -T -P|grep '/'|grep -v tmpfs|grep -v 'snap/core'|grep -v udev")[0]
    tempInodes = ExecShell("df -i -P|grep '/'|grep -v tmpfs|grep -v 'snap/core'|grep -v udev")[0]
    temp1 = temp.split('\n')
    tempInodes1 = tempInodes.split('\n')
    diskInfo = []
    n = 0
    cuts = []
    for tmp in temp1:
        n += 1
        try:
            inodes = tempInodes1[n-1].split()
            disk = re.findall(r"^(.+)\s+([\w\.]+)\s+([\w\.]+)\s+([\w\.]+)\s+([\w\.]+)\s+([\d%]{2,4})\s+(/.{0,50})$",tmp.strip())
            if disk: disk = disk[0]
            if len(disk) < 6: continue
            if disk[2].find('M') != -1: continue
            if disk[2].find('K') != -1: continue
            if len(disk[6].split('/')) > 10: continue
            if disk[6] in cuts: continue
            if disk[6].find('docker') != -1: continue
            if disk[1].strip() in ['tmpfs']: continue
            arr = {}
            arr['filesystem'] = disk[0].strip()
            arr['type'] = disk[1].strip()
            arr['path'] = disk[6]
            tmp1 = [disk[2],disk[3],disk[4],disk[5]]
            arr['size'] = tmp1
            if int(inodes[1]) == 0 and int(inodes[2]) == 0:
                arr['inodes'] = [inodes[1],10000,10000,0]
            else:
                arr['inodes'] = [inodes[1],inodes[2],inodes[3],inodes[4]]
            diskInfo.append(arr)
        except:
            continue
    return diskInfo


#取磁盘可用空间
def get_disk_free(dfile):
    diskInfo = get_disk_info()
    if not diskInfo: return '',0,0
    _root = None
    for d in diskInfo:
        if d['path'] == '/':
            _root = d
            continue
        if re.match("^{}/.+".format(d['path']),dfile):
            return d['path'],float(d['size'][2]) * 1024,int(d['inodes'][2])
    if _root:
        return _root['path'],float(_root['size'][2]) * 1024,int(_root['inodes'][2])
    return '',0,0

def get_last_days_by_timestamp(day):
    """获取最近N天的时间戳区间

    Args:
        day (int): 最近N天

    Returns:
        truple : 起始，终止的时间戳
    """
    now = time.localtime()
    t1 = time.mktime(
        (now.tm_year, now.tm_mon, now.tm_mday - day + 1, 0, 0, 0, 0, 0, 0))
    t2 = time.localtime(t1)
    start, _ = get_timestamp_interval(t2)
    _, end = get_timestamp_interval(now)
    return start, end

def get_timestamp_interval(local_time):
    """获取某个时间的时间戳区间

    Args:
        local_time (time): 时间

    Returns:
        truple : 起始，终止的时间戳
    """
    start = None
    end = None
    start = time.mktime((local_time.tm_year, local_time.tm_mon,
                         local_time.tm_mday, 0, 0, 0, 0, 0, 0))
    end = time.mktime((local_time.tm_year, local_time.tm_mon,
                       local_time.tm_mday, 23, 59, 59, 0, 0, 0))
    return start, end

def get_query_timestamp(query_date):
    """获取查询日期的时间戳
    参数query_date，用于指定查询的日期。根据query_date的值，函数会返回一个时间戳(start_date, end_date)。
    如果query_date为空或者为"today"，则返回当天的时间戳。
    如果query_date为"yesterday"，则返回昨天的时间戳。
    如果query_date以"l"开头，后面跟着一个数字n，则返回最近n天的时间戳。
    如果query_date为一个日期字符串，格式为"YYYYMMDD"，则返回该日期所在天的时间戳。
    如果query_date为一个日期区间字符串，格式为"start_date-end_date"，则返回该日期区间的时间戳 yyyymmddhhiiss-yyyymmddhhiiss
    """
    try:
        start_date = None
        end_date = None
        if not query_date or query_date == "today":
            start_date, end_date = get_timestamp_interval(
                time.localtime())
        elif query_date == "yesterday":
            # day - 1
            now = time.localtime()
            yes_i = time.mktime((
                                now.tm_year, now.tm_mon, now.tm_mday - 1, 0,
                                0, 0, 0, 0, 0))
            yes = time.localtime(yes_i)
            start_date, end_date = get_timestamp_interval(yes)
        elif query_date.startswith("l"):
            days = int(query_date[1:])
            start_date, end_date = get_last_days_by_timestamp(days)
        else:
            if query_date.find("-") < 0:
                if query_date.isdigit():
                    s_time = time.strptime(query_date, "%Y%m%d")
                    start_date, end_date = get_timestamp_interval(
                        s_time)
            else:
                s, e = query_date.split("-")
                if s[-6:] == "000000" and e[-6:] == "000000":
                    s = s[:-6]
                    e = e[:-6]
                    start_time = time.strptime(s.strip(), "%Y%m%d")
                    end_time = time.strptime(e.strip(), "%Y%m%d")
                    start_date, _ = get_timestamp_interval(start_time)
                    _, end_date = get_timestamp_interval(end_time)
                else:
                    start_time = time.strptime(s.strip(), "%Y%m%d%H%M%S")
                    end_time = time.strptime(e.strip(), "%Y%m%d%H%M%S")
                    start_date = time.mktime(start_time)
                    end_date = time.mktime(end_time)

    except Exception as e:
        print("query timestamp exception:", str(e))
    return start_date, end_date

def get_serverid_bysid(sid):
    '''
        @name 通过主机ID获取server_id
        @author Zhj<2022-07-21>
        @param  sid<integer> 主机ID
        @return string|None
    '''
    # 优先从缓存中获取
    cache_key = 'BT_MONITOR_CACHE__GET_SERVER_ID_BY_SID__{}'.format(sid)
    server_id = cache_get(cache_key)
    if server_id is not None:
        return server_id

    with sqlite_easy('safety') as db:
        server_id = db.query()\
            .name('server_list')\
            .where('sid=?', int(sid))\
            .value('server_id')
        # 缓存server_id
        cache_set(cache_key, server_id, 600)
        return server_id

def get_agent_file(sid,file_name):
    """
    @name 获取agent文件
    @author cjxin
    @param sid 服务器id
    @param file_name<string> 文件名
    """    
        
    pdata = g_pdata({"file":file_name})
    serverid = get_serverid_bysid(sid)
    result = send_agent_msg(serverid,'File','ReadFile','recv/File/ReadFile/{}'.format(serverid),pdata)
    return result

def g_pdata(pdata):
    """
    @构造agent参数
    @param pdata
    """
    data = {}
    data['args'] = {}
    data['args_list'] = []
    for key in pdata:
        data['args_list'].append(key)
        data['args'][key] = str(pdata[key])
    return data

def get_agent_msg(obj):
    '''
        @name 解析客户端返回数据
        @author Zhj<2022-07-11>
        @param  obj<string|dict> 客户端返回数据
        @return dict
    '''
    if not obj:
        return None

    if isinstance(obj, str):
        try:
            obj = json.loads(obj)
        except: pass

    res = obj

    if 'body' in obj.keys():
        res = obj['body']

        if 'body' in res.keys() and isinstance(res['body'], str):
            try:
                res['body'] = json.loads(res['body'])
            except: pass

        return obj['body']

    return obj

def bt_auth(key = None):
    '''
        @name 获取当前登录用户信息
        @author Zhj<2022-07-11>
        @param  key<string> 键名
        @return dict
    '''
    from core import session

    user_info =  {
        'username': session.get('username', 'system'),
        'uid': session.get('uid', 0),
        'gid': session.get('gid', 0),
        'login': session.get('login', True),
        'last_login_time': session.get('last_login_time', 0),
        'last_login_ip': session.get('last_login_ip', '127.0.0.1'),
        'request_token_head': session.get('request_token_head', ''),
    }

    # 获取指定键值
    if key is not None:
        return user_info.get(key, None)

    return user_info

# 获取当前绑定的堡塔账号信息
def get_user_info():
    user_path = '{}/data/user.json'.format(get_panel_path())
    data = None
    try:
        if os.path.exists(user_path):
            data = json.loads(readFile(user_path))
    except:
        pass

    return data

def sqlite_execute_batch(db_name, raw_sqls):
    '''
        @name 批量执行多条sqlite语句
        @author Zhj<2022-07-11>
        @param  db_name<string>  数据库名称
        @param  raw_sqls<string> sqlite语句
        @return dict
    '''
    query = db(db_name)
    res = {}

    for raw_sql in raw_sqls.split(';'):
        raw_sql = raw_sql.strip()

        if raw_sql == '':
            continue

        res[raw_sql] = query.execute(raw_sql)

    return res

def sqlite_easy(db_name, brandnew = True):
    '''
        @name 获取SqliteEasy数据库对象
        @author Zhj<2022-07-18>
        @param  db_name<string>     数据库名称
        @param  brandnew<bool>      是否开启全新数据库连接
        @return core.include.sqlite_easy.Db
    '''
    from sqlite_server import Db
    # from core.include.sqlite_easy import Db

    return Db(db_name, brandnew).synchronous_off_wal()
    # return Db(db_name, brandnew)

def print_exc_stack(e):
    '''
        @name 打印异常堆栈到日志
        @author Zhj<2022-07-19>
        @param  e<BaseException> 异常对象
        @return bool
    '''
    import traceback
    from core.include.monitor_exceptions import BtMonitorException

    if isinstance(e, BtMonitorException):
        return False

    print_log(traceback.format_exc(), _level='ERROR')

    return True

def is_number(s):
    '''
        @name 判断输入参数是否是一个数字
        @author Zhj<2022-07-18>
        @param  s<string|integer|float> 输入参数
        @return bool
    '''
    try:
        float(s)
        return True
    except ValueError:
        pass

    try:
        import unicodedata
        unicodedata.numeric(s)
        return True
    except (TypeError, ValueError):
        pass

    return False

def import_via_loader(real_py_path):
    '''
        @name 通过加载器导入模块
        @author Zhj<2022-08-30>
        @param  real_py_path<string> py文件的绝对路径
        @return object
    '''
    import core.include.c_loader.PluginLoader as plugin_loader

    module_obj = plugin_loader.get_module(real_py_path)

    if not module_obj:
        raise Exception('importError: {}'.format(real_py_path))

    if isinstance(module_obj, dict):
        if 'msg' not in module_obj:
            raise Exception('importError: {}'.format(real_py_path))

        raise Exception('importError: {}\n{}'.format(real_py_path, module_obj['msg']))

    return module_obj

def encrypt_password(data):
    '''
        @name AES加密字符串
        @param data<string> 原文
        @return string
    '''
    if sys.version_info[0] == 2:
        from core.include.aes import aescrypt_py3 as aescrypt
    else:
        from core.include.aes import aescrypt_py2 as aescrypt
    
    aesc = aescrypt('40b0767eb19b', 'ECB', '', 'utf8')
    return aesc.aesencrypt(data.strip())

def decrypt_password(data):
    '''
        @name AES解密字符串
        @param data<string> 密文
        @return string
    '''
    if sys.version_info[0] == 2:
        from core.include.aes import aescrypt_py3 as aescrypt
    else:
        from core.include.aes import aescrypt_py2 as aescrypt
    
    aesc = aescrypt('40b0767eb19b', 'ECB', '', 'utf8')
    return aesc.aesdecrypt(data.strip())

# 构造带有签名的关联数组
def get_panel_key_data(pdata, token):
    pdata['request_time'] = int(time.time())
    pdata['request_token'] = md5(str(pdata['request_time']) + '' + md5(str(token)))
    return pdata

def mmh3_hash64(key):
    '''
        @name MurmurHash3哈希函数
        @param key<string> 字符串
        @return int
    '''
    # 导入MurmurHash3
    import core.include.pymmh3 as mmh3

    h, _ = mmh3.hash64(key)

    return h

def tuple2dict(t):
    data = {}
    for item in t:
        data[item[0][0]] = item[0][1]
    return data

match_number_reg = re.compile(r'^\d+(?:\.\d+)?')
def get_item_as_number(d, prop, parse_int=False):
    '''
        @name 从字典中获取值并尝试转为数字
        @author Zhj<2023-03-20>
        @param d<dict>          字典
        @param prop<string>     键
        @param parse_int<?bool> 转为整数
        @return float|int
    '''
    ret = 0.00

    for _ in range(1):
        if not isinstance(d, dict) or prop not in d:
            ret = 0.00
            break

        if is_number(d[prop]):
            ret = float(d[prop])
            break

        if not isinstance(d[prop], str):
            ret = 0.00
            break

        m = match_number_reg.match(d[prop].strip())

        if not m:
            ret = 0.00
            break

        ret = float(m.group())
        break

    if parse_int:
        return int(ret)

    return ret

def event(event_obj=None):
    '''
        @name 触发事件
        @author Zhj<2023-03-23>
        @param  event_obj<?core.include.monitor_events.BaseEvent> 事件对象
        @return bool
    '''
    m = import_via_loader('{}/core/include/monitor_event_helper.py'.format(get_panel_path()))

    if event_obj is None:
        return m

    return m.fire(event_obj)


# 使用雪花算法生成ID
def snow_flake(machine_id=0, sequence=0):
    return (int(time.time() * 1000 - 1680509680481) << 22) | ((int(machine_id) & ((1 << 10) - 1)) << 12) | (int(sequence) & ((1 << 12) - 1))


# 将allowed_gai_family还原回初始状态
def restore_allowed_gai_family():
    import requests.packages.urllib3.util.connection as urllib3_conn
    from core import default_allowed_gai_family
    urllib3_conn.allowed_gai_family = default_allowed_gai_family


ipv4_pattern = re.compile(r'\d{1,3}(?:\.\d{1,3}){3}')
def mask_ipv4_address(s):
    '''
        @name 将IPv4地址匿名化处理
        @param s<string> 原字符串
        @return string
    '''
    return ipv4_pattern.sub('****', s)


# 检查客户端返回的操作是否成功
def check_agent_response_success(res):
    '''
        @name 检查客户端返回的操作是否成功
        @author Zhj<2023-04-27>
        @param  res<dict> 客户端响应的数据
        @return bool
    '''
    if 'success' not in res:
        return True

    return bool(res['success'])


# 自定义监控 执行脚本
def custom_exec_script(warning_config=None):
    '''
        @name 自定义监控 执行脚本
        @param  warning_config<dict> 告警规则
        @return bool
    '''
    from core.include.monitor_helpers import warning_obj, basic_monitor_obj
    if warning_config is None:
        return False

    rule_id = int(warning_config.get('id', 0))
    sid = int(warning_config.get('sid', 0))
    # pro_name = warning_obj.get_var(warning_config['sub_type'])

    proc_name, boot_command = str(warning_obj.get_var(warning_config['sub_type'])).split('|', 1)
    pne_id = warning_obj.get_pne_id(proc_name, boot_command)

    # 脚本配置表查数据
    monitor_db_manager = import_via_loader('{}/core/include/monitor_db_manager.py'.format(get_panel_path()))
    with monitor_db_manager.db_mgr('custom_process') as db:
        # 任务
        pro_ = db.query() \
            .name('custom_process') \
            .where('sid', sid) \
            .where('pne_id', pne_id) \
            .find()

        # 关联脚本 .where('push_condition', 0) \
        scripts = db.query() \
            .name('custom_process_rule_script') \
            .field('script', 'id') \
            .where('pro_id', pro_['id']) \
            .where('rule_id', rule_id) \
            .select()

    if not pro_ or not scripts:
        return False

    execute_result = []
    for script in scripts:
        # 调用执行shell脚本的方法
        if script['script'] == '':
            # print_log(
            #     'HHHHHHHHHHHHHHHHHHHHHHHHHHHH进程{}执行脚本为空 不执行跳过'.format(warning_config['sub_type']),
            #     _level='error')

            continue
        else:
            res, err_msg = basic_monitor_obj.exec_shell_with_agent(sid, script['script'])
            # print_log('HHHHHHHHHHHHHHHHHHHHHHHHHHHH 进程::{} 脚本:::{}  执行结果res::{}  err::{}'.format(warning_config['sub_type'],script['script'], res, err_msg), _level='error')
            # print_log('HHHHHHHHHHHHHHHHHHHHHHHHHHHH进程{}执行脚本{}'.format(warning_config['sub_type'], script['script']), _level='error')


            result_dict = {
                'pro_id': pro_['id'],
                'center_id': script['id'],
                'result': '' if res is None else res.replace('\n', ''),
                'status': 1 if err_msg is None else 0,
                'err_msg': '' if err_msg is None else str(err_msg),
                'create_time': int(time.time())
            }
            # 记录执行脚本日志
            status_ = '成功' if err_msg is None else '失败'
            WriteLog('自定义监控进程', '进程【%s】 执行脚本:【%s】 执行%s err_msg: %s' % (proc_name, script['script'], status_, str(err_msg)))
            execute_result.append(result_dict)

    # 记录执行结果
    with monitor_db_manager.db_mgr('custom_process') as db:
        try:
            # 关闭事务自动提交
            db.autocommit(False)
            if len(execute_result) > 0:
                db.query() \
                    .name('custom_process_script_result') \
                    .insert_all(execute_result)
            # 提交事务
            db.commit()
        except BaseException as e:
            # 回滚事务
            db.rollback()
            # 记录异常堆栈
            print_exc_stack(e)
            # 记录日志
            return False
    # print_log('HHHHHHHHHHHHHHHHHHHHHHHHHHHH执行脚本完毕', _level='error')
    return True
