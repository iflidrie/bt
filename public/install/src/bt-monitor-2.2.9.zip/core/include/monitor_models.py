class BasicHistory:
    # 添加历史数据
    def put_item(self, prop_name, value):
        item = getattr(self, prop_name, [])
        item.append(value)
        setattr(self, prop_name, sorted(item, reverse=True)[:10])

    # 获取指标数据并清空历史数据
    def pull_item(self, prop_name):
        item = getattr(self, prop_name, [])

        if len(item) == 0:
            return None

        if len(item) < 4:
            value = item[-1]
        else:
            value = item[2]

        setattr(self, prop_name, [])

        return value

class CpuHistory(BasicHistory):
    __slots__ = ['percent']

class MemHistory(BasicHistory):
    __slots__ = ['percent', 'used']

class SwapHistory(BasicHistory):
    __slots__ = ['percent', 'used']

class DiskHistory(BasicHistory):
    __slots__ = ['name', 'used', 'used_percent', 'inodes_used',
                 'inodes_used_percent', 'iops', 'io_percent',
                 'read_bytes_per_second', 'write_bytes_per_second']

class NetHistory(BasicHistory):
    __slots__ = ['name', 'sent_per_second', 'recv_per_second']

class LoadAvgHistory(BasicHistory):
    __slots__ = ['last_1_min', 'last_5_min', 'last_15_min']

class SysteminfoHistory:
    __slots__ = ['cpu', 'mem', 'swap', 'disk', 'net',
                 'load_avg']

class ProcessHistory:
    pass