
class sms:
	pass