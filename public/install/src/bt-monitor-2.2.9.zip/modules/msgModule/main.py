import json,os

import core.include.public as public
import core.include.c_loader.PluginLoader as plugin_loader

"""
@name 告警通知主模块 
@author cjxin@bt.cn
"""

class main:

    __path = '{}/data/msg_push.json'.format(public.get_panel_path())
    __mod_list = {
        'dingding':'钉钉',
        'weixin':'微信',
        'sms':'短信',
        'mail':'邮件',
        'feishu':'飞书',
        'weixingzh':'微信公众号',
    }

    __default_conf = {
        'weixin': {
            'weixin_url':'',
            'isAtAll':True,
            'user':1
        },
        'dingding': {
            'dingding_url':'',
            'isAtAll':True,
            'user':1
        },
        'mail': {
            "send": {
                "qq_mail":"",
                "qq_stmp_pwd":"",
                "hosts":"",
                "port":""
            },
            "receive":[]
        },
        'feishu': {

        },

        'weixingzh': {

        },

     }


    # ***************************************************************** 对外方法start *****************************************************************
    def send(self, args):
        """
        @name 发送消息
        @author cjxin
        @args dict 请求参数
            msg_type    string 推送类型
            msg         string 消息内容
            title       string 标题(非必填)
            to_email    string 接收邮箱（非必填）
        """
        msg_type = args.get('msg_type', None)

        if msg_type is None:
            return public.error('缺少参数：msg_type')

        msg_obj = self._get_script_obj(args)

        # 检查对应的消息推送类是否存在
        if not msg_obj: 
            return public.error('无效的消息通道：{}.'.format(msg_type))

        # 检查是否完成配置
        if not msg_obj.is_configured():
            return public.error('请先配置消息通道：{}'.format(msg_type))

        return msg_obj.send_msg(args)

    def resetting(self,args):
        """
        @name 清空mail配置
        @author law
        @msg_type string 消息类型
        @args dict 配置参数
        """
        msg_type = args.get('msg_type', None)

        if msg_type is None:
            return public.error('缺少参数：msg_type')

        msg_obj = self._get_script_obj(args)

        return msg_obj.resetting_v1(args)


    def auto_send(self, get):
        """根据消息通道优先级和配置情况，自动发送消息

        Args:
            get (dict_obj): 消息参数, 参考send

        Returns:
            dict : 结果状态描述
        """
        msg_list = self.get_msg_list(None)
        weights = {
            "dingding": 0,
            "weixin": 0,
            "mail": 0,
            "sms": 1,
        }
        channels = []
        if msg_list["status"]:
            data = msg_list["data"]
            for k in list(data.keys()):
                if data[k]["setup"]:
                    channels.append((k, weights.get(k, 1000)))

        if not channels:
            return public.return_data(False, "请先配置消息通道。")



        sorted_channels = sorted(channels, key=lambda x: x[1])
        # 选择一个能够发送的通道
        for c in sorted_channels:
            get.msg_type = c[0]
            send_res = self.send(get)
            if "status" in send_res:
                if send_res["status"]:
                    return send_res
        return public.return_data(False, "消息发送失败：{}".format(",".join(list(map(lambda x: x[0], sorted_channels)))))

    def get_msg_list(self,get):
        """
        @name 获取消息通道列表
        @author cjxin
        @get dict 请求参数
        """
        data = {}
        try:
            if os.path.exists(self.__path): 
                data = json.loads(public.readFile(self.__path))
        except:pass

        for key in data.keys():
            args = public.dict_obj()
            args.msg_type = key
            msg_obj = self._get_script_obj(args)
            if not msg_obj: 
                data[key]['setup'] = False
            else:
                data[key]['setup'] = True
        return public.return_data(True,data)

    def get_msg_config(self,get = None):
        """
        @name 获取配置
        @author cjxin 
        @get dict 请求参数
            msg_type string 推送类型  
        """
        if not 'msg_type' in get:
            return public.return_data(False,'msg_type参数不能为空!')

        msg_obj = self._get_script_obj(get)
        if not msg_obj: 
            return public.return_data(False,'找不到消息模型{}.'.format(get['msg_type']))
       
        return public.success(msg_obj.get_config(get))

    def set_msg_config(self,get):
        """
        @name 设置配置
        @author cjxin
        @get dict 请求参数
            msg_type string 推送类型
        """
        if not 'msg_type' in get:
            return public.return_data(False,'msg_type参数不能为空!')

        msg_obj = self._get_script_obj(get)
        if not msg_obj: 
            return public.return_data(False,'找不到消息模型{}.'.format(get['msg_type']))
        return msg_obj.set_config(get)

    def send_test_msg(self, args):
        '''
            @name 发送一条测试信息
            @author Zhj<2022-08-02>
            @arg    msg_type<string> 消息通道类型
            @return dict
        '''
        return self.send(public.to_dict_obj({
            'msg_type': args.get('msg_type', None),
            'title': '【宝塔云安全监控】消息测试',
            'msg': '''您正在宝塔云安全监控进行告警通知测试操作，如非您本人操作，请忽略此消息。\n若您收到此消息，证明您的配置正确，且可以正常收发消息。'''
        }))

    # ***************************************************************** 对外方法end *****************************************************************

    def is_configured(self):
        '''
            @name 消息通道配置检查方法（abstract）
            @author Zhj<2022-08-02>
            @return bool
        '''
        raise Exception('subclass must implement method is_configured().')

    def _get_script_obj(self,get):
        """
        @name 获取脚本路径
        @author cjxin
        @get dict 请求参数
            msg_type string 推送类型
        """
        msg_obj = None
        try:
            path = '{}/modules/msgModule/{}.py'.format(public.get_panel_path(),get['msg_type'])
            if not os.path.exists(path): return False
            _obj = plugin_loader.get_module(path)
            if hasattr(_obj, get['msg_type']):
                msg_obj = getattr(_obj, get["msg_type"])()
        except:
            msg_obj = None
        return msg_obj

    def _get_base_config(self,msg_type = None):
        """
        @name 获取配置
        @author cjxin
        @msg_type string 消息类型
        """        
        try:
            data = {}
            if os.path.exists(self.__path): 
                data = json.loads(public.readFile(self.__path))
            if msg_type in data:
                return data[msg_type]
            else:
                return self.__default_conf[msg_type]
        except: pass        
        return data


    def _set_base_config(self,msg_type,args):
        """
        @name 清空配置
        @author cjxin
        @msg_type string 消息类型
        @args dict 配置参数

        """
        data = {}
        try:
            if os.path.exists(self.__path): 
                data = json.loads(public.readFile(self.__path))
        except: pass
            
        data[msg_type] = args
        public.writeFile(self.__path,json.dumps(data))
        return public.return_data(True,'设置成功!')

    def _return_data(self,msg_type,status,msg,msg_info='', need_write_log=True):
        """
        @name 返回数据
        @author cjxin
        @msg_type string 消息类型
        @status bool 是否成功
        @msg string 消息
        @msg_info string 消息/错误详情
        """
        status_code = 1
        if not status: status_code = 0

        if need_write_log:
            self._write_log(msg_type,status_code,msg,msg_info)
        else:
            public.print_log(msg_info)
        
        return public.return_data(status,msg)

    def _write_log(self,msg_type,status_code,msg,msg_info = '', need_write_log=True):
        """
        @name 写日志
        @author cjxin
        @msg_type string 消息类型
        @msg string 消息
        @msg_info string 消息/错误详情
        """    
        if msg_type in self.__mod_list: 
            msg_type = self.__mod_list[msg_type]
        public.WriteLog('告警通知',msg_type + msg,status_code,msg_info)
        return True
