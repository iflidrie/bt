import re

import paramiko
import threading
import json
import time
from io import StringIO
import sys
import socket
import os
import simple_websocket
import uuid

os.chdir("/www/server/bt-monitor")
sys.path.insert(0, "/www/server/bt-monitor")

import core.include.public as public
from core import my_terms
import core.include.Locker as Locker

# from serverModule.main import main as serverModule
# from core.include.flask_session import Session
serverModule = public.import_via_loader('{}/modules/serverModule/main.py'.format(public.get_panel_path())).main
monitor_db_manager = public.import_via_loader('{}/core/include/monitor_db_manager.py'.format(public.get_panel_path()))
from core.include.monitor_helpers import basic_monitor_obj


class main:
    __log_type = '被控面板终端'
    _coll_user = None
    _host = None
    _web_socket = None
    _ssh_info = None
    _ssh_socket = None
    _uid = 1
    _filepath = '/www/server/bt-monitor/data/asciinemadir'
    # time = time.time()
    # __MATCH_PWD_OBJ = re.compile(r'^[\r\n]?(?:[\x1b]\[K)?(?:[\x1b]\]0;)?\[?(([^\s#\$\x07]+)@[^\s#\$\x07]+:?) ?([^\s#\$\x07\x5d]+)(?:[\x07]\1\3)?\]?[\$#] $')
    # __PWD_PER_TERMINAL = {}
    __TERMINAL_SSH_CONNECTIONS = {}
    # __sf = paramiko.Transport(host,port)



    def __init__(self):
        if not os.path.exists(self._filepath):
            os.system('mkdir -p ' + self._filepath)
            os.system('chmod -R 600 %s' % self._filepath)
        self.SSH_SESSION = None
        self.__TERMINAL_ID = None
        self.__SENDING_LAST_CHARS = 0
        self.DURATIONS = 0

    def connect(self,ssh_info=None ):
        if ssh_info: self._ssh_info = ssh_info
        if not self._host: self._host = self._ssh_info['host']
        # if self._ssh_info['host'] in my_terms:
        #     if time.time() - my_terms[self._host].last_time < 86400:
        #         return True
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 262144)
            sock.connect((self._ssh_info['host'], int(self._ssh_info['port'])))

        except Exception as e:
            public.print_exc_stack(e)
            self._web_socket.send("服务器连接失败!")
            return False


        # 使用Transport连接
        p1 = paramiko.Transport(sock)
        p1.start_client()
        if 'pkey' not in self._ssh_info:
            self._ssh_info['pkey'] = None
        else:
            self._ssh_info['c_type'] = True

        connect_flag = False
        pwd = ''
        check_send = False
        for i in range(2):
            try:
                # 如果有pkey时则使用RSA私钥登录
                if i == 0 and self._ssh_info['pkey'] and self._ssh_info['c_type']:
                    # 将RSA私钥转换为io对象，然后生成rsa_key对象
                    p_file = StringIO(public.decrypt_password(self._ssh_info['pkey']))
                    pkey = paramiko.RSAKey.from_private_key(p_file)
                    p1.auth_publickey(username=self._ssh_info['username'], key=pkey)
                else:
                    # p1.auth_password(username=self._ssh_info['username'], password=self._ssh_info['password'])
                    if self._ssh_info['password'] == '':
                        if not check_send:
                            # 使用ws发送一条消息 请输入密码
                            self._web_socket.send("{}@{}'s password:".format(self._ssh_info['username'],self._ssh_info['host']))
                        # 发送后标记消息已发送，后面都不发送
                        check_send = True
                        space_num = 0  # 发送的空格数量
                        # 多次尝试的机制
                        for count in range(3):
                            #   接收ws消息(阻塞)  循环获取消息
                            while self._web_socket.connected:
                                c_data = self._web_socket.receive()
                                # 当接收到的消息为id或者resize时，执行特定的代码段
                                if not c_data: continue
                                if c_data.find('{"id":"') != -1:
                                    self.__TERMINAL_ID = str(c_data)[7:16]
                                    self.__TERMINAL_SSH_CONNECTIONS['{}_{}'.format(self._ssh_info['id'],self.__TERMINAL_ID)] = TerminalSshConnectionWrap(
                                        self.SSH_SESSION)
                                    continue
                                if c_data.find('{"host":"') != -1:
                                    continue
                                if c_data.find('"resize":1') != -1:
                                    self.resize(c_data)
                                    continue
                                if c_data.find('resize_pty') != -1:
                                    if self.resize(c_data): continue
                                elif c_data.find('"password"') != -1 and c_data.find('"host"') != -1:
                                    continue
                                #
                                # public.print_log("-------{}".format(c_data.encode()))
                                # public.print_log("+++++++++++{}".format(pwd))
                                if c_data.encode() == b'\x7f':
                                    if len(pwd) > 0:
                                        # public.print_log("*****")
                                        space_num -= 1
                                        pwd = pwd[:-1]
                                        self._web_socket.send(b'\x08\x1b[K')
                                    continue

                                # 其它情况的消息，说明接收到了密码输入，将输入拼接起来，直到接收到了回车符号或者换行符号
                                pwd += c_data

                                # public.print_log("+++++++++++{}".format(pwd))
                                # public.print_log("+++++++++++{}".format(type(pwd)))
                                if '\r' in c_data or '\n' in c_data:
                                    break

                                self._web_socket.send(' ')
                                space_num += 1

                            try:
                                pwd = pwd.strip()
                                # 将接收到的消息当作密码，拿到下面尝试连接
                                p1.auth_password(username=self._ssh_info['username'], password=pwd)
                                # 当密码正确连接成功后，跳出循环
                                connect_flag = True
                                self._web_socket.send("\r\n")
                                break
                            except BaseException:
                                pwd = ''
                                self._web_socket.send((b'\x08\x1b[K' * space_num) + '密码错误，重新输入!\r\n'.encode())
                                space_num = 0
                                self._web_socket.send("{}@{}'s password:".format(self._ssh_info['username'], self._ssh_info['host']))
                                # public.print_exc_stack(e)

                        if not connect_flag:
                            self._web_socket.send((b'\x08\x1b[K' * space_num) + '超过最大重试次数,用户验证失败!'.encode())
                            p1.close()
                        connect_flag = True
                        break
                    p1.auth_password(username=self._ssh_info['username'], password=public.decrypt_password(self._ssh_info['password']))

                connect_flag = True
                break
            except Exception as e:
                public.print_exc_stack(e)

        if not connect_flag:
            self._web_socket.send("用户验证失败!")
            p1.close()
            return False

        self.SSH_SESSION = p1.open_session()
        self.connect_time = int(time.time())
        self.SSH_SESSION.get_pty(term='xterm', width=100, height=29)
        self.SSH_SESSION.invoke_shell()
        self.filename = self._ssh_info['host'] + '_' + \
            time.strftime('%Y_%m_%d_%H%M%S', time.localtime(self.connect_time))

        # my_terms[self._host] = public.dict_obj()
        # my_terms[self._host].last_time = time.time()
        # my_terms[self._host].connect_time = time.time()
        # 打开会话
        # my_terms[self._host].tty = p1.open_session()
        # 获取终端对象
        # my_terms[self._host].tty.get_pty(term='xterm', width=100, height=29)
        # my_terms[self._host].tty.invoke_shell()
        # 回放日志文件名
        # my_terms[self._host].filename = self._ssh_info['host'] + '_' + \
        #                                 time.strftime('%Y_%m_%d_%H%M%S',
        #                                               time.localtime(my_terms[self._host].connect_time))

        # 记录登陆记录
        public.M('ssh_records').add('coll_user,ssh_user,host,cmd,addtime', (
            self._coll_user, self._ssh_info['username'], self._ssh_info['host'], 'login', int(time.time())))

        with open(self._filepath + '/{}.cast'.format(self.filename), 'w') as fp:
            fp.write('{}\n'.format(json.dumps({
                "version": 2,
                "width": 120,
                "height": 40,
                "timestamp": int(time.time()),
                "env": {
                    "SHELL": "/bin/bash",
                    "TERM": "xterm"
                }
            })))
        # self.record('header', {
        #     "version": 1,
        #     "width": 120,
        #     "height": 40,
        #     "timestamp": int(my_terms[self._host].connect_time),
        #     "env": {
        #         "TERM": "xterm",
        #         "SHELL": "/bin/bash",
        #     },
        #     "stdout": []
        # })
        # self.time=my_terms[self._host].connect_time

        # 初始化终端帮助类
        if self.__TERMINAL_ID is not None:
            term_conn_warp = TerminalSshConnectionWrap(self.SSH_SESSION)
            term_conn_warp.password = pwd
            self.__TERMINAL_SSH_CONNECTIONS['{}_{}'.format(self._ssh_info['id'], self.__TERMINAL_ID)] = term_conn_warp


        return True

    def test_connect(self, args):
        host_info = {}
        host_info['host'] = args.host
        host_info['port'] = int(args['port'])
        host_info['username'] = args.username
        host_info['password'] = args.password
        host_info['pkey'] = args['pkey']


        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 262144)
            sock.connect((host_info['host'], int(host_info['port'])))

        except Exception as e:
            public.print_exc_stack(e)
            self._web_socket.send("服务器连接失败!")
            return False

        # 使用Transport连接
        p1 = paramiko.Transport(sock)
        p1.start_client()
        if 'pkey' not in host_info:
            host_info['pkey'] = None
        else:
            host_info['c_type'] = True

        connect_flag = False
        for i in range(2):
            try:
                # 如果有pkey时则使用RSA私钥登录
                if i == 0 and host_info['pkey'] and host_info['c_type']:
                    # 将RSA私钥转换为io对象，然后生成rsa_key对象
                    p_file = StringIO(public.decrypt_password(host_info['pkey']))
                    pkey = paramiko.RSAKey.from_private_key(p_file)
                    p1.auth_publickey(username=host_info['username'], key=pkey)
                else:
                    # p1.auth_password(username=self._ssh_info['username'], password=self._ssh_info['password'])
                    p1.auth_password(username=host_info['username'], password=host_info['password'])
                connect_flag = True
                break
            except Exception as e:
                public.print_exc_stack(e)
                e = str(e)
                if e.find('Authentication timeout') != -1:
                    return public.error("认证超时{}".format(e))
                if e.find('Authentication failed') != -1:
                    return public.error('认证失败,账号或密码错误{}'.format(e))
                # if e.find('Bad authentication type; allowed types') != -1:
                #     if self._host in ['127.0.0.1', 'localhost'] and self._pass == 'none':
                #         return returnMsg(False, '帐号或密码错误: {}'.format(
                #             "Authentication failed ," + host_info['username'] + "@" + host_info['host'] + ":" + str(host_info['port'])))
                #     return returnMsg(False, '不支持的身份验证类型: {}'.format(e))
                if e.find('Connection reset by peer') != -1:
                    e = '目标服务器主动拒绝连接'
                    return public.error(e)
                if e.find('Error reading SSH protocol banner') != -1:
                    return public.error('协议头响应超时，与目标服务器之间的网络质量太糟糕：' + e)
                if not e:
                    return public.error("SSH协议握手超时，与目标服务器之间的网络质量太糟糕")


            finally:
                time.sleep(1)
                self.close()

        if not connect_flag:
            self._web_socket.send("用户验证失败!")
            p1.close()
            return False

        return public.success("连接成功！")

    def resize(self, data):
        try:
            data = json.loads(data)
            if "width" in data:
                self.SSH_SESSION.resize_pty(width=data['width'], height=data['height'],
                                   width_pixels=data['width_px'], height_pixels=data['height_px'])
            else:
                self.SSH_SESSION.resize_pty(width=data['cols'], height=data['rows'])
            return True
        except BaseException as e:
            # public.print_exc_stack(e)
            # print(public.get_error_info())
            return False

    def send(self):
        try:
            while self._web_socket.connected:
                c_data = self._web_socket.receive()
                if not c_data: continue
                if len(c_data) > 10:
                    if c_data.find('{"id":"') != -1:
                        self.__TERMINAL_ID = str(c_data)[7:16]
                        # self.__TERMINAL_SSH_CONNECTIONS['{}_{}'.format(self._ssh_info['id'], self.__TERMINAL_ID)] = {
                        #     'last_chars': '',
                        #     'ssh_session': self.SSH_SESSION,
                        #     'get_pwd': False,
                        #     'cnt': 0,
                        #     'pwd': None,
                        #     'lock': threading.Lock(),
                        # }
                        self.__TERMINAL_SSH_CONNECTIONS['{}_{}'.format(self._ssh_info['id'], self.__TERMINAL_ID)] = TerminalSshConnectionWrap(self.SSH_SESSION)
                        continue
                    if c_data.find('{"host":"') != -1:
                        continue
                    if c_data.find('"resize":1') != -1:
                        self.resize(c_data)
                        continue
                    if c_data.find('resize_pty') != -1:
                        if self.resize(c_data): continue
                    elif c_data.find('"password"') != -1 and c_data.find('"host"') != -1:
                        continue
                # if self._host in my_terms:
                #     my_terms[self._host].last_time = time.time()
                # else:
                #     return

                k = '{}_{}'.format(self._ssh_info['id'], self.__TERMINAL_ID)
                if k in self.__TERMINAL_SSH_CONNECTIONS:
                    # if str(c_data).find('\r') > -1 or str(c_data).find('\n') > -1:
                    #     # str_end = str(c_data).split('\n')[-1]
                    #     str_end = re.split(r'[\r\n]', str(c_data))[-1]
                    #     if len(str_end.strip()) == 0:
                    #         self.__TERMINAL_SSH_CONNECTIONS[k]['last_chars'] = ''
                    #     else:
                    #         self.__TERMINAL_SSH_CONNECTIONS[k]['last_chars'] = str(str_end)
                    # else:
                    #     self.__TERMINAL_SSH_CONNECTIONS[k]['last_chars'] += str(c_data)
                    self.__TERMINAL_SSH_CONNECTIONS[k].set_last_chars(c_data)

                self.SSH_SESSION.send(c_data)
        except simple_websocket.ws.ConnectionClosed: pass
        except BaseException as e:
            public.print_exc_stack(e)
            # print(public.get_error_info())
        finally:
            try:
                self.SSH_SESSION.close()
            except: pass

    def recv(self):
        try:
            # n = 0
            while self._web_socket.connected:
                # self.not_send()
                # if n == 0: self.last_send()
                data = self.SSH_SESSION.recv(1024)
                # self.not_send()
                if not data:
                    self.close()
                    self._web_socket.send('连接已断开,按回车将尝试重新连接!')
                    # self._web_socket.send('连接已断开,请重新打开SSH终端!')
                    return

                try:
                    result = data.decode('utf-8', 'ignore')
                except:
                    try:
                        result = data.decode()
                    except:
                        result = str(data)
                if not result: continue

                if not self._web_socket.connected:
                    # my_terms[self._host].not_send = result
                    return

                if self.__SENDING_LAST_CHARS > 0:
                    self.__SENDING_LAST_CHARS -= 1
                    continue

                k = '{}_{}'.format(self._ssh_info['id'], self.__TERMINAL_ID)
                # if k in self.__TERMINAL_SSH_CONNECTIONS and self.__TERMINAL_SSH_CONNECTIONS[k]['get_pwd']:
                #     self.__TERMINAL_SSH_CONNECTIONS[k]['cnt'] -= 1
                #
                #     if re.match(r'^(?:\x08\x1b\[K)*pwd', str(result)):
                #         self.__TERMINAL_SSH_CONNECTIONS[k]['pwd'] = str(result).strip().split('\n')[-1]
                #
                #     if self.__TERMINAL_SSH_CONNECTIONS[k]['cnt'] == 0:
                #         self.__TERMINAL_SSH_CONNECTIONS[k]['get_pwd'] = False
                #         # 重新发送上一次的字符
                #         if len(self.__TERMINAL_SSH_CONNECTIONS[k]['last_chars']) > 0:
                #             self.SSH_SESSION.send(self.__TERMINAL_SSH_CONNECTIONS[k]['last_chars'])
                #             self.__SENDING_LAST_CHARS = 1
                #     continue
                if k in self.__TERMINAL_SSH_CONNECTIONS and self.__TERMINAL_SSH_CONNECTIONS[k].schedule(result):
                    if self.__TERMINAL_SSH_CONNECTIONS[k].is_schedule_end():
                        # 重新发送上一次的字符
                        if len(self.__TERMINAL_SSH_CONNECTIONS[k].get_last_chars()) > 0:
                            self.SSH_SESSION.send(self.__TERMINAL_SSH_CONNECTIONS[k].get_last_chars())
                            self.__SENDING_LAST_CHARS = 1
                    continue

                # self.set_last_send(result)
                # self.record('iodata', result)

                # if not n: n = 1
                # TODO 写入回放日志
                with open(self._filepath + '/{}.cast'.format(self.filename), 'a') as fp:
                    self.DURATIONS = round(time.time() - self.connect_time, 6)
                    fp.write('{}\n'.format(json.dumps([self.DURATIONS, 'o', str(result)])))

                # # 记录当前终端的工作目录
                # pwd = self.__parse_pwd(result)
                # if pwd:
                #     self.__terminal_pwd(self._ssh_info['id'], self.__TERMINAL_ID, pwd)
                #     public.print_log('>>>> GET_CURRENT_DIRECTORY[{}_{}]: {}'.format(self._ssh_info['id'], self.__TERMINAL_ID, pwd), _level='error')
                #     public.print_log('>>>> {} {} {}'.format(self._ssh_info['id'], self.__TERMINAL_ID, pwd))

                self._web_socket.send(result)

        except simple_websocket.ws.ConnectionClosed: pass
        except BaseException as e:
            public.print_exc_stack(e)

        finally:
            try:
                self.SSH_SESSION.close()
            except: pass

    # def record(self, rtype, data):
    #
    #     if rtype == 'header':
    #         with open(self._filepath + '/{}.json'.format(my_terms[self._host].filename), 'w') as fw:
    #             fw.write(json.dumps(data) + '\n')
    #             return True
    #     else:
    #         with open(self._filepath + '/{}.json'.format(my_terms[self._host].filename), 'r') as fr:
    #             content = json.loads(fr.read())
    #             stdout = content["stdout"]
    #         atime = time.time()
    #         iodata = [atime - self.time, data]
    #         stdout.append(iodata)
    #         content["stdout"] = stdout
    #         with open(self._filepath + '/{}.json'.format(my_terms[self._host].filename), 'w') as fw:
    #             fw.write(json.dumps(content) + '\n')
    #             self.time = atime
    #             return True
    #     return True

    def set_last_send(self, result):
        last_size = 1024
        if 'last_send' not in my_terms[self._host]:
            my_terms[self._host].last_send = []

        my_terms[self._host].last_send.append(result)
        last_len = len(my_terms[self._host].last_send)
        if last_len > last_size:
            my_terms[self._host].last_send = my_terms[self._host].last_send[last_len - last_size:]

    def not_send(self):
        if 'not_send' in my_terms[self._host]:
            if my_terms[self._host].not_send:
                self._web_socket.send(my_terms[self._host].not_send)
                my_terms[self._host].not_send = ""

    def last_send(self):
        if 'last_send' in my_terms[self._host]:
            for d in my_terms[self._host].last_send:
                self._web_socket.send(d)

    def close(self):
        try:
            self.SSH_SESSION.close()
        except:
            pass
        if self._host in my_terms:
            del my_terms[self._host]

    def run(self, args):
        res = serverModule().get_ssh_info(public.to_dict_obj({
            'id': args.get('id', 0)
        }))

        if not res or not res["status"]:
            # public.print_log('>>>>>> 连接失败： {}'.format(res))
            raise RuntimeError('>>>>>> 连接失败： {}'.format(res['error_msg']))

        self._web_socket = args.ws
        self._ssh_info = res["data"]

        if not self._ssh_info:
            return

        result = self.connect()
        time.sleep(0.1)
        if result:
            sendt = threading.Thread(target=self.send)
            recvt = threading.Thread(target=self.recv)
            sendt.start()
            recvt.start()
            sendt.join()
            recvt.join()
            # if time.time() - my_terms[self._host].last_time > 86400:
            #     self.close()
            # self._web_socket = None

        # 移除当前终端的工作目录
        # self.__terminal_pwd(self._ssh_info['id'], self.__TERMINAL_ID, False)
        self.__TERMINAL_SSH_CONNECTIONS.pop('{}_{}'.format(self._ssh_info['id'], self.__TERMINAL_ID), None)

        try:
            self._web_socket.close()

        except: pass

        # close_time = time.time()
        login_mode = 'pkey'
        # if self._ssh_info.get('pkey') is None:
        #     login_mode = 'password'
        if self._ssh_info['pkey'] == '':
            login_mode = 'password'

        if self._ssh_info['sid'] > 0:
            play_info = {
                "host": self._ssh_info['host'],
                "playback": self.filename,
                "username": self._ssh_info['username'],
                'uid': public.bt_auth('uid'),
                "port": self._ssh_info['port'],
                "login_mode": login_mode,
                "count_time": int(self.DURATIONS),
                "create_time": int(self.connect_time),
            }

            with monitor_db_manager.MonitorDbManager(self._ssh_info['sid']).db_mgr('playrecords') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query() \
                        .name("playrecords") \
                        .insert(play_info)

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)

                    raise e
            # return public.success('添加信息成功')

        # public.print_log("++++++++++++++++{}".format(res['data']['id']))
        play_info = {
            "host": self._ssh_info['host'],
            "ssh_id": res['data']['id'],
            "playback": self.filename,
            "username": self._ssh_info['username'],
            'uid': public.bt_auth('uid'),
            "port": self._ssh_info['port'],
            "login_mode": login_mode,
            "count_time": int(self.DURATIONS),
            "create_time": int(self.connect_time),
        }

        with monitor_db_manager.db_mgr('fortress_player') as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query() \
                    .name("fortress_player") \
                    .insert(play_info)

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)

                raise e

            return public.success('添加信息成功')

    def player(self, args):
        sid = args.get('sid', None)
        id = args.get('id', None)
        query_date = args.get('query_date', None)

        if int(sid) > 0 :
            with monitor_db_manager.MonitorDbManager(sid).db_mgr('playrecords') as db:
                query = db.query()\
                    .name('playrecords') \
                    .field('id', 'host', 'playback', 'username','uid','port', 'login_mode', 'count_time', 'create_time') \
                    .order('create_time', 'desc')

                if query_date is not None and len(query_date) > 0 :
                    query.where('`create_time` BETWEEN ? AND ?', public.get_query_timestamp(query_date))

                ret = public.simple_page(query, args)
        else:
            with monitor_db_manager.db_mgr('fortress_player') as db:
                query = db.query() \
                    .name('fortress_player') \
                    .where("id=?", int(id)) \
                    .field('id', 'host', 'playback', 'username', 'uid', 'port', 'login_mode', 'count_time',
                           'create_time') \
                    .order('create_time', 'desc')

                if query_date is not None and len(query_date) > 0:
                    query.where('`create_time` BETWEEN ? AND ?', public.get_query_timestamp(query_date))

                ret = public.simple_page(query, args)

        with monitor_db_manager.db_mgr('safety') as db:
            uid_username_map = db.query()\
                .name('users') \
                .where_in('uid', list(set(map(lambda x: x['uid'], ret['list']))))\
                .field('uid', 'username')\
                .column('username', 'uid')

        for item in ret['list']:
            item['systemname'] = uid_username_map.get(item['uid'], '')

        return public.success(ret)

    def fortress_player(self, args):
        id = args.get('id', None)
        uid = public.bt_auth('uid')
        keyword = args.get('keyword', None)
        query_date = args.get('query_date', None)
        query2 = basic_monitor_obj.db_easy('ssh_info').field('id')

        ssh_info_ids = self.__uid_check(uid, 16)

        with monitor_db_manager.db_mgr('fortress_player') as db:
            if uid > 1:
                query = db.query() \
                    .name('fortress_player') \
                    .field('*') \
                    .order('create_time', 'desc') \
                    .where_in('ssh_id', ssh_info_ids)
            elif id is not None:
                query = db.query() \
                    .name('fortress_player') \
                    .field('*') \
                    .order('create_time', 'desc') \
                    .where('ssh_id', id)
            else:
                query = db.query() \
                    .name('fortress_player') \
                    .field('*') \
                    .order('create_time', 'desc')

            if keyword is not None and len(keyword) > 0:
                tmp = '%{}%'.format(keyword)
                # query.where('host like ? or ssh_id like ?', [tmp, tmp])
                # query2.where('remark like ?', tmp)
                #
                # query.where('`ssh_id` IN ({})'.format(','.join(map(lambda x: str(x), query2.column('id')))))
                query2.where('host like ? OR remark like ?', [tmp, tmp])

                query.where('(`ssh_id` IN ({}) )'.format(
                    ','.join(map(lambda x: str(x), query2.column('id')))))

            if query_date is not None and len(query_date) > 0:
                query.where('`create_time` BETWEEN ? AND ?', public.get_query_timestamp(query_date))

            ret = public.simple_page(query, args)

        with monitor_db_manager.db_mgr('safety') as db:
            uid_username_map = db.query() \
                .name('users') \
                .where_in('uid', list(set(map(lambda x: x['uid'], ret['list'])))) \
                .field('uid', 'username') \
                .column('username', 'uid')

        with monitor_db_manager.db_mgr() as db:
            remark_list = db.query() \
                .name('ssh_info') \
                .where_in('id', list(set(map(lambda x: x['ssh_id'], ret['list'])))) \
                .field('remark', 'id') \
                .column('remark', 'id')


        for item in ret['list']:
            item['systemname'] = uid_username_map.get(item['uid'], '')
            item['remark'] = remark_list.get(item['ssh_id'], '')

        return public.success(ret)

    # 堡垒机上传文件
    def fortress_upload(self,args):
        '''
             @name 堡垒机上传文件
             @author law<2023-05-29>
             @param  args<dict_obj>
             @return list
        '''
        # 上传文件到主控data/upload下

        # 文件原本的名称
        filename_real = ''

        # 文件随机名称
        filename = uuid.uuid4().hex

        try:
            file = args.get('FILES', {}).get('file', "")
            file_path = os.path.join('{}/data/'.format(public.get_panel_path()), 'upload')
            if not os.path.exists(file_path):
                os.mkdir(file_path)
            filename_real = file.filename
            file.save(os.path.join(file_path, filename))
            file.close()
        except Exception as e:
            return public.error(e)

        ssh_id = args.get('id', None)
        terminal_id = args.get('terminal_id',None)

        # xx = self.__list_all(ssh_id, terminal_id)
        # with open('/www/server/bt-monitor/data/xxyy.txt', 'w') as fp:
        #     fp.write(xx)
        # public.print_log('>>>>>> {} {} {}'.format(ssh_id, terminal_id, xx))
        # return public.success(self.__terminal_pwd_2(ssh_id, terminal_id))

        with monitor_db_manager.db_mgr() as db:
            ssh_info = db.query()\
                .name('ssh_info')\
                .where('id', ssh_id)\
                .find()

        # 记录当前终端的工作目录
        terminal_path = self.__terminal_pwd_2(ssh_id, terminal_id)

        # public.print_log('>>>> {} {} {}'.format(ssh_id, terminal_id, terminal_path))

        if len(ssh_info['pkey']) > 0:
            p_file = StringIO(public.decrypt_password(ssh_info['pkey']))
            password = paramiko.RSAKey.from_private_key(p_file)
            # public.print_log('>>> get ssh password from pkey: {}'.format(password))
        elif len(ssh_info['password']) > 0:
            password = public.decrypt_password(ssh_info['password'])
            # public.print_log('>>> get ssh password from database: {}'.format(password))
        else:
            password = self.__term_conn_wrap_obj(ssh_id, terminal_id).password
            # public.print_log('>>> get ssh password from terminal session: {}'.format(password))

        # 主控上传文件路径
        remote_path = os.path.join('{}/data/'.format(public.get_panel_path()), 'upload/')

        sf = paramiko.Transport(ssh_info['host'], int(ssh_info['port']))
        # sf = self.__sf(ssh_info['host'], int(ssh_info['port']))
        try:
            sf.connect(username=ssh_info['username'], password=password)
            sftp = paramiko.SFTPClient.from_transport(sf)

            # # 判断本地参数是目录还是文件
            # if os.path.isdir(remote_path):
            #     # 遍历本地目录
            #     for f in os.listdir(remote_path):
            #         # public.print_log('++66666666+{}'.format(os.path.join(remote_path + f )))
            #         # public.print_log('++77777777777777+{}'.format(os.path.join(terminal_path)))
            #         # 上传目录中的文件
            #         sftp.put(os.path.join(remote_path+f), os.path.join(terminal_path+'/'+f))
            # else:
            #     # 上传文件
            #     sftp.put(remote_path, terminal_path)

            # 上传目标文件
            if os.path.exists(os.path.join(remote_path, filename)):
                sftp.put(os.path.join(remote_path, filename), os.path.join(terminal_path, filename_real))
        except BaseException as e:
            public.print_exc_stack(e)
            return public.error('上传失败：{}'.format(str(e)))
        finally:
            sf.close()

            # 删除目标文件
            if os.path.exists(os.path.join(remote_path, filename)):
                os.remove(os.path.join(remote_path, filename))
            # os.system('rm -rf {}*'.format(remote_path))

        return public.success("上传成功!")

    # 取消上传文件
    def off_fortress_upload(self, args):
        '''
             @name 取消权限堡垒机上传文件
             @author law<2023-06-07>
             @param  args<dict_obj>
             @return list
        '''

        # ssh_id = args.get('id', None)
        # with monitor_db_manager.db_mgr() as db:
        #     ssh_info = db.query() \
        #         .name('ssh_info') \
        #         .where('id', ssh_id) \
        #         .find()
        #
        # remote_path = os.path.join('{}/data/'.format(public.get_panel_path()), 'upload/')
        # sf = (ssh_info['host'], int(ssh_info['port']))
        # sf.close()
        # os.system('rm -rf {}*'.format(remote_path))

    # 从终端文本中解析当前工作目录
    def __parse_pwd(self, content):
        if len(content) < 5 or len(content) > 256:
            return None

        m = self.__MATCH_PWD_OBJ.match(str(content))
        if m is None:
            return None

        # 解析用户家目录
        if m.group(3) == '~':
            if m.group(2) == 'root':
                return '/root'

            return '/home/{}'.format(m.group(2))

        return m.group(3)

    # 设置/获取终端当前所在目录
    def __terminal_pwd(self, ssh_id, terminal_id, pwd=None):
        k = '{}_{}'.format(ssh_id, terminal_id)

        # 获取
        if pwd is None:
            return self.__PWD_PER_TERMINAL.get(k, None)

        # 删除
        if pwd is False:
            self.__PWD_PER_TERMINAL.pop(k, None)
            return None

        # 设置
        self.__PWD_PER_TERMINAL[k] = pwd
        return pwd

    # 使用pwd命令获取终端当前目录
    def __terminal_pwd_2(self, ssh_id, terminal_id):
        k = '{}_{}'.format(ssh_id, terminal_id)
        if k not in self.__TERMINAL_SSH_CONNECTIONS:
            return None

        return self.__TERMINAL_SSH_CONNECTIONS[k].execute_command('pwd')

    # 使用ls命令获取终端当前目录所有文件
    def __list_all(self, ssh_id, terminal_id):
        k = '{}_{}'.format(ssh_id, terminal_id)
        if k not in self.__TERMINAL_SSH_CONNECTIONS:
            return None

        return self.__TERMINAL_SSH_CONNECTIONS[k].execute_command('ls -alh')

    # 获取TerminalSshConnectionWrap对象
    def __term_conn_wrap_obj(self, ssh_id, terminal_id):
        k = '{}_{}'.format(ssh_id, terminal_id)
        if k not in self.__TERMINAL_SSH_CONNECTIONS:
            raise RuntimeError('terminal-[{}] is disconnected.'.format(k))

        return self.__TERMINAL_SSH_CONNECTIONS[k]

    #   堡垒机权限检查调用
    def __uid_check(self, uid, number):
        """
            查询uid关联role_id
            @param  uid<string>  关联字段    uid查询出 role_id
            @param  number<int>  操作类型
            0-无权限 1-可查看 2-可连接 4-可编辑 8-可删除 16-录像回放查看
            @return
        """
        with monitor_db_manager.db_mgr('safety') as db:
            role_id = db.query() \
                .name('users') \
                .where('`uid`=?', uid) \
                .value('gid')

        with monitor_db_manager.db_mgr() as db:
            ssh_ids = db.query() \
                .name('fortress_role') \
                .where('`role_id` = ?', int(role_id)) \
                .where(' `type` & {} = {}'.format(number, number)) \
                .column('ssh_id')

        return ssh_ids


# 终端会话对象包装类
class TerminalSshConnectionWrap:
    __slots__ = ['__LOCK', '__SSH_SESSION', '__CURRENT_EXECUTING_COMMAND', '__REG_OBJ',
                 '__LAST_CHARS', '__EXECUTING', '__RESULT_BEGIN', '__RESULT_END', '__RESULT',
                 '__RESULT_RAW', 'password']

    __MATCH_PWD_OBJ = re.compile(r'^[\r\n]?(?:\x1b\[K)?(?:\x1b\]0;)?\[?(([^\s#\$\x00-\x1f\x7f]+)@[^\s#\$\x00-\x1f\x7f]+)[ :]? ?([^\s#\$\x00-\x1f\x7f]+)(?:\x07\[?\1[ :]?\3\]?)?\]?[\$#] $')

    def __init__(self, ssh_session):
        self.__LOCK = threading.Lock()
        self.__SSH_SESSION = ssh_session
        self.__CURRENT_EXECUTING_COMMAND = None
        self.__REG_OBJ = None
        self.__LAST_CHARS = ''
        self.__EXECUTING = False
        self.__RESULT_BEGIN = None
        self.__RESULT_END = None
        self.__RESULT_RAW = ''
        self.__RESULT = None
        self.password = None

    # 设置上一次发送的字符
    def set_last_chars(self, chars):
        if str(chars).find('\r') > -1 or str(chars).find('\n') > -1:
            str_end = re.split(r'[\r\n]+', str(chars))[-1]
            if len(str_end.strip()) == 0:
                self.__LAST_CHARS = ''
                return

            self.__LAST_CHARS = str(str_end)
            return

        self.__LAST_CHARS += str(chars)

    # 获取上一次发送的字符
    def get_last_chars(self):
        return self.__LAST_CHARS

    # 调度
    def schedule(self, recv_chars):
        if not self.__EXECUTING:
            return False

        self.__RESULT_RAW += str(recv_chars)

        if str(self.__RESULT_RAW).find('\r') > -1 or str(self.__RESULT_RAW).find('\n') > -1:
            rows = re.split(r'[\r\n]+', str(self.__RESULT_RAW))
        else:
            rows = [str(self.__RESULT_RAW)]

        for i in range(len(rows) - 1, -1, -1):
            if self.__REG_OBJ.match(rows[i]):
                self.__RESULT = []
                self.__RESULT_BEGIN = i + 1
                break

            if self.__MATCH_PWD_OBJ.search(rows[i]):
                self.__EXECUTING = False
                self.__RESULT_END = i
                break

        if not self.__EXECUTING:
            self.__RESULT = rows[self.__RESULT_BEGIN:self.__RESULT_END]
            self.__RESULT_RAW = ''
            self.__RESULT_BEGIN = None
            self.__RESULT_END = None

        return True

    # 检查本次调度任务是否已经结束
    def is_schedule_end(self):
        return not self.__EXECUTING

    # 执行命令并获取结果
    def execute_command(self, command='pwd'):
        with Locker.acquire(self.__LOCK):
            delete_cnt = len(self.__LAST_CHARS)
            # public.print_log('LAST_CHARS <<< {} {}'.format(delete_cnt, self.__LAST_CHARS), _level='error')

            msg = b''

            if delete_cnt > 0:
                msg += b'\x7f' * delete_cnt

            msg += command.encode()
            msg += b'\n'

            self.__CURRENT_EXECUTING_COMMAND = command
            self.__REG_OBJ = re.compile(r'^(?:\x08\x1b\[K)*{}'.format(self.__CURRENT_EXECUTING_COMMAND))
            self.__EXECUTING = True
            self.__RESULT = None
            self.__RESULT_BEGIN = False

            self.__SSH_SESSION.send(msg)

            cost_milli_sec = 0

            for _ in iter(lambda: self.__EXECUTING, False):
                # 最大等待3s
                if cost_milli_sec > 3000:
                    self.__EXECUTING = False
                    self.__RESULT_BEGIN = False
                    break
                time.sleep(0.1)
                cost_milli_sec += 100

            if self.__RESULT is not None:
                self.__RESULT = '\n'.join(self.__RESULT).strip()

            # public.print_log('>>>>>>>>>>>> {}'.format(self.__RESULT.encode()), _level='error')

            return self.__RESULT
