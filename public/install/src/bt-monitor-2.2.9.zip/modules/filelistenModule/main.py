# encoding: utf-8
import re, time
import core.include.public as public
from core.include.monitor_helpers import basic_monitor_obj, monitor_db_manager, warning_obj
from concurrent.futures import ThreadPoolExecutor


class main:
    '''
        @name 目录/文件监听模块
        @author Zhj<2023-04-26>
    '''

    # 目录/文件监控帮助函数
    def __filelisten_help(self, sid, action, params=None):
        '''
            @name 病毒扫描帮助函数
            @author Zhj<2023-04-03>
            @param sid<int>         主机ID
            @param action<string>   接口名称
            @param params<?dict>    请求参数
            @return None|dict
        '''
        pdata = {}

        if params is not None and isinstance(params, dict):
            pdata.update(params)

        res = public.send_agent_msg(
            public.get_serverid_bysid(sid),
            'filelisten',
            action,
            timeout=60,
            pdata=public.g_pdata(pdata))

        if not res:
            return None

        return res.get('body', {}).get('body', None)

    # TODO 添加目录/文件监听
    def add_file_listener(self, args):
        sid = args.get('sid', None)
        file_path = args.get('file_path', None)
        # is_dir = args.get('is_dir', 0)

        if sid is None:
            return public.error('缺少参数：sid')

        if file_path is None:
            return public.error('缺少参数：file_path')

        return public.success(self.__filelisten_help(sid, 'WriteFilesToAgent', {
            'files': file_path,
            'action': 'add',
        }))

    # TODO 添加目录/文件监听
    def new_add_file_listener(self, args):
        sid = args.get('sid', None)
        file_path = args.get('file_path', None)
        is_dir = args.get('is_dir', 0)

        if sid is None:
            return public.error('缺少参数：sid')

        if re.match(r'^-?\d+(?:,-?\d+)*$', str(sid)):
            return public.error('参数格式错误：sid')

        if file_path is None:
            return public.error('缺少参数：file_path')

        sid_list = str(sid).split(',')

        insert_data = []

        with ThreadPoolExecutor(max_workers=10) as t:
            fs = []

            for sid_tmp in sid_list:
                fs.append((t.submit(self.__filelisten_help, sid_tmp, 'WriteFilesToAgent', {
                    'files': file_path,
                    'action': 'add',
                }), sid_tmp))

            for (f, sid_tmp) in fs:
                res = f.result()

                # 添加监听成功
                if public.check_agent_response_success(res):
                    insert_data.append({
                        'sid': int(sid_tmp),
                        'is_dir': int(is_dir),
                        'listening': 1,
                        'operator': public.bt_auth('uid'),
                        'file_path': file_path,
                    })
                    # return public.error('监听失败：{}'.format(res.get('errinfo', '--')))

        basic_monitor_obj.db_easy('server_file_listeners').insert_all(insert_data)

        if len(insert_data) < len(sid_list):
            return public.success('部分文件监听成功，监听失败可能是因为重复添加监听')

        return public.success('操作成功')

    # TODO 移除目录/文件监听
    def remove_file_listener(self, args):
        sid = args.get('sid', None)
        file_path = args.get('file_path', None)

        if sid is None:
            return public.error('缺少参数：sid')

        if file_path is None:
            return public.error('缺少参数：file_path')

        return public.success(self.__filelisten_help(sid, 'WriteFilesToAgent', {
            'files': file_path,
            'action': 'del',
        }))

    # TODO 移除目录/文件监听
    def new_remove_file_listener(self, args):
        # sid = args.get('sid', None)
        # file_path = args.get('file_path', None)
        listen_id = args.get('listen_id', None)

        # if sid is None:
        #     return public.error('缺少参数：sid')

        # if file_path is None:
        #     return public.error('缺少参数：file_path')

        if listen_id is None:
            return public.error('缺少参数：listen_id')

        if re.match(r'^-?\d+(?:,-?\d+)*$', str(listen_id)):
            return public.error('参数格式错误：listen_id')

        listen_id_list = str(listen_id).split(',')

        listeners = basic_monitor_obj.db_easy('server_file_listeners') \
            .where_in('id', listen_id_list) \
            .field('id', 'sid', 'file_path') \
            .select()

        success_ids = []

        with ThreadPoolExecutor(max_workers=10) as t:
            fs = []

            for listener in listeners:
                fs.append((t.submit(self.__filelisten_help, listener['sid'], 'WriteFilesToAgent', {
                    'files': listener['file_path'],
                    'action': 'del',
                }), listener['id']))

            for (f, listener_id) in fs:
                res = f.result()

                # 移除监听成功
                if public.check_agent_response_success(res):
                    success_ids.append(listener_id)
                    # return public.error('取消监听失败：{}'.format(res.get('errinfo', '--')))

        basic_monitor_obj.db_easy('server_file_listeners') \
            .where_in('id', success_ids) \
            .update({
            'listening': 0,
            'operator': public.bt_auth('uid'),
            'update_time': int(time.time()),
        })

        if len(success_ids) < len(listener):
            return public.success('部分文件取消监听成功')

        return public.success('操作成功')

    # TODO 获取目录/文件监听列表
    def get_file_listeners(self, args):
        sid = args.get('sid', None)
        query_date = args.get('query_date', None)
        is_listening = args.get('is_listening', None)

        query = basic_monitor_obj.db_easy('server_file_listeners')

        if sid is not None and re.match(r'^-?\d+(?:,-?\d+)*$', str(sid)):
            query.where_in('sid', str(sid).split(','))

        if query_date is not None and len(query_date) > 0:
            query.where('create_time >= ? and create_time <= ?', public.get_query_timestamp(query_date))

        if is_listening is not None and len(is_listening) > 0:
            query.where('listening', int(is_listening))

        def query_handler(query, keyword):
            query.where('`file_path` like ?', '%{}%'.format(keyword))

        public.add_retrieve_keyword_query(query, args, query_handler)

        ret = public.simple_page(query, args)

        with monitor_db_manager.db_mgr('safety') as db:
            users = db.query() \
                .name('users') \
                .where_in('uid', list(map(lambda x: x['operator'], ret['list']))) \
                .field('uid', 'username') \
                .column('username', 'uid')

        # 组装服务器信息和操作人信息
        for item in ret['list']:
            item['operator_username'] = users.get(item['uid'], '')

        return public.success(ret)

    # TODO 获取监听结果
    def get_listen_result(self, args):
        sid = args.get('sid', None)

        if sid is None:
            return public.error('缺少参数：sid')

        return public.success(self.__filelisten_help(sid, 'GetFileListenResult'))

    def __get_listen_result_all(self):
        listeners = basic_monitor_obj.db_easy('server_file_listeners')\
            .where('listening', 1)\
            .field('id', 'sid', 'file_path')\
            .select()

        insert_data = []

        listener_map = {}

        for listener in listeners:
            listener_map['{}|{}'.format(listener['sid'], listener['file_path'])] = listener['id']

        with ThreadPoolExecutor(max_workers=10) as t:
            fs = []

            for sid in set(map(lambda x: x['sid'], listeners)):
                fs.append((t.submit(self.__filelisten_help, sid, 'GetFileListenResult'), sid))

            for (f, sid) in fs:
                res = f.result()

                # 获取监听结果成功
                if public.check_agent_response_success(res) and 'Infos' in res and isinstance(res['Infos'], list):
                    for item in res['Infos']:
                        k = '{}|{}'.format(sid, item['file'])
                        if k not in listener_map:
                            continue

                        try:
                            insert_data.append({
                                'listener_id': listener_map[k],
                                'type': self.__convert_event_type_to_listen_type(item['action']),
                            })
                        except:
                            pass

        if len(insert_data) > 0:
            basic_monitor_obj.name('server_file_listen_history').insert_all(insert_data)

    # 转换文件监听触发事件事件类型
    def __convert_event_type_to_listen_type(self, event_type):
        d = {
            'CREATE': 0,
            'WRITE': 1,
            'REMOVE': 2,
            'RENAME': 3,
            'CHMOD': 4,
        }

        if event_type not in d:
            raise RuntimeError('invalid event_type: {}'.format(event_type))

        return d[event_type]

    # # 远程执行shell脚本
    # def exec_shell(self, args):
    #     sid = args.get('sid', None)
    #     shell = args.get('shell', None)
    #
    #     if sid is None:
    #         return public.error('缺少参数：sid')
    #
    #     if shell is None:
    #         return public.error('缺少参数：shell')
    #
    #     res, err = basic_monitor_obj.exec_shell_with_agent(sid, shell)
    #
    #     # return public.success(public.send_agent_msg(
    #     #     public.get_serverid_bysid(sid),
    #     #     'exec_shell',
    #     #     'GetShellExecResult',
    #     #     timeout=300,
    #     #     pdata=public.g_pdata({
    #     #         'command': shell,
    #     #     })))
    #
    #     return public.success({
    #         'success': err is None,
    #         'res': res,
    #         'err': str(err) if err is not None else err,
    #     })
    #
    # # 获取文件属性
    # def get_fileinfo(self, args):
    #     sid = args.get('sid', None)
    #     file_path = args.get('file_path', None)
    #
    #     if sid is None:
    #         return public.error('缺少参数：sid')
    #
    #     if file_path is None:
    #         return public.error('缺少参数：file_path')
    #
    #     res = public.send_agent_msg(
    #         public.get_serverid_bysid(sid),
    #         'File',
    #         'FileInfo',
    #         timeout=60,
    #         pdata=public.g_pdata({
    #             'file': file_path,
    #         }))
    #
    #     return public.success(res)
