import core.include.public as public
from gettext import find
import json,time,re,os,copy
import sqlite3
from flask import Response,request
from core import session
from core.include.monitor_helpers import basic_monitor_obj, monitor_db_manager

class main:

    def __to_sort(self,data,pid,key):
        '''
            @name 无限级分类排序
            @author hwliang
            @param data<list> 待排序数据
            @param pid<int> 父级id
            @param key<string> 排序字段
            @return list
        '''
        result = []
        for i in data:
            if i['pid'] == pid:
                result.append(i)
                result += self.__to_sort(data,i[key],key)
        return public.return_data(True,result)

    def get_user_list(self,args):
        '''
            @name 获取用户列表
            @author hwliang
            @return list
        '''
        try:
            conn = None
            cur = None

            conn = sqlite3.connect("/www/server/bt-monitor/data/safety.db")
            cur = conn.cursor()
            fields = "u.uid,u.username,u.username_hash,u.password,u.nickname,"\
            "u.status,u.ps,u.last_login_time,u.last_login_ip,u.create_time," \
            "u.pwd_update_time,u.expire_day,u.gid,g.name"
            sql = "select {} from bt_users u left join bt_role g on u.gid==g.role_id;"
            sor = cur.execute(sql.format(fields))
            res = sor.fetchall()
            data = []

            in_demo = basic_monitor_obj.in_demo()
            for line in res:
               item = {
                    "uid": line[0],
                    "username": line[1],
                    "username_hash": line[2],
                    "password": line[3],
                    "nickname": line[4],
                    "status": line[5],
                    "ps": line[6],
                    "last_login_time": line[7],
                    "last_login_ip": line[8],
                    "create_time": line[9],
                    "pwd_update_time": line[10],
                    "expire_day": line[11],
                    "gid": line[12],
                    "gname": line[13],
               }

               # DEMO
               if in_demo:
                   item['last_login_ip'] = '****'

               data.append(item)
            return public.return_data(True, data)
        except Exception as e:
            return public.return_data(False, "用户信息异常: {}".format(e))
        finally:
            cur and cur.close()
            conn and conn.close()
        # sql = public.M('users')
        # user_list = sql.field('uid,gid,username,nickname,status,ps,last_login_time,last_login_ip,create_time').order('uid DESC').select()
        # return user_list

    def set_user_status(self,args):
        '''
            @name 设置用户状态
            @author hwliang
            @param uid <int> 用户id
            @param status <int> 状态
            @return dict
        '''
        uid = args.get('uid/d',0)
        if not uid: return public.return_data(False,'UID格式不正确')
        status = args.get('status/d',-1)
        if not status in [0,1]: return public.return_data(False,'status值必需为0或1')

        # 获取当前登录用户信息
        if int(public.bt_auth('uid')) == int(uid):
            return public.error('操作失败：您不能操作自己')

        # DEMO
        if basic_monitor_obj.in_demo():
            return public.error('DEMO不支持此操作')

        sql = public.M('users')
        userInfo = sql.where('uid=?',uid).find()
        if not userInfo: return public.return_data(False,'用户不存在')
        sql.where('uid=?',uid).setField('status',status)
        status_msg = '禁用' if status == 0 else '启用'
        public.WriteLog('用户管理','设置用户[%s]状态为[%s]' % (userInfo['username'],status_msg))
        return public.return_data(True,'设置成功')

    # def set_user_ps(self,args):
    #     '''
    #         @name 设置用户备注
    #         @author hwliang
    #         @param uid <int> 用户id
    #         @param ps <string> 备注
    #         @return dict
    #     '''
    #     uid = args.get('uid/d',0)
    #     if not uid: return public.return_data(False,'UID格式不正确')
    #     sql = public.M('users')
    #     userInfo = sql.where('uid=?',uid).find()
    #     if not userInfo: return public.return_data(False,'用户不存在')
    #     ps = args.get('ps/xss','')
    #     sql.where('uid=?',uid).setField('ps',ps)
    #     public.WriteLog('用户管理','设置用户[%s]备注为[%s]' % (userInfo['username'],ps))
    #     return public.return_data(True,'设置成功')

    def __get_user_pwd(self,pwd,salt):
        '''
            @name 获取用户密码
            @author hwliang
            @param pwd <string> 密码
            @param salt <string> 盐
            @return string
        '''
        return public.md5(public.md5(pwd + '_bt') + salt)

    def check_password_safe(self,password):
        '''
            @name 密码复杂度验证
            @auther hwliang<2021-10-18>
            @param password(string) 密码
            @return bool
        '''
        num = 0
        # 密码是否包含数字
        if re.search(r'[0-9]+',password): num += 1
        # 密码是否包含小写字母
        if re.search(r'[a-z]+',password): num += 1
        # 密码是否包含大写字母
        if re.search(r'[A-Z]+',password): num += 1
        # 密码是否包含特殊字符
        if re.search(r'[^\w\s]+',password): num += 1
        # 密码是否包含以上任意3种组合
        if num < 3: return False
        return True

    def set_user_pwd(self,args):
        '''
            @name 设置用户密码
            @author hwliang
            @param uid <int> 用户id
            @param pwd <string> 密码
            @return dict
        '''
        uid = args.get('uid/d',0)
        pwd = args.get('pwd/s','')
        if not uid: return public.return_data(False,'UID格式不正确')

        # 密码长度验证
        if len(pwd) < 8: return public.error('密码长度必须8位或以上')

        if public.get_config_value('config', 'password_complexity', False) and not self.check_password_safe(pwd):
            return public.return_data(False,'密码复杂度要求：密码长度8位以上，包含数字、小写字母、大写字母、特殊符号任意3种组合!')

        # DEMO
        if basic_monitor_obj.in_demo():
            return public.error('DEMO不支持此操作')

        userInfo = public.M('users').where('uid=?',uid).find()
        if not userInfo: return public.return_data(False,'用户不存在')
        salt = public.GetRandomString(12)
        password = self.__get_user_pwd(pwd,salt)
        sql = public.M('users')
        sql.where('uid=?',uid).update({'password':password,'salt':salt,'pwd_update_time':int(time.time())})
        public.WriteLog('用户管理','修改用户[%s]的密码成功' % (userInfo['username'],))
        return public.return_data(True,'修改成功')

    # def set_user_nickname(self,args):
    #     '''
    #         @name 修改用户昵称
    #         @author hwliang
    #         @param uid <int> 用户id
    #         @param nickname <string> 昵称
    #         @return dict
    #     '''
    #     uid = args.get('uid/d',0)
    #     nickname = args.get('nickname/xss','')
    #     if not uid: return public.return_data(False,'UID格式不正确')
    #     if not nickname: return public.return_data(False,'昵称不能为空')
    #     sql = public.M('users')
    #     userInfo = sql.where('uid=?',uid).find()
    #     if not userInfo: return public.return_data(False,'用户不存在')
    #     sql.where('uid=?',uid).setField('nickname',nickname)
    #     public.WriteLog('用户管理','修改用户[%s]的昵称为[%s]' % (userInfo['username'],nickname))
    #     return public.return_data(True,'修改成功')

    def create_user(self,args):
        '''
            @name 创建用户
            @author hwliang
            @param username <string> 用户名
            @param pwd <string> 密码
            @param nickname <string> 昵称
            @param ps <string> 备注
            @param gid <int> 组id
            @return dict
        '''
        username = args.get('username/s','')
        pwd = args.get('pwd/s','')
        nickname = args.get('nickname/xss','')
        ps = args.get('ps/xss','')
        gid = args.get('gid/d',0)
        if not username: return public.return_data(False,'用户名不能为空')
        if not pwd: return public.return_data(False,'密码不能为空')
        if not gid: return public.return_data(False,'用户组不能为空')
        if len(username) < 5: return public.return_data(False,'用户名长度不能小于5位')
        if len(pwd) < 8: return public.return_data(False,'密码长度不能小于8位')
        if not re.match("^[\w\.-]+$",username): return public.return_data(False,'用户名格式不正确')
        sql = public.M('users')
        if sql.where('username=?',username).count(): return public.return_data(False,'用户名已存在')
        if sql.where('nickname=?',nickname).count(): return public.return_data(False,'昵称已存在')
        salt = public.GetRandomString(12)
        password = self.__get_user_pwd(pwd,salt)
        day_time = int(time.time())
        uid = sql.add('username,username_hash,password,salt,nickname,ps,gid,create_time,pwd_update_time',(username,public.md5(username),password,salt,nickname,ps,gid,day_time,day_time))
        if not uid: return public.return_data(False,'创建失败')
        if isinstance(uid,str): return public.return_data(False,uid)
        public.WriteLog('用户管理','创建用户[%s]成功' % (username))
        return public.return_data(True,'创建成功')


    def modify_user(self,args):
        '''
            @name 修改用户
            @author hwliang
            @param uid <int> 用户id
            @param username <string> 用户名
            @param pwd <string> 密码
            @param nickname <string> 昵称
            @param ps <string> 备注
            @param gid <int> 组id
            @return dict
        '''
        uid = args.get('uid/d',0)
        username = args.get('username/xss','')
        pwd = args.get('pwd/s','')
        nickname = args.get('nickname/xss','')
        ps = args.get('ps/xss','')
        gid = args.get('gid/d',0)
        if not uid: return public.return_data(False,'UID格式不正确')
        if not username: return public.return_data(False,'用户名不能为空')
        if not gid: return public.return_data(False,'用户组不能为空')
        if len(username) < 5: return public.return_data(False, '用户名长度不能小于5位')
        if pwd and len(pwd) < 8: return public.return_data(False,'密码长度不能小于8位')

        # DEMO
        if basic_monitor_obj.in_demo():
            return public.error('DEMO不支持此操作')

        sql = public.M('users')
        userInfo = sql.where('uid=?',uid).find()
        if not userInfo: return public.return_data(False,'用户不存在')
        if username != userInfo['username']:
            if sql.where('username=?',username).count(): return public.return_data(False,'用户名已存在')
        if nickname != userInfo['nickname']:
            if sql.where('nickname=?',nickname).count(): return public.return_data(False,'昵称已存在')
        if pwd:
            salt = public.GetRandomString(12)
            password = self.__get_user_pwd(pwd,salt)
            sql.where('uid=?',uid).update({'password':password,'salt':salt,'pwd_update_time':int(time.time())})

        sql.where('uid=?',uid).update({'username':username,'username_hash':public.md5(username),'nickname':nickname,'ps':ps,'gid':gid})
        public.WriteLog('用户管理','修改用户[%s]的信息' % (userInfo['username']))
        return public.return_data(True,'修改成功')


    def remove_user(self,args):
        '''
            @name 删除用户
            @author hwliang
            @param uid <int> 用户id
            @return dict
        '''
        uid = args.get('uid/d',0)
        if not uid: return public.return_data(False,'UID格式不正确')
        sql = public.M('users')
        userInfo = sql.where('uid=?',uid).find()
        if not userInfo: return public.return_data(False,'用户不存在')

        # 获取当前登录用户信息
        if int(public.bt_auth('uid')) == int(uid):
            return public.error('操作失败：您不能操作自己')

        # DEMO
        if basic_monitor_obj.in_demo():
            return public.error('DEMO不支持此操作')

        sql.where('uid=?',uid).delete()
        public.WriteLog('用户管理','删除用户[%s]成功' % (userInfo['username']))

        return public.return_data(True,'删除成功')



    def get_role_list(self,args):
        '''
            @name 获取角色列表
            @author hwliang
            @return list
        '''
        sql = public.M('role')
        data = sql.field('role_id,name,pid,status,ps').select()
        return public.return_data(True,data)


    def create_role(self,args):
        '''
            @name 创建角色
            @author hwliang
            @param name <string> 角色名
            @param status<int> 状态 0.禁用 1.启用
            @param ps <string> 备注
            @param pid <int> 父角色id
            @return dict
        '''
        name = args.get('name/xss','')
        ps = args.get('ps/xss','')
        pid = args.get('pid/d',0)
        status = args.get('status/d',1)
        if not name: return public.return_data(False,'角色名不能为空')
        if not status in [0,1]: return public.return_data(False,'状态值不正确')
        sql = public.M('role')
        if sql.where('name=?',name).count(): return public.return_data(False,'角色名已存在')
        if pid and not sql.where('role_id=?',pid).count(): return public.return_data(False,'父角色不存在')
        role_id = sql.add('name,pid,status,ps',(name,pid,status,ps))
        if not role_id: return public.return_data(False,'创建失败')
        public.WriteLog('用户管理','创建角色[%s]成功' % (name))
        return public.return_data(True,'创建成功')


    def modify_role(self,args):
        '''
            @name 修改角色
            @author hwliang
            @param role_id <int> 角色id
            @param name <string> 角色名
            @param status<int> 状态 0.禁用 1.启用
            @param ps <string> 备注
            @param pid <int> 父角色id
            @return dict
        '''
        role_id = args.get('role_id/d',0)
        name = args.get('name/xss','')
        ps = args.get('ps/xss','')
        pid = args.get('pid/d',0)
        status = args.get('status/d',1)
        if not role_id: return public.return_data(False,'角色ID不能为空')
        if not name: return public.return_data(False,'角色名不能为空')
        if not status in [0,1]: return public.return_data(False,'状态值不正确')
        sql = public.M('role')
        if sql.where('name=? AND role_id!=?',(name,role_id)).count(): return public.return_data(False,'角色名已存在')
        if pid and not sql.where('role_id=?',pid).count(): return public.return_data(False,'父角色不存在')
        sql.where('role_id=?',role_id).save('name,pid,status,ps',(name,pid,status,ps))
        public.WriteLog('用户管理','修改角色[%s]成功' % (name))
        return public.return_data(True,'修改成功')


    def remove_role(self,args):
        '''
            @name 删除角色
            @author hwliang
            @param role_id <int> 角色id
            @return dict
        '''
        role_id = args.get('role_id/d',0)
        if not role_id: return public.return_data(False,'角色ID不正确')
        sql = public.M('role')
        roleInfo = sql.where('role_id=?',role_id).find()
        if not roleInfo: return public.return_data(False,'角色不存在')
        if public.M('users').where('gid=?',role_id).count():
            return public.return_data(False,'该角色上有用户，不能删除')
        sql.where('role_id=?',role_id).delete()

        # 删除角色权限关系
        public.M('access').where('role_id=?',role_id).delete()
        # 操作添加日志
        public.WriteLog('用户管理','删除角色[%s]成功' % (roleInfo['name']))
        return public.return_data(True,'删除成功')


    def set_role_status(self,args):
        '''
            @name 设置角色状态
            @author hwliang
            @param role_id <int> 角色id
            @param status <int> 状态 0.禁用 1.启用
            @return dict
        '''
        role_id = args.get('role_id/d',0)
        status = args.get('status/d',0)
        if not role_id: return public.return_data(False,'角色ID不正确')
        if not status in [0,1]: return public.return_data(False,'状态值不正确')
        sql = public.M('role')
        roleInfo = sql.where('role_id=?',role_id).find()
        if not roleInfo: return public.return_data(False,'角色不存在')
        sql.where('role_id=?',role_id).save('status',status)
        status_msg = '禁用' if status == 0 else '启用'
        public.WriteLog('用户管理','设置角色[%s]状态为[%s]' % (roleInfo['name'],status_msg))
        return public.return_data(True,'设置成功')

    def set_role_access(self,args):
        '''
            @name 设置角色权限
            @author hwliang
            @param role_id <int> 角色id
            @param access <string> 权限信息(node_id,node_id,node_id),多个用逗号隔开,如：1,2,3
            @return dict
        '''
        role_id = args.get('role_id/d',0)
        access = args.get('access','')
        if not role_id: return public.return_data(False,'角色ID不正确')
        sql = public.M('role')
        roleInfo = sql.where('role_id=?', role_id).find()
        if not roleInfo: return public.return_data(False, '角色不存在')

        node_sql = public.M('node')
        access_sql = public.M('access')

        # 删除所有全局权限
        if not access:
            access_sql.where('role_id=? AND sid=0', (role_id,)).delete()
            return public.return_data(True, '权限更新成功')

        access_list = access.split(",")


        # 获取当前角色权限
        menu_list = access_sql.field("node_id").where('role_id=? AND sid=0 AND level=1',(role_id)).select()
        menu_list = [node["node_id"] for node in menu_list]

        module_list = access_sql.field("node_id").where('role_id=? AND sid=0 AND level=2',(role_id)).select()
        module_list = [node["node_id"] for node in module_list]

        access_menu_list = []
        access_module_list = []

        for node_id in access_list:
            node = node_sql.field("node_id,pid,level").where("node_id=?", (node_id)).find()

            if node["level"] == 1:
                if node["node_id"] not in access_menu_list:
                    access_menu_list.append(node["node_id"])

            if node["level"] == 2:
                access_module_list.append(node["node_id"])

                if node["pid"] not in access_menu_list:
                    access_menu_list.append(node["pid"])

        # 需要删除的
        delete_access = list(set(menu_list).difference(set(access_menu_list)))
        delete_access.extend(list(set(module_list).difference(set(access_module_list))))

        if delete_access:
            delete_access = ",".join([str(i) for i in delete_access])
            access_sql.where(f'role_id=? AND node_id in ({delete_access}) AND sid=0', (role_id)).delete()

        # 添加
        add_menu_access = list(set(access_menu_list).difference(set(menu_list)))
        add_module_access = list(set(access_module_list).difference(set(module_list)))

        # 添加没有的权限
        for node_id in add_menu_access:
            access_sql.addAll('role_id,node_id,sid,level', (role_id, node_id, 0, 1))

        for node_id in add_module_access:
            access_sql.addAll('role_id,node_id,sid,level', (role_id, node_id, 0, 2))

        # 提交事务
        access_sql.commit()

        public.WriteLog('用户管理','更新角色[%s]权限成功' % (roleInfo['name']))
        return public.return_data(True,'权限更新成功')

    def set_role_server_access(self,args):
        '''
            @name 设置角色服务器权限
            @author hwliang
            @param role_id <int> 角色id
            @param access <string> 权限信息(sid|node_id),多个用逗号隔开,如：1|1,2|2,3|3
            @return dict
        '''
        role_id = args.get('role_id/d',0)
        access = args.get('access','')
        if not role_id: return public.return_data(False,'角色ID不正确')
        sql = public.M('role')
        roleInfo = sql.where('role_id=?',role_id).find()
        if not roleInfo: return public.return_data(False,'角色不存在')


        node_sql = public.M('node')
        access_sql = public.M('access')

        # 删除所有权限
        if not access:
            access_sql.where('role_id=? AND sid=0', (role_id,)).delete()

        access_list = access.split(",")
        # 获取当前角色权限

        # 添加没有的权限
        for access in access_list:
            sid,node_id,status = access.split("|")

            if int(status) == 1 : # 添加
                node = node_sql.field("node_id,level,pid").where("node_id=?", (node_id)).find()
                # 依赖权限
                pid = node["pid"]
                if pid != 0 and f"{sid}|{pid}|{status}" not in access_list and access_sql.where('role_id=? AND node_id=? AND sid=?', (role_id, pid,sid)).count() == 0:
                    pid_node = node_sql.field("node_id,level,pid").where("node_id=?", (pid)).find()
                    access_sql.addAll('role_id,node_id,sid,level',
                                      (role_id, pid_node["node_id"], sid, pid_node["level"]))
                # 添加事务
                access_sql.addAll('role_id,node_id,sid,level', (role_id, node["node_id"], sid, node["level"]))
            else:# 删除
                access_sql.where('role_id=? AND node_id=? AND sid=?', (role_id, node_id, sid)).delete()
                access_sql.where('role_id=? AND pid=? AND sid=?', (role_id, node_id, sid)).delete()

        # 提交事务
        access_sql.commit()

        public.WriteLog('用户管理','更新角色[%s]服务器权限成功' % (roleInfo['name']))
        return public.return_data(True,'权限更新成功')

    def get_role_access(self,args):
        '''
            @name 获取角色权限
            @author hwliang
            @param role_id <int> 角色id
            @return list
        '''
        role_id = args.get('role_id/d',0)
        if not role_id: return public.return_data(False,'角色ID不正确')

        access_sql = public.M('access')

        node_list = access_sql.field("node_id").where("role_id=? AND sid=0",(role_id)).select()
        node_list = [i["node_id"] for i in node_list]

        return public.return_data(True,node_list)

    def get_role_server(self,args):
        '''
            @name 获取角色服务器权限
            @author hwliang
            @param role_id <int> 角色id
            @return list
        '''
        role_id = args.get('role_id/d', 0)
        server_keywords = args.get('keywords', None)
        group_id = args.get('group_id', None)
        if not role_id: return public.return_data(False, '角色ID不正确')

        access_sql = public.M('access')
        node_sql = public.M('node')
        server_query = basic_monitor_obj.db_easy('servers')

        # 获取服务器信息
        server_query = server_query\
            .alias('s').left_join('server_group sg', 's.group_id=sg.id')\
            .field("sid", "group_id", "ip", "remark", 'sg.name as group_name')

        if not group_id is None:
            server_query.where("group_id",group_id)

        if server_keywords:
            server_query.where("ip like ? or remark like ?",(f"%{server_keywords}%",f"%{server_keywords}%"))

        server_list = server_query.select()
        # 获取权限
        server_access_list = node_sql.field('node_id,name,title').where("level in (4,5)", ()).select()

        for server in server_list:

            temp = copy.deepcopy(server_access_list)
            # 获取节点详情
            for server_access in temp:
                server_access["is_access"] = access_sql.field("node_id").where("role_id=? AND node_id=? AND sid=?", (role_id,server_access["node_id"],server["sid"])).count() > 0

            server["node_list"] = temp

        return public.return_data(True, server_list)

    def get_access_node_list(self,args):
        '''
            @name 获取节点列表
            @author hwliang
            @return list
        '''
        node_sql = public.M('node')
        menu_list = node_sql.field('node_id,name,title,ps,pid,level').where("level=1", ()).select()

        for menu in menu_list:
            module_list = node_sql.field('node_id,name,title,ps,pid,level').where("pid=? AND level=2", (menu["node_id"])).select()
            menu["node_list"] = module_list

        return public.return_data(True,menu_list)

    #  堡垒机权限列表
    def get_fortress_list(self, args):
        '''
              @author law<2023-05-31>
              @param  args<dict_obj>
              @return list
        '''
        role_id = args.get('role_id', None)  # 角色ID
        server_keywords = args.get('keywords', None)  # 搜索关键字
        query = basic_monitor_obj.db_easy('ssh_info')\
            .field('id as ssh_id', 'host', 'remark')

        if server_keywords:
            query.where("host like ? OR remark like ?", ['%{}%'.format(server_keywords), '%{}%'.format(server_keywords)])

        server_list = query.select()

        role_access_map = basic_monitor_obj.db_easy('fortress_role')\
            .where('role_id', role_id)\
            .field('ssh_id', 'type')\
            .column('type', 'ssh_id')

        # 权限初始值
        default_permissions = [
            {
                'name': '查看',
                'value': 1,
                "access": False
            },
            {
                'name': '连接',
                'value': 2,
                "access": False
            },
            {
                'name': '编辑',
                'value': 4,
                "access": False
            },
            {
                'name': '删除',
                'value': 8,
                "access": False
            },
            {
                'name': '终端回放',
                'value': 16,
                "access": False
            },
        ]

        for item in server_list:
            item['permissions'] = []

            for permission in default_permissions:
                item['permissions'].append({
                    'name': permission['name'],
                    'value': permission['value'],
                    'access': role_access_map.get(item['ssh_id'], 0) & permission['value'] == permission['value'],
                })

        return public.success(server_list)

    #  设置堡垒机权限
    def set_fortress_list(self, args):
        '''
              @author law<2023-05-31>
              @param role_id <int> 角色id
              @param access <string> 权限信息(ssh_id|type),多个用逗号隔开,如：1|1,2|2,3|3
              @return list
        '''

        role_id = args.get('role_id/d', 0)
        access = args.get('access', '')
        public.print_log("+++{}".format(access), _level="error")
        if access is None:
            return public.error('缺少参数：access')

        access_list = access.split(',')
        if not role_id: return public.return_data(False, '角色ID不正确')

        insert_data = []
        for temp in access_list:
            ssh_id,type = temp.split("|")
            insert_data.append({
                "role_id": role_id,
                'ssh_id': ssh_id,
                'type': type,
            })

        ssh_id_list  = [int(x.split("|")[0]) for x in access_list]
        with monitor_db_manager.db_mgr() as db:
            db.autocommit(False)

            db.query().name('fortress_role')\
                .where('role_id', role_id)\
                .where_in('ssh_id', ssh_id_list)\
                .delete()

            db.query().name('fortress_role').insert_all(insert_data)

            db.commit()

        return public.success("设置成功！")


