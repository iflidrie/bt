import json,time,re,os
import core.include.public as public
from core import session,app
from core.include.monitor_helpers import warning_obj, monitor_events, monitor_task_queue
from core.include import pyotp
# import modules.rbacModule.main as rbac
# import core.include.c_loader.PluginLoader as plugin_loader


rbac = public.import_via_loader('{}/modules/rbacModule/main.py'.format(public.get_panel_path()))
MsgModule = public.import_via_loader('{}/modules/msgModule/main.py'.format(public.get_panel_path())).main
AuthModule = public.import_via_loader('{}/modules/authModule/main.py'.format(public.get_panel_path())).main

class main:

    def __get_user_pwd(self,pwd,salt):
        '''
            @name 获取用户密码
            @author hwliang
            @param pwd <string> 加密后的密码
            @param salt <string> 盐
            @return string
        '''
        return public.md5(pwd + salt)

    def login(self,args):
        '''
            @name 用户登录
            @author hwliang
            @param username <string> md5加密后的用户名,算法: md5(username) [必传]
            @param password <string> md5加密后的密码,算法: md5(password + '_bt')  [必传]
            @param code <string> 验证码,在session.login_code == True时才传递此参数
            @return dict
        '''
        # 获取参数
        login_ip = public.get_client_ip()
        username = args.get('username/s','')
        password = args.get('password/xss','')

        # 检查错误次数
        skey = "login_err_{}".format(login_ip)
        code_key = 'login_code'
        error_num = public.get_error_num(skey)
        max_error_num = 5
        reset_msg = ''
        if error_num >= max_error_num:
            reset_msg = "您连续{}次登录失败，请稍后再试！".format(max_error_num)
            public.WriteLog('用户登录失败', '用户登录失败, 失败次数过多, 登录IP: {} 失败次数: {}'.format(login_ip, error_num))
            return public.return_data(False,reset_msg,0,'失败超过5次,次数过多！')
        else:
            if error_num > 0:
                reset_msg = '您还可以尝试{}次'.format(max_error_num - error_num)
        session['login_error'] = reset_msg

        if username == '' or password == '':
            public.WriteLog('用户登录失败', '用户登录失败, 用户名或密码为空, 登录IP: {} 失败次数: {}'.format(login_ip, error_num))
            return public.return_data(False,reset_msg,0,'用户名或密码不能为空!')

        # 验证码验证
        if session.get(code_key,None):
            login_code = args.get('code/xss','')
            if not login_code:
                public.WriteLog('用户登录失败', '用户登录失败, 验证码不能为空, 登录IP: {} 失败次数: {}'.format(login_ip, error_num))
                return public.return_data(False,'验证码不能为空!')

            if not public.checkCode(login_code):
                public.set_error_num(skey)
                public.WriteLog('用户登录失败', '用户登录失败, 验证码错误, 登录IP: {} 失败次数: {}'.format(login_ip, error_num))
                return public.return_data(False,reset_msg,0,'验证码错误!')

        if len(username) != 32 or len(password) != 32:
            session[code_key] = True
            # public.print_log('用户名或密码错误 {} {} {}'.format(username, login_ip, error_num), _level='error')
            public.WriteLog('用户登录失败', '用户登录失败，用户名或密码错误, 登录IP: {} 失败次数: {}'.format(login_ip, error_num))
            return public.return_data(False,reset_msg,0,'用户名或密码错误!')

        if not re.match("^\w+$",username):
            session[code_key] = True
            public.set_error_num(skey)
            # public.WriteLog('用户登录失败', '用户登录失败, 用户名格式不合法, 登录IP: {} 失败次数: {}'.format(login_ip, error_num))
            return public.return_data(False,reset_msg,0,'用户名格式不合法!')

        if not re.match("^\w+$",password):
            session[code_key] = True
            public.set_error_num(skey)
            # public.WriteLog('用户登录失败', '用户登录失败, 密码格式不合法, 登录IP: {} 失败次数: {}'.format(login_ip, error_num))
            return public.return_data(False,reset_msg,0,'密码格式不合法!')

        user_sql = public.M('users')

        # 获取用户信息
        user_info = user_sql.where("username_hash=?",username).find()


        if not user_info:
            session[code_key] = True
            public.set_error_num(skey)
            # public.print_log('用户名或密码错误1 {} {} {}'.format(username, login_ip, error_num), _level='error')
            public.WriteLog('用户登录失败', '用户登录失败，用户名或密码错误, 登录IP: {}  失败次数: {}'.format(login_ip, error_num))
            return public.return_data(False,reset_msg,0,'用户名或密码错误!')

        # # 获取登录地点
        # cur_login_place = None
        # ip_info = warning_obj.search_ip_info([
        #     user_info['last_login_ip'],
        #     login_ip,
        # ])
        # login_ip_info = ip_info.get(login_ip, None)
        # if login_ip_info:
        #     cur_login_place = login_ip_info['country'] + login_ip_info['province']
        # else:
        #     cur_login_place = '未知'

        # 验证密码
        pwd = self.__get_user_pwd(password,user_info['salt'])
        if pwd != user_info['password']:
            session[code_key] = True
            public.set_error_num(skey)
            self.__login_log('用户登录失败', '用户{}登录失败，用户名或密码错误, 失败次数: {}'.format(user_info['username'], error_num), login_ip, user_info['last_login_ip'])
            return public.return_data(False,reset_msg,0,'用户名或密码错误!')

        # 用户已禁用？
        if user_info['status'] == 0 and user_info['uid'] != 1:

            # public.WriteLog('用户登录失败', '禁用用户{}登录 登录失败，登录IP: {}，登录地点: {}  失败次数: {}'.format(user_info['username'], login_ip,
            #                                                                             cur_login_place, error_num))
            self.__login_log('用户登录失败', '禁用用户{}登录 登录失败，用户名或密码错误, 失败次数: {}'.format(user_info['username'], error_num), login_ip,
                             user_info['last_login_ip'])
            return public.return_data(False, '用户已被禁用!')

        # 处理密码过期时间
        login_time = int(time.time())
        expire_day = app.config.get('PASSWORD_EXPIRE',0)
        if expire_day > 0:
            expire_time = user_info['pwd_update_time'] + expire_day * 86400
            if login_time > expire_time:
                # public.WriteLog('用户登录失败', '用户{}登录失败，密码已过期, 登录IP: {}，登录地点: {}  失败次数: {}'.format(user_info['username'], login_ip, cur_login_place, error_num))
                self.__login_log('用户登录失败', '用户{}登录失败，密码已过期，用户名或密码错误, 失败次数: {}'.format(user_info['username'], error_num),
                                 login_ip,
                                 user_info['last_login_ip'])
                return public.return_data(False,'该帐户密码已过期，请联系管理员重置密码!')

        # 动态口令
        path = '{}/config/two_step_auth.json'.format(public.get_panel_path())
        two_auth_conf = {}
        if os.path.exists(path):
            two_auth_conf = json.loads(public.readFile(path))

        # 判断是否开启
        if two_auth_conf.get("open", False):
            # login_two_auth_num = session.get('login_two_auth_num', 0)
            # if login_two_auth_num >= 5:
            #     return public.return_data(False, '动态口令错误次数过多，请稍后再试！')
            # 存储用户信息
            cache_key = "TWO_STEP_AUTH_" + str(user_info['uid']) + "_" + public.GetRandomString(8)

            # def __inner_fun():
            #     # 获取登录地点
            #     cur_login_place = '未知'
            #     ip_info = warning_obj.search_ip_info([
            #         user_info['last_login_ip'],
            #         login_ip,
            #     ])

                # login_ip_info = ip_info.get(login_ip, None)
                # if login_ip_info:
                #     cur_login_place = login_ip_info['country'] + login_ip_info['province']

            __login_info = {
                'username': user_info['username'],
                'uid': user_info['uid'],
                'gid': user_info['gid'],
                'login': True,
                'last_login_time': login_time,
                'last_login_ip': login_ip,
                'request_token_head': public.GetRandomString(48),
                # 'cur_login_place': cur_login_place,
                'user_info': user_info,
            }
            login_info = json.dumps(__login_info)
            public.cache_set(cache_key, login_info, 180)

                # __login_info['cur_login_place'] = cur_login_place
            # monitor_task_queue.add_task_easy(__inner_fun)
            return public.return_data(True, {'two_auth': 1, 'user_cache_key': cache_key})

            ######################################################
            # vcode = args.get("vcode", None)
            # if vcode is None:
            #     return public.return_data(True, {'two_auth': 1})
            #
            # otp = pyotp.TOTP(two_auth_conf["secret_key"])
            # is_auth = otp.verify(vcode)
            # if not is_auth:
            #     if public.sync_date():
            #         is_auth = otp.verify(vcode)
            #     if not is_auth:
            #         session['login_two_auth_num'] += 1
            #         return public.return_data(False, '认证失败!')

        # 设置会话
        session[code_key] = False
        session['username'] = user_info['username']
        session['uid'] = user_info['uid']
        session['gid'] = user_info['gid']
        session['login'] = True
        session['last_login_time'] = login_time
        session['last_login_ip'] = login_ip
        session['request_token_head'] = public.GetRandomString(48)
        public.set_error_num(skey, True)
        # 更新登录时间
        user_sql.where("uid=?", user_info['uid']).update({'last_login_time': login_time, 'last_login_ip': login_ip})

        def __inner_fun():
            # 检测异地登录
            is_place_other, cur_login_place = self.__check_place_other(user_info['last_login_ip'], login_ip)
            if is_place_other:
                # 推送异地登录告警
                self.__notify_place_other(user_info['username'], login_ip, cur_login_place)

            public.WriteLog('用户登录成功', '用户{}登录成功，登录IP: {}，登录地点: {} '.format(user_info['username'], login_ip, cur_login_place))
        monitor_task_queue.add_task_easy(__inner_fun)

        # 触发用户登录成功事件
        public.event(monitor_events.UserLoginSuccess(user_info))

        return public.return_data(True, '登录成功!')

    def check_two_auth_login(self, args):
        '''
            @name 用户登录时进行动态口令验证
            @author lt
            @param vcode <string> 动态口令 [必传]
            @return dict
        '''
        vcode = args.get("vcode", None)
        user_cache_key = args.get("user_cache_key", None)
        login_time = int(time.time())
        login_ip = public.get_client_ip()
        __user_info = public.cache_get(user_cache_key)
        if not __user_info:
            return public.return_data(False, '登录信息不存在！')
        __user_info = json.loads(__user_info)

        login_two_auth_num = session.get('login_two_auth_num', 0)

        if login_two_auth_num >= 5:
            self.__login_log('用户登录失败', '用户{}登录失败，动态口令错误超过5次,'.format(__user_info['username']),login_ip,
                                 __user_info['last_login_ip'])
            return public.return_data(False, '动态口令错误超过5次,次数过多，请稍后再试！')

        path = '{}/config/two_step_auth.json'.format(public.get_panel_path())
        if not os.path.exists(path):  # 动态口令文件不存在 没有设置
            return public.return_data(True, True)

        two_auth_conf = json.loads(public.readFile(path))
        otp = pyotp.TOTP(two_auth_conf["secret_key"])
        is_auth = otp.verify(vcode)
        if not is_auth:
            session['login_two_auth_num'] = login_two_auth_num + 1
            self.__login_log('用户登录失败', '用户{}登录失败，动态口令错误, 错误次数: {}'.format(__user_info['username'], session['login_two_auth_num']),
                             login_ip, __user_info['last_login_ip'])

            return public.return_data(False, '动态口令错误!')

        # 设置会话
        session['username'] = __user_info['username']
        session['uid'] = __user_info['uid']
        session['gid'] = __user_info['gid']
        session['login'] = __user_info['login']
        session['last_login_time'] = __user_info['last_login_time']
        session['last_login_ip'] = __user_info['last_login_ip']
        session['request_token_head'] = __user_info['request_token_head']
        user_info = __user_info['user_info']
        # 更新登录时间
        public.M('users')\
            .where("uid=?", user_info['uid'])\
            .update({'last_login_time': login_time, 'last_login_ip': login_ip})

        def __inner_fun():
            # 检测异地登录
            is_place_other, cur_login_place = self.__check_place_other(user_info['last_login_ip'], login_ip)
            if is_place_other:
                # 推送异地登录告警
                self.__notify_place_other(user_info['username'], login_ip, cur_login_place)

            public.WriteLog('用户登录成功', '用户{}登录成功，登录IP: {}，登录地点: {} '.format(user_info['username'], login_ip, cur_login_place))
        monitor_task_queue.add_task_easy(__inner_fun)


        # 触发用户登录成功事件
        public.event(monitor_events.UserLoginSuccess(user_info))
        return public.return_data(True, '登录成功!')

    def loginout(self,args):
        '''
            @name 用户登出
            @author hwliang
            @return dict
        '''
        public.WriteLog('用户登录退出', '用户{}，已手动退出登录'.format(session.get('username', '--')))
        session['login'] = False
        session['username'] = None
        session['uid'] = None
        session['gid'] = None
        session['last_login_time'] = None
        session['last_login_ip'] = None
        session['request_token_head'] = None
        # session.clear()
        # session.clear()
        # public.print_log('【logout】 session >> {}'.format(session), _level='error')
        return public.return_data(True,'登出成功!')

    def modify_password(self,args):
        '''
            @name 修改当前用户密码(self)
            @param password<string> 新密码
            @return dict
        '''

        args.uid = session.get('uid',0)
        return rbac.main().set_user_pwd(args)

    def modify_nickname(self,args):
        '''
            @name 修改当前用户昵称(self)
            @param nickname<string> 新昵称
            @return dict
        '''
        args.uid = session.get('uid',0)
        return rbac.main().set_user_nickname(args)

    def get_user_info(self,args):
        '''
            @name 获取当前用户信息(self)
            @return dict
        '''
        uid = session.get('uid',0)
        data = public.M('users').where('uid=?',uid).find()
        if not data: return public.return_data(False,'用户不存在!')
        data['role_name'] = public.M('role').where('role_id=?',data['gid']).getField('name')
        data['admin_path'] = public.get_admin_path()
        del(data['password'])
        del(data['salt'])
        del(data['username_hash'])

        # DEMO
        if warning_obj.in_demo():
            data['last_login_ip'] = '****'

        bt_account_info = AuthModule().get_userinfo(public.to_dict_obj({}))

        data['bt_account_info'] = {
            'status': bt_account_info.get('status', False),
            # 'msg': bt_account_info.get('msg', ''),
            'username': bt_account_info['data'].get('username', '') if isinstance(bt_account_info.get('data', ''), dict) else '',
        }

        # 消息推送通道
        data['push_methods'] = warning_obj.get_push_methods()
        data['push_methods_v2'] = warning_obj.get_push_methods_v2()

        if uid == 1:
            menu_list = self.get_menu(True)
        else:
            menu_list = self.get_menu(data['gid'])

        data["menu_list"] = menu_list
        data['popup'] = warning_obj.db_easy('servers').count() < 2
        data['rule'] = warning_obj.db_easy('warning_configurations').count() < 1
        return public.return_data(True,data)

    @staticmethod
    def get_menu(role_id):
        '''
            @name 获取用户菜单
            @param role_id 用户角色
            @return []
        '''
        if role_id is True:  # 管理员
            sql = '''select node.name,node.title from
                bt_node as node
                where node.level=1 and node.pid=0
            '''
        else:
            sql = '''select node.name,node.title from
                bt_access as access,
                bt_node as node
                where
                access.role_id={role_id}
                and access.node_id=node.node_id
                and access.sid = 0
                and node.level=1
                and node.pid=0
            '''.format(role_id=role_id)
        db_obj = public.M('')
        node_list = db_obj.query(sql)
        menu_list = []
        if node_list:
            for value in node_list:
                menu_list.append({"name": value[0], "title": value[1]})
        return menu_list

    def __check_place_other(self, last_login_ip, cur_login_ip):
        '''
            @name 异地登录检测
            @author Zhj<2022-10-09>
            @param  last_login_ip<string>   上一次登录IP
            @param  cur_login_ip<string>    本次登录IP
            @return (bool, cur_login_ip_place)
        '''
        # 是否开启了异地登录提醒
        warn_place_other = public.get_config_value('config', 'warn_place_other', None)

        # 异地登录检测
        # 获取上次登录IP归属地与本次登录IP归属地
        ip_info = warning_obj.search_ip_info([
            last_login_ip,
            cur_login_ip,
        ])

        last_login_ip_info = ip_info.get(last_login_ip, None)
        login_ip_info = ip_info.get(cur_login_ip, None)

        if login_ip_info is None:
            return False, '未知'

        # 当前登录IP归属地
        cur_login_place = login_ip_info['country'] + login_ip_info['province']

        # 上一次登录地点未知
        # 未开启异地登录提醒
        # 如果上一次或者本次是从内网登录，不检测异地登录
        if last_login_ip_info is None\
            or warn_place_other is None\
            or int(warn_place_other) == 0\
            or public.is_local_ip(last_login_ip)\
            or public.is_local_ip(cur_login_ip):
            return False, cur_login_place

        # 检测异地登录
        return last_login_ip_info['country'] + last_login_ip_info['province'] != cur_login_place, cur_login_place

    def __notify_place_other(self, username, cur_login_ip, cur_login_place):
        '''
            @name 推送异地登录提醒
            @author Zhj<2022-10-09>
            @param  username<string>        用户名
            @param  cur_login_ip<string>    当前登录IP
            @param  cur_login_place<string> 当前登录地点
            @return bool
        '''
        args = public.dict_obj()
        args['title'] = '堡塔云监控异地登录提醒'
        args['msg'] = '''堡塔云监控异地登录提醒
> 主控IP: {}
> 登录账号: {}
> 登录时间: {}
> 登录地点: <font color="#FF0000">{}</font>
> 登录IP：{}

如果不是您本人操作，请尽快修改登录密码！'''.format(public.GetLocalIp(), username, time.strftime('%Y-%m-%d %X'), cur_login_place, cur_login_ip)

        msg_obj = MsgModule()

        # 获取异地登录提醒消息推送方式
        push_methods = public.get_config_value('config', 'warn_place_other_push_methods')

        # 自动根据消息通道推送告警
        if push_methods == '':
            res = msg_obj.auto_send(args)

            if not res or not isinstance(res, dict) or not res.get('status', False):
                return False
        else:
            push_res_list = []

            # 使用不同推送方式推送告警
            for push_method in push_methods.split(','):
                args_dup = public.dict_obj()
                args_dup['title'] = args['title']
                args_dup['msg'] = args['msg']
                args_dup['msg_type'] = push_method

                # 兼容不同推送方式的换行符
                if args_dup['msg_type'] == 'mail':
                    args_dup['msg'] = '<pre style="margin: 0;">{}</pre>'.format(args_dup['msg'])

                # 推送消息
                res = msg_obj.send(args_dup)

                if not res or not isinstance(res, dict) or not res.get('status', False):
                    push_res_list.append(False)
                    continue

                push_res_list.append(True)

            # 所有推送方式全部推送失败
            if len(list(filter(lambda i: i, push_res_list))) < 1:
                return False

        return True

    # 记录登录日志
    def __login_log(self, log_type, content, login_ip, last_login_ip):
        monitor_task_queue.add_task_easy(self.__login_log_help, log_type, content, login_ip, last_login_ip)

    # 记录登录日志(辅助函数)
    def __login_log_help(self, log_type, content, login_ip, last_login_ip):
        # 获取登录地点
        cur_login_place = '未知'
        ip_info = warning_obj.search_ip_info([last_login_ip, login_ip])
        login_ip_info = ip_info.get(login_ip, None)
        if login_ip_info:
            cur_login_place = login_ip_info['country'] + login_ip_info['province']
        public.WriteLog(str(log_type), '{}  登录IP: {}，登录地点: {}'.format(content, login_ip, cur_login_place))

