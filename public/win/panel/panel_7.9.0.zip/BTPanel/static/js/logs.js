var logs = {
	event: function() {
	  var that = this, name = bt.get_cookie('logs_type');
	  that.get_logs_info();
	  // 切换主菜单
	  $('#cutTab').unbind().on('click', '.tabs-item', function () {
		var index = $(this).index(), name = $(this).data('name')
		var parent = $(this).parent().parent().nextAll('.tab-view-box').children('.tab-con').eq(index)
		$(this).addClass('active').siblings().removeClass('active');
		parent.addClass('show w-full').removeClass('hide').siblings().removeClass('show w-full').addClass('hide');
		that[name].event();
		bt.set_cookie('logs_type',name)
	  })
	  $('[data-name="'+ (name || 'panelLogs') +'"]').trigger('click')
	},
	get_logs_info: function () {
		bt_tools.send({url: '/logs/panel/get_logs_info'}, function (rdata) {
			
		})
	},
    // 面板日志
	panelLogs:{
		crontabId: '',
		crontabName: '',
        /**
		 * @description 事件绑定
		 */
		event:function (){
			var that = this;
			$('.state-content').hide()
			$('#panelLogs').unbind('click').on('click','.tab-nav-border span',function(){
			  var index = $(this).index();
			  $(this).addClass('on').siblings().removeClass('on');
			  $(this).parent().next().find('.tab-block').eq(index).addClass('on').siblings().removeClass('on');
			  that.cutLogsTab(index)
			})
			$(window).unbind('resize').resize(function (){
				that.heightResize()
			})
			$('#panelLogs .tab-nav-border span').eq(0).trigger('click');
			$('.refresh_log').unbind('click').on('click',function (){
				that.getLogs(1)
			})
			$('.close_log').unbind('click').on('click',function (){
				that.delLogs()
			})
			$('#panelCrontab .Tab').on('click','.Item',function(){
				var id = $(this).data('id')
				$(this).addClass('active').siblings().removeClass('active')
				that.crontabId = id
				that.crontabName = $(this).prop('title')
				that.getCrontabLogs({id: id}, function (rdata) {
					$('#panelCrontab .crontab-log').html(rdata.msg)
					var div = $('#panelCrontab .crontab-log')
					div.height((window.innerHeight - 310) +'px')
					div.scrollTop(div.prop('scrollHeight'))
				})
			})
			//计划任务日志刷新
			$('.refreshCrontabLogs').click(function (){
				that.getCrontabLogs({id: that.crontabId})
			})
			//计划任务搜索
			$('#panelLogs .search-input').keyup(function (e) {
				var value = $(this).val()
				if(e.keyCode == 13) that.crontabLogs(value)
			})
			$('#panelLogs').on('click','.glyphicon-search',function(){
				var value = $('#panelLogs .search-input').val()
				that.crontabLogs(value)
			})

		},
		heightResize: function(){
			$('#errorLog .crontab-log').height((window.innerHeight - 310) +'px')
			$('#panelCrontab .crontab-log').height((window.innerHeight - 310) +'px')
			$('#panelCrontab .Tab').css('max-height',(window.innerHeight - 290) +'px')
			$('#panelCrontab').height((window.innerHeight - 240) +'px')
		},
		/**
		 * @description 切换日志菜单
		 * @param {number} index 索引
		 */
		cutLogsTab:function(index){
			switch (index) {
				case 0:
					this.getLogs(1)
					break;
				case 1:
					this.runLogs()
					break;
				case 2:
					this.errorLog()
					break;
				case 3:
					this.heightResize()
					this.crontabLogs('',function() {
						$('#panelCrontab .Tab .Item').eq(0).trigger('click');
					})
					break;
			}
		},
		/**
		 * @description 运行日志
		*/
		runLogs:function (p,limit,search){
			var that = this;
			search = search == undefined ? '':search;
			limit = limit || 20
			p = p || 1
			$('#panelRun').empty()
			bt_tools.table({
				el:'#panelRun',
				url:'/logs/panel/get_panel_log',
				param: {
					data : JSON.stringify({
						p: p,
						limit: limit,
						search: search
					})
				},
				load: '正在获取运行日志，请稍候...',
				height: $(window).height() - 330+'px',
				default: '列表为空', // 数据为空时的默认提示
				dataFilter: function (res) {
					if(!$('#panelRun .page').length){
						$('#panelRun .tootls_top').append('<div class="pull-right">\
								<div class="bt_search">\
									<input type="text" class="search_input" style="" placeholder="搜索日志" value="'+ search +'">\
									<span class="glyphicon glyphicon-search" aria-hidden="true"></span>\
								</div>\
							</div>')
						var html = '\
							<div class="tootls_group tools_bottom">\
								<div class="page">\
									<select class="page_select_number">\
										<option value="20" selected>20条/页</option>\
										<option value="50">50条/页</option>\
										<option value="100">100条/页</option>\
										<option value="500">500条/页</option>\
										<option value="1000">1000条/页</option>\
									</select>\
								</div>\
							</div>\
						';
						$('#panelRun .divtable').after(html)
						var select_num = $('#panelRun .tools_bottom .page_select_number'),search_input = $('#panelRun .search_input')
						select_num.val(limit)
						select_num.change(function () {
							that.runLogs(p, $(this).val())
						});
						$('#panelRun .page').prepend(logs.logAudit.renderPages(select_num.val(), p, res.length))
						$('#panelRun .page').find('.nextPage').click(function () {
							that.runLogs($(this).data('page'),select_num.val(),search_input.val())
						})
						search_input.keydown(function (e) {
							var value = $(this).val()
							if(e.keyCode == 13) that.runLogs(p,select_num.val(),value)
						})
						$('#panelRun .glyphicon-search').click(function () {
							that.runLogs(p,select_num.val(),$(this).prev().val())
						})
						$('#panelRun .search_input').focus(function () {
							layer.tips("特殊符号不支持搜索，xss类型的符号，如..,'", $(this), { tips: [1, '#bbb'],time: 0});
						})
						$('#panelRun .search_input').blur(function () {
							layer.closeAll('tips');
						})
					}
					return {data: res}
				},
				tootls: [
					{ // 按钮组
						type: 'group',
						positon: ['left', 'top'],
						list: [{
							title: '刷新日志',
							active: true,
							event: function (ev,_that) {
								that.runLogs()
							}
						}]
					}
				],
				column: [
					{ fid: 'date', title: "操作时间",width: 150},
					{ fid: 'ip', title: "IP:端口",width: 130 },
					{ title: "归属地",width: 130,template:function (row){
						return '<span>'+ (row.area?'' + row.area.info + '':'-') +'</span>';
					}},
					{ fid: 'method', title: "请求类型",width: 100 },
					{ fid: 'uri', title: "URI",width: 200 },
					{ fid: 'argv', title: "参数",width: 200},
					{ fid: 'user-agent', title: "浏览器标识",width: 300,fixed: true},
				]
			})
		},
		/**
		 * @description 计划任务日志
		*/
		crontabLogs:function (search,callback){
			var _that = this
			$('#panelCrontab .Tab').empty()
			bt_tools.send({url: '/data?action=getData&table=crontab',data: {search: search ? search : '',p: 1,limit: 9999}}, function (rdata) {
				var _html = ''
				$.each(rdata.data, function (index, item) {
					_html += '<div class="Item '+ (_that.crontabId && _that.crontabId === item.id ? 'active' : '' ) +'" title="'+ item.name + '" data-id="'+ item.id +'">'+ item.name +'</div>'
				})
				$('#panelCrontab .Tab').html(_html)
				if(callback) callback(rdata)
			})
		},
		/**
		* @description 获取计划任务执行日志
		* @param {object} param 参数对象
		* @param {function} callback 回调函数
		*/
		getCrontabLogs:function (param,callback){
			var loadT = bt.load('正在获取执行日志，请稍后...')
			$.post('/crontab?action=GetLogs', { id: param.id }, function (res) {
				loadT.close()
				if (callback) callback(res)
			})
		},
		/**
		 * @description 错误日志
		 */
		errorLog:function (){
			var that = this;
			bt_tools.send({
				url:'/files?action=GetFileBody'},{path:setup_path+"/panel/data/panelError.log"},function(res){
				log = res.data
				if(res.data == '') log = '当前没有日志'
				$('#errorLog').html('<div style="font-size: 0;">\
					<button type="button" title="刷新日志" class="btn btn-success btn-sm mr5 refreshRunLogs" ><span>刷新日志</span></button>\
					<pre class="crontab-log">'+ log +'</pre>\
				</div>');
				$('.refreshRunLogs').click(function (){
					that.errorLog()
				})
				var div = $('#errorLog .crontab-log')
				div.height((window.innerHeight - 310) +'px')
				div.scrollTop(div.prop('scrollHeight'))
			},'面板错误日志')
		},
		/**
		* 取回数据
		* @param {Int} page  分页号
		*/
		getLogs:function(page,search) {
			var that = this
			search = search == undefined ? '':search;
			bt_tools.send({url:'/data?action=getData&table=logs&tojs=getLogs&limit=20&p=' + page+"&search="+search}, function(data) {
				$('#operationLog').empty()
				bt_tools.table({
					el:'#operationLog',
					data: data.data,
                    height: $(window).height() - 330+'px',
                    default: '操作列表为空', // 数据为空时的默认提示
					tootls: [
						{ // 按钮组
							type: 'group',
							positon: ['left', 'top'],
							list: [{
								title: '刷新日志',
								active: true,
								event: function (ev,_that) {
									that.getLogs(1)
								}
							}, {
								title: '清空日志',
								event: function (ev,_that) {
									that.delLogs()
								}
							}]
						}
					],
					column:[
						{ fid: 'username', title: "用户",width: 100 },
						{ fid: 'type', title: "操作类型",width: 100 },
						{ fid: 'log', title: "详情"},
						{ fid: 'addtime', title: "操作时间",width: 150}
					],
					success: function () {
						if(!$('#operationLog .search_input').length){
							$('#operationLog .tootls_top').append('<div class="pull-right">\
								<div class="bt_search">\
									<input type="text" class="search_input" style="" placeholder="搜索日志" value="'+ search +'">\
									<span class="glyphicon glyphicon-search" aria-hidden="true"></span>\
								</div>\
							</div>')
							$('#operationLog .search_input').keydown(function (e) {
								var value = $(this).val()
								if(e.keyCode == 13) that.getLogs(1,value)
							})
							$('#operationLog .glyphicon-search').click(function () {
								var value = $('#operationLog .search_input').val()
								that.getLogs(1,value)
							})
						}
					}
				})
				$('.operationLog').html(data.page);
			},'获取面板操作日志')
		},
		//清理面板日志
		delLogs: function(){
			var that = this
			layer.confirm(lan.firewall.close_log_msg,{title:lan.firewall.close_log,closeBtn:2},function(){
				var loadT = layer.msg(lan.firewall.close_the,{icon:16});
				bt_tools.send('/ajax?action=delClose',function(rdata){
					layer.close(loadT);
					layer.msg(rdata.msg,{icon:rdata.status?1:2});
					that.getLogs(1);
				});
			});
		},
    },
    // 网站日志
	siteLogs:{
		siteName: '',
        event: function() {
			var that = this
			this.getSiteList('',function(rdata){
				$('#siteLogs .Tab .Item').eq(0).trigger('click');
			})
			that.heightResize()

			$(window).unbind('resize').resize(function (){
				that.heightResize()
			})

			$('#siteLogs .Tab').unbind().on('click','.Item',function(){
				that.siteName = $(this).data('name')
				$(this).addClass('active').siblings().removeClass('active')
				var index = $('#siteLogs .tab-nav-border span.on').index()
				$('#siteLogs .tab-nav-border span').eq(index).trigger('click');
			})

			$('#siteLogs').unbind().on('click','.tab-nav-border span',function(){
				var index = $(this).index();
				$(this).addClass('on').siblings().removeClass('on');
				$(this).parent().next().find('.tab-block').eq(index).addClass('on').siblings().removeClass('on');
				that.cutLogsTab(index)
			})
			$('#siteLogs .TabGroup .search-input').keyup(function (e) {
				var value = $(this).val()
				if(e.keyCode == 13) that.getSiteList(value)
			})
			$('#siteLogs .TabGroup').on('click','.glyphicon-search',function(){
				var value = $('#siteLogs .search-input').val()
				that.getSiteList(value)
			})
        },
		heightResize: function(){
			$('#siteLogs .Tab').css('max-height',(window.innerHeight - 290) +'px')
			$('#siteLogs').height((window.innerHeight - 200) +'px')
			$('#siteOnesite .divtable').css('max-height',($(window).height() - 350) +'px')
			$('#siteRun .crontab-log').height((window.innerHeight - 330) +'px')
			$('#siteError .crontab-log').height((window.innerHeight - 330) +'px')
		},
		/**
		 * @description 获取网站列表
		*/
		getSiteList:function(search,callback){
			var that = this
			$('#siteLogs .Tab').empty()
			bt_tools.send('/data?action=getData&table=sites',{limit: 999999,p:1,search: search ? search : '',type: -1},function(rdata){
				var _html = ''
				$.each(rdata.data,function(index,item){
					_html += '<div class="Item '+ (that.siteName && that.siteName === item.name ? 'active' : '' ) +'" title="'+ item.name+'（'+ item.ps +'）' +'" data-name="'+ item.name +'">'+ item.name+'（'+ item.ps +'）' +'</div>'
				})
				$('#siteLogs .Tab').html(_html)
				if(callback) callback(rdata)
			})
		},
		/**
		 * @description 切换日志菜单
		 * @param {number} index 索引
		*/
		cutLogsTab:function(index){
			var that = this;
			switch (index) {
				case 0://网站操作日志 
					that.getSiteOnesite();
					break;
				case 1://网站运行日志
					that.getSiteRun()
					break;
				case 2://网站错误日志
					that.getSiteError()
					break;
				case 3://WEB日志分析
					that.getSiteWeb()
					break;
			}
		},
		/**
		 * @description 获取网站操作日志
		*/
		getSiteOnesite: function(p) {
			var that = this;
			$('#siteOnesite').empty()
			bt_tools.table({
				el: '#siteOnesite',
				url: '/logs/panel/get_logs_bytype',
				param: { 
					data: JSON.stringify({
						stype: '网站管理',
						search: that.siteName,
						limit: 20,
						p: p || 1
				})
				},
				height: $(window).height() - 350,
				dataFilter: function(res) {
					$('#siteOnesite .tootls_bottom').remove()
					$('#siteOnesite').append('<div class="tootls_group tootls_bottom"><div class="pull-right"></div></div>')
					$('#siteOnesite .tootls_bottom .pull-right').append($(res.page).addClass('page'))
					$('#siteOnesite .tootls_bottom .pull-right .page').on('click','a',function(e){
						var num = $(this).prop('href').split('p=')[1]
						that.getSiteOnesite(num)
						e.preventDefault();
					})
					return {data: res.data}
				},
				tootls: [
					{ // 按钮组
					  type: 'group',
					  positon: ['left', 'top'],
					  list: [{
						title: '刷新日志',
						active: true,
						event: function (ev,_that) {
							_that.$refresh_table_list(true)
						}
					  }]
					}
				],
				column: [
					{fid: 'username', title: '用户', type: 'text', width: 150},
					{fid: 'type', title: '操作类型', type: 'text', width: 150},
					{fid: 'log', title: '日志', type: 'text', width: 300},
					{fid: 'addtime', title: '操作时间', type: 'text', width: 150},
				]
			})
		},
		/**
		 * @description 网站运行日志
		*/
		getSiteRun: function(search,p) {
			var that = this;
			search = search || ''
			bt_tools.send({url: '/logs/site/get_site_logs'}, { data: JSON.stringify({siteName: that.siteName,search: search})}, function (rdata) {
				$('#siteRun').html('<div style="margin-bottom: 5px; position: relative; height:30px;line-height:30px;display: flex;justify-content: space-between;"><button type="button" title="刷新日志" class="btn btn-success btn-sm mr15 refreshSiteSunLogs" >\
					<span>刷新日志</span></button>\
					<div class="bt-search">\
						<input type="text" class="search-input" placeholder="搜索日志" value="'+ search +'">\
						<span class="glyphicon glyphicon-search" aria-hidden="true"></span>\
					</div>\
				</div>\
				<div style="font-size: 0;">\
					<pre class="crontab-log">'+ (rdata.length ? rdata.join('\n') : '当前没有日志.')+'</pre>\
				</div>');

				$('#siteRun .search-input').keyup(function (e) {
					var value = $(this).val()
					if(e.keyCode == 13) that.getSiteRun(value)
				})
				$('#siteRun').on('click','.glyphicon-search',function(){
					var value = $('#siteRun .search-input').val()
					that.getSiteRun(value)
				})

				$('.refreshSiteSunLogs').click(function (){
					that.getSiteRun()
				})
				var div = $('#siteRun .crontab-log')
				div.height((window.innerHeight - 330) +'px')
				div.scrollTop(div.prop('scrollHeight'))
			},'获取网站运行日志')
		},
		/**
		 * @description 网站错误日志
		*/
		getSiteError: function() {
			var that = this;
			bt.site.get_site_error_logs(that.siteName, function (rdata) {
				$('#siteError').html('<div style="font-size: 0;">\
					<button type="button" title="刷新日志" class="btn btn-success btn-sm mr5 refreshSiteErrorLogs" ><span>刷新日志</span></button>\
					<pre class="crontab-log">'+ rdata.msg +'</pre>\
				</div>');

				$('.refreshSiteErrorLogs').click(function (){
					that.getSiteError()
				})

				var div = $('#siteError .crontab-log')
				div.height((window.innerHeight - 330) +'px')
				div.scrollTop(div.prop('scrollHeight'))
			})
		},
		/**
		 * @description WEB日志分析
		*/
		getSiteWeb: function() {
			var that = this,robj = $('#siteWeb');
			var progress = '';  //扫描进度
			$.post('/site?action=get_scan_files&siteName=' + that.siteName, function (fileList) {
				//1.扫描按钮/日志列表
				var logOption = '';
				if(fileList.data.length > 0){
					$.each(fileList.data,function(index,item){
						logOption+='<option value="'+item+'">'+item+'</option>'
					})
				}
				var analyes_log_btn = (logOption ? '<select class="bt-input-text mr5" name="scan_log_file">'+logOption+'</select>' : '')+'<button type="button" title="日志扫描" class="btn btn-success analyes_log btn-sm mr5"><span>日志扫描</span></button><button type="button" title="刷新日志" class="btn btn-default refreshSiteWebLogs btn-sm mr5"><span>刷新日志</span></button>'

				//2.功能介绍
				var analyse_help = '<ul class="help-info-text c7">\
				<li>日志安全分析：扫描网站(.log)日志中含有攻击类型的请求(类型包含：<em style="color:red">xss,sql,scan,php</em>)</li>\
				<li>分析的日志数据包含已拦截的请求</li>\
				<li>默认展示上一次扫描数据(如果没有请点击日志扫描）</li>\
				<li>如日志文件过大，扫描可能等待时间较长，请耐心等待</li>\
				</ul>'

				robj.html(analyes_log_btn+'<div class="analyse_log_table"></div>'+analyse_help)

				$('.refreshSiteWebLogs').click(function (){
					that.getSiteWeb()
				})
				render_analyse_list()  //加载模板
				//首次获取进度
				detect_progress('init',function(){
					var loadT = bt.load('正在获取日志分析数据，请稍候...');
					$.post('/site?action=get_scan_result&siteName=' + that.siteName, function (rdata) {
						loadT.close();
						render_analyse_list(rdata);
					})
					//事件
					robj.on('click','.analyes_log',function(){
						var _file = $('[name=scan_log_file]').val();
						if(!_file) return layer.msg('没有日志文件',{icon:2})

						bt.confirm({
							title:'扫描网站日志',
							msg:'建议在服务器负载较低时进行安全分析，本次将对【'+_file+'】文件进行扫描，可能等待时间较长，是否继续？'
						}, function(index){
							layer.close(index)
							$('.analyes_log').attr('disabled',true)
							// 开启扫描并且持续获取进度
							$.post('/site?action=start_scan_logs&siteName=' + that.siteName+'&path='+_file, function (rdata) {
								if(rdata.status){
									open_scan_dialog();
								}else{
									layer.close(progress);
									layer.msg(rdata.msg, { icon: 2, time: 0, shade: 0.3, shadeClose: true });
								}
							})
						})
					})
				})
			})

			// 渲染分析日志列表
			function render_analyse_list(rdata){
				var analyse_list = '<div class="divtable" style="margin-top: 10px;"><table class="table table-hover">\
				<thead><tr><th>文件名</th><th width="142">扫描时间</th><th>总条数</th><th>耗时</th><th>XSS</th><th>SQL</th><th>扫描</th><th>PHP攻击</th><th>合计</th></tr></thead>\
				<tbody class="analyse_body">'
				if(rdata && rdata.length > 0){   //检测是否有扫描数据
					$.each(rdata,function(index,item){
						var numTotal = item.xss+item.sql+item.scan+item.php
						analyse_list +='<tr name="'+item.filename+'">\
							<td title="'+item.filepath+'"><span class="size_ellipsis" style="width:90px">'+item.filename+'</span></td>\
							<td>'+bt.format_data(item.start)+'</td>\
							<td>'+item.total+'</td>\
							<td>'+item.time.toString().substring(0,4)+'秒</td>\
							<td class="onChangeLogDatail" '+(item.xss>0?'style="color:red"':'')+' name="xss">'+item.xss+'</td>\
							<td class="onChangeLogDatail" '+(item.sql>0?'style="color:red"':'')+' name="sql">'+item.sql+'</td>\
							<td class="onChangeLogDatail" '+(item.scan>0?'style="color:red"':'')+' name="scan">'+item.scan+'</td>\
							<td class="onChangeLogDatail" '+(item.php>0?'style="color:red"':'')+' name="php">'+item.php+'</td>\
							<td>'+numTotal+'</td>\
						</tr>'
					})
				}else{
					analyse_list+='<tr><td colspan="9" style="text-align: center;">没有扫描数据</td></tr>'
				}

				analyse_list += '</tbody></table></div>'
				$('.analyse_log_table').html(analyse_list)
				$('.onChangeLogDatail').css('cursor','pointer').attr('title','点击查看详情')
				//查看详情
				$('.onChangeLogDatail').on('click',function(){
					get_analysis_data_datail($(this).attr('name'),$(this).parents('tr').attr('name'))
				})
				$('.analyes_log').attr('disabled',false)
			}
			// 扫描进度界面
			function open_scan_dialog(){
				progress = layer.open({
					type: 1,
					closeBtn: 1,
					title: '日志扫描',
					shade: 0,
					maxmin:true,
					area: "500px",
					skin:"scan_logs_view",
					content: '<div class="pro_style">\
						<pre style="margin-bottom: 0px;height:300px;border-radius:0px; text-align: left;background-color: #000;color: #fff;white-space: pre-wrap;" id="scan_result_progress"></pre>\
						</div>',
					success:function(){
						detect_progress();
					},
					full:function(){
						$('#scan_result_progress').height($('.scan_logs_view .layui-layer-content').height()-50)
					},
					restore:function(){
						$('#scan_result_progress').height('279px');
					},
					cancel:function(index){
						layer.confirm('正在对日志扫描中，此操作将会停止日志扫描，是否继续？', {
							title: '停止扫描',
							icon: 0
							}, function (indexs) {
							$.post('/site?action=stop_scan_logs&siteName=' + that.siteName, function (rdata) {
								if(rdata.status){
									layer.close(indexs)
								}
								layer.msg(rdata.msg,{icon:rdata.status?1:2})
							})
							});
						return false;
					}
				})
			}
			// 扫描进度
			function detect_progress(type,callback){
				$.post('/site?action=speed_log&siteName=' + that.siteName, function (res) {
					var pro = res.code
					if(type == 'init' && pro != 1){
						// 是否有扫描进度界面
						if($('#scan_result_progress').length>0){
							detect_progress()
						}else{
							open_scan_dialog()
						}
						$('.analyes_log').attr('disabled',true)
					}else if(type == 'init' && pro == 1){
						callback()
					}else{
						if(pro !== 1){
							$('#scan_result_progress').html(res.msg).scrollTop(100000000000)
							setTimeout(function () {
								detect_progress();
							}, 1000);
						}else{
							layer.msg('扫描完成',{icon:1,timeout:4000})
							layer.close(progress);
							get_analysis_data();
						}
					}
				})
			}
			// 获取扫描结果
			function get_analysis_data(){
				var loadTGA = bt.load('正在获取日志分析数据，请稍候...');
				$.post('/site?action=get_scan_result&siteName=' + that.siteName, function (rdata) {
					loadTGA.close();
					render_analyse_list(rdata)
				})
			}
			// 获取扫描结果详情日志
			function get_analysis_data_datail(name,filename){
				layer.open({
					type: 1,
					closeBtn: 1,
					shadeClose: false,
					maxmin:true,
					title: '【文件：'+filename+'】【类型：'+name+'】日志详情',
					area: '650px',
					skin:'scan_type_details',
					content:'<pre id="analysis_pre" style="background-color: #333;color: #fff;height:545px;margin: 0;white-space: pre-wrap;border-radius: 0;"></pre>',
					success:function(){
						var loadTGD = bt.load('正在获取日志详情数据，请稍候...');
						$.post('/site?action=get_detailed&siteName=' + that.siteName+'&filename='+filename+'&type='+name+'', function (logs) {
							loadTGD.close();
							$('#analysis_pre').html(logs.msg)
						})
					},
					full:function(){
						$('#analysis_pre').height($('.scan_type_details .layui-layer-content').height()-50)
					},
					restore:function(){
						$('#analysis_pre').height('524px');
					}
				})
			}
		},
		check_log_time: function () {
            bt.confirm({
                msg: "是否立即校对IIS日志时间，校对后日志统一使用北京时间记录？",
                title: '提示'
            }, function () {
                var loading = bt.load()
                bt.send("check_log_time", 'site/check_log_time', {}, function (rdata) {
                    loading.close();
                    if (rdata.status) {
                        site.reload();
                    }
                    bt.msg(rdata);
                })
            })
        },
    },
	// 日志审计
	logAudit:{
		plugin_name: 'win_event',
		selectIndex: 0,
		p:1,
		timeRange: {
            start: 0,
            end: 0,
            value: ''
        },
		/**
		 * @description 事件绑定
		 */
		event:function (){
			var that = this;
			$('.state-content').hide()
			var ltd = parseInt(bt.get_cookie('ltd_end')  || -1)
      if(ltd < 0){
				return $('#logAudit .daily-thumbnail').show().prevAll().hide()
			}
			$('#logAudit').height($(window).height() - 180).css({'overflow': 'hidden'})
			$('#logAudit .tab-con').css({'overflow': 'visible'})
			// 切换日志审计菜单事件
			$('#logAudit').unbind('click').on('click', '.tab-nav-border span', function () {
			  var index = $(this).index();
			  $(this).addClass('on').siblings().removeClass('on');
			  $(this).parent().next().find('.tab-block').eq(index).addClass('on').siblings().removeClass('on');
			  var html = '';
				switch (index) {
					case 0:
						html = '<div id="bt_app_table"></div>';
						break;
					case 1:
						html = '<div id="bt_safe_table"></div>';
						break;
					case 2:
						html = '<div id="bt_system_table"></div>';
						break;
					case 3:
						html = '<div id="bt_setup_table"></div>';
						break;
					case 4:
						html = '<div id="bt_fe_table"></div>';
						break;
				}
				$(this).parent().next().find('.tab-block').eq(index).empty().append(html);
                that.render_tools();
                that.render_table();
			})
			$('#logAudit .tab-nav-border span:eq(0)').click();
		},
		/**
         * @description 生成工具栏
         * @return void
         */
		 render_tools: function () {
            this.render_tools_top();
            this.render_tools_bottom();
        },
        /**
         * @description 生成工具栏顶部及事件
         * @return void
         */
        render_tools_top: function () {
            var html = '\
                <div class="tootls_group tools_top">\
                    <div class="tools_left"></div>\
                </div>\
            ';
            var index = this.get_menu_index();
            $('#logAudit .tab-block').eq(index).prepend(html);
            this.render_tools_top_level();
            // this.render_tools_top_time();
            this.render_tools_top_event();
        },
		/**
         * @description 生成工具栏底部及事件
         * @return void
         */
		 render_tools_bottom: function () {
			var that = this
            var html = '\
                <div class="tootls_group tools_bottom">\
                    <div class="page">\
                        <select class="page_select_number">\
                            <option value="20" selected>20条/页</option>\
                            <option value="50">50条/页</option>\
                            <option value="100">100条/页</option>\
                            <option value="500">500条/页</option>\
                            <option value="1000">1000条/页</option>\
                        </select>\
                    </div>\
                </div>\
            ';
            var index = this.get_menu_index();
            $('#logAudit .tab-block').eq(index).append(html);
            $('.tools_bottom .page_select_number').change(function () {
                that.render_table();
            });
        },
        /**
         * @description 生成查询等级复选框及事件
         * @return void
         */
        render_tools_top_level: function () {
			var that = this
            var index = this.get_menu_index();
            if (index == 1) {
				$('.tools_top .tools_left').append('<button type="button" title="刷新日志" class="btn btn-success btn-sm mr15 refreshLogAudit" ><span>刷新日志</span></button>');
			}else{
				var html = '\
					<button type="button" title="刷新日志" class="btn btn-success btn-sm mr15 refreshLogAudit" ><span>刷新日志</span></button>\
					<div class="tools_item">\
						<span class="tools_label">级别：</span>\
						<div class="checkbox_group">\
							<div class="checkbox_item checkbox_default">\
								<input type="checkbox" class="checkbox-text" value="2" />\
								<span>错误</span>\
							</div>\
							<div class="checkbox_item checkbox_default">\
								<input type="checkbox" class="checkbox-text" value="3" />\
								<span>警告</span>\
							</div>\
							<div class="checkbox_item checkbox_default">\
								<input type="checkbox" class="checkbox-text" value="1" />\
								<span>关键</span>\
							</div>\
							<div class="checkbox_item checkbox_default">\
								<input type="checkbox" class="checkbox-text" value="4" />\
								<span>信息</span>\
							</div>\
						</div>\
					</div>\
				';
				$('.tools_top .tools_left').append(html);
				$('.checkbox_item span').click(function () {
					$(this).prev().click();
				});
				$('.checkbox_default input').click(function () {
					that.render_table();
				});
			}
			$('.refreshLogAudit').click(function(){
				var index = $('#logAudit .tab-nav-border span.on').index();
				$('#logAudit .tab-nav-border span').eq(index).click();
			})
        },
        /**
         * @description 生成查询时间选择器及事件
         * @return void
         */
        render_tools_top_time: function () {
            var _this = this;
            var html = '\
                <div class="tools_item">\
                    <div class="bt_select_updown site_class_type">\
                        <div class="bt_select_value">\
                            <span class="bt_select_content">操作时间：近两天</span>\
                            <span class="glyphicon glyphicon-triangle-bottom ml5"></span>\
                        </div>\
                        <ul class="bt_select_list">\
                            <li class="item" data-type="1">近2小时</li>\
                            <li class="item" data-type="2">近12小时</li>\
                            <li class="item" data-type="3">近24小时</li>\
                            <li class="item active" data-type="0">近两天</li>\
                            <li class="item" data-type="4">近7天</li>\
                            <li class="item" data-type="5">近30天</li>\
                            <li class="divider" role="separator"></li>\
                            <li class="item custom">自定义范围</li>\
                        </ul>\
                    </div>\
                </div>\
            ';
            $('.tools_top .tools_left').append(html);
            $('.bt_select_value').click(function (e) {
                var $this = $(this);
                $this.next().show();
                $(document).one('click', function () {
                    $this.next().hide();
                });
                e.stopPropagation();
            });
            $('.bt_select_list').on('click', '.item', function () {
                var $this = $(this);
                var text = $this.text();
                _this.selectIndex = $this.siblings('.active').index();
                $this.addClass('active').siblings('.active').removeClass('active');
                $this.parent().prev().find('.bt_select_content').text('操作时间：' + text);
                if ($this.hasClass('custom')) {
                    layer.open({
                        type: 1,
                        area: "380px",
                        title: '自定义范围',
                        closeBtn: 2,
                        shift: 5,
                        shadeClose: false,
                        btn: ['提交', '取消'],
                        content: '\
                            <div class="bt-form pd20">\
                                <div class="line">\
                                    <span class="tname" style="width: auto;">时间范围</span>\
                                    <div class="info-r" style="margin-left: 68px;">\
                                        <input type="text" class="bt-input-text mr5" id="time_range" style="width: 100%;" placeholder="开始时间 至 结束时间">\
                                    </div>\
                                </div>\
                            </div>\
                        ',
                        success: function () {
                            var today = new Date();
                            var todayStr = bt.format_data(today.getTime() / 1000, 'yyyy-MM-dd hh:mm:ss');
                            var value = '' + todayStr + ' 至 ' + todayStr + '';
                            _this.timeRange.value = value;
                            _this.timeRange.start = Math.floor(today.getTime() / 1000);
                            _this.timeRange.end = Math.floor(today.getTime() / 1000);
                            laydate.render({
                                elem: '#time_range',
                                type: 'datetime',
                                range: '至',
                                format: 'yyyy-MM-dd HH:mm:ss',
                                value: value,
                                done: function (value, startDate, endDate) {
                                    _this.timeRange.value = value;
                                    _this.timeRange.start = _this.get_time_stamp(startDate);
                                    _this.timeRange.end = _this.get_time_stamp(endDate);
                                }
                            });
                        },
                        yes: function (layIndex) {
                            var li = '<li class="item other" data-type="6">' + _this.timeRange.value + '</li>';
                            layer.close(layIndex);
                            $this.siblings('.other').remove();
                            $this.siblings('.divider').before(li);
                            $('.bt_select_list .other').click();
                        },
                        btn2: function () {
                            this.cancel();
                        },
                        cancel: function () {
                            var text = $this.parent().find('.item').eq(_this.selectIndex).text();
                            $this.removeClass('active');
                            $this.parent().find('.item').eq(_this.selectIndex).addClass('active');
                            $this.parent().prev().find('.bt_select_content').text('操作时间：' + text);
                        }
                    });
                } else {
                    if (!$this.hasClass('other')) $this.siblings('.other').remove();
                    _this.render_table();
                }
            });
        },
        /**
         * @description 获取日期对象的时间戳
         * @param {object} data 日期对象
         * @return 时间戳
         */
        get_time_stamp: function (data) {
            var date = new Date(data.year, data.month - 1, data.date, data.hours, data.minutes, data.seconds);
            return Math.floor(date.getTime() / 1000);
        },
        /**
         * @description 生成事件id查询框及事件
         * @return void
         */
        render_tools_top_event: function () {
			var that = this
            var html = '\
                <div class="bt_search">\
                    <input type="text" class="search_input" placeholder="搜所有字段" />\
                    <span class="glyphicon glyphicon-search search_btn" aria-hidden="true"></span>\
                </div>\
            ';
			console.log()
			var _el = that.set_el(that.get_menu_index())
            $('#'+ _el +' .tools_top').append(html);
			$('#'+ _el +' .search_input').val('')
            $('#'+ _el +' .search_input').keydown(function (e) {
                if (e.keyCode == 13) {
                    $('#'+ _el +' .search_btn').click();
                }
            });
            $('#'+ _el +' .search_btn').click(function () {
				that.p = 1
                that.render_table();
            });
        },
        get_menu_index: function () {
            return $('#logAudit .tab-nav-border span.on').index();
        },
        /**
         * @description 生成表格
         * @return void
         */
        render_table: function () {
            var _this = this;
            var data = {};
            this.set_search_data(data);
            this.get_event_logs(data, function (res) {
                var _el = _this.get_table_id();
                $(_el).empty();
                var column = _this.get_table_column();
                var table = bt_tools.table({
                    el: _el,
                    data: res,
                    height: $(window).height() - 330+'px',
                    default: '列表为空',
                    column: column
                });
                _this.table_dblclick(table);
				$(_el).next().find('.page_select_number').prevAll().remove()
				$(_el).next().find('.page').prepend(_this.renderPages($(_el).next().find('.page_select_number').val(),_this.p,res.length))
				$(_el).next().find('.nextPage').click(function () {
					_this.p = $(this).data('page')
					_this.render_table();
				})
            });
        },
		/**
		 * @description 渲染日志分页
		 * @param pages
		 * @param p
		 * @param num
		 * @returns {string}
		 */
		renderPages:function(pages,p,num){
			return (p > 1 ?'<a class="nextPage" data-page="1">首页</a>':'') + (p !== 1?'<a class="nextPage" data-page="'+ (p-1) +'">上一页</a>':'') + (pages <= num ? '<a class="nextPage" data-page="'+ (p+1) +'">下一页</a>':'')+'<span class="Pcount">第 '+ p +' 页</span>';
		},
        /**
         * @description 通过tabs获取相对应的表格id
         * @return 表格id
         */
        get_table_id: function () {
            var index = this.get_menu_index(),_id = ''
			switch (index) {
				case 0:
					_id = '#bt_app_table';
					break;
				case 1:
					_id = '#bt_safe_table';
					break;
				case 2:
					_id = '#bt_system_table';
					break;
				case 3:
					_id = '#bt_setup_table';
					break;
				case 4:
					_id = '#bt_fe_table';
					break;
			}
            return _id;
        },
        /**
         * @description 获取表格渲染列
         * @return 表格渲染列
         */
        get_table_column: function () {
			var that = this
            var event = this.get_menu_index()
            var column = [
                { fid: 'Event ID', title: '事件ID', align: 'right' },
                { fid: 'Task', title: '任务类别' },
                { fid: 'Source', title: '来源' },
                { fid: 'Date', title: '操作时间' },
                {
                    title: '操作',
                    type: 'group',
                    width: 100,
                    align: 'right',
                    group: [
                        {
                            title: '详细',
                            event: function (row, index, ev, key, _that) {
                                that.open_windows_details(row);
                            }
                        }
                    ]
                }
            ];
            if (event == 1) {
                column.unshift({
                    fid: 'Keyword',
                    title: '关键字',
                    template: function (row, index) {
                        if (row.Keyword == '审核成功') return '<span>审核成功</span>';
                        if (row.Keyword == '审核失败') return '<span class="bt_danger">审核失败</span>';
                        return '';
                    }
                });
            } else {
                column.unshift({
                    fid: 'Level',
                    title: '级别',
                    template: function (row, index) {
                        if (row.Level == 1) return '<span>关键</span>';
                        if (row.Level == 2) return '<span class="bt_danger">错误</span>';
                        if (row.Level == 3) return '<span class="bt_warning">警告</span>';
                        if (row.Level == 4) return '<span>信息</span>';
                        return '';
                    }
                });
            }
            return column;
        },
		//当前id
		set_el:  function (index) {
            // event
			var _el = ''
			switch (index) {
				case 0:
					_el = 'logApplication';
					break;
				case 1:
					_el = 'logSecurity';
					break;
				case 2:
					_el = 'logSystem';
					break;
				case 3:
					_el = 'logSetup';
					break;
				case 4:
					_el = 'logForwardedEvents';
					break;
			}
			return _el
		},
        /**
         * @description 填充查询数据
         * @param {object} data 传入数据
         * @return void
         */
        set_search_data: function (data) {
            // event
			var event = ''
			switch (this.get_menu_index()) {
				case 0:
					event = 'Application';
					break;
				case 1:
					event = 'Security';
					break;
				case 2:
					event = 'System';
					break;
				case 3:
					event = 'Setup';
					break;
				case 4:
					event = 'ForwardedEvents';
					break;
			}
            data.event = event;
            // 级别
            var level = [];
            $('#log' + event + ' .checkbox_default').each(function () {
                var input = $(this).find('input');
                if (input.is(':checked')) {
                    level.push(input.val());
                }
            });
            data.level = level.join(',');
            // 事件ID
            var eventId = $('#log'+ event +' .search_input').val();
            data.search = eventId;
            // limit
            var limit = $('#log'+ event +' .page_select_number').val();
            data.count = limit;
			data.p = this.p;
            // 时间
            // var time = this.get_time_data();
            // data.start = time.start;
            // data.end = time.end;
        },
        /**
         * @description 获取开始、结束时间戳
         * @return 时间对象包含开始、结束时间戳
         */
         get_time_data: function () {
            var today = new Date();
            var start = 0;
            var end = Math.floor(today.getTime() / 1000);
            var type = parseInt($('.bt_select_list .active').attr('data-type'));
            if (type === 1) {
                start = end - 2 * 3600;
            } else if (type === 2) {
                start = end - 12 * 3600;
            } else if (type === 3) {
                start = end - 24 * 3600;
            } else if (type === 4) {
                start = end - 7 * 24 * 3600;
            } else if (type === 5) {
                start = end - 30 * 24 * 3600;
            } else if (type === 6) {
                start = this.timeRange.start;
                end = this.timeRange.end;
            } else {
                start = '';
                end = '';
            }
            return { start: start, end: end };
        },
        /**
         * @description 表格单行双击事件
         * @param {object} table 生成表格实例对象
         * @return void
         */
        table_dblclick: function (table) {
            var _this = this;
            $('.bt_table tbody tr').dblclick(function () {
                var index = $(this).index();
                var data = table.data[index];
                _this.open_windows_details(data);
            });
        },
        /**
         * @description 打开详情弹框
         * @param {object} data 事件详情数据
         * @return void
         */
        open_windows_details: function (data) {
            var levelStr = this.get_level_str(data['Level']);
            layer.open({
                type: 1,
                closeBtn: 2,
                title: '事件属性',
                area: ["600px", "600px"],
                shadeClose: false,
                content: '\
                    <div class="bt-property-setting pd15">\
                        <div class="tab-nav">\
                            <span class="on">常规</span>\
                        </div>\
                        <div class="tab-con">\
                            <div class="event_info">\
                                <div class="desc">\
                                    <textarea rows="14" disabled>' + data['Description'] + '</textarea>\
                                </div>\
                                <div class="rows">\
                                    <div class="cols">\
                                        <div class="name">日志名称:</div>\
                                        <div class="value" title="应用程序">应用程序</div>\
                                    </div>\
                                </div>\
                                <div class="rows">\
                                    <div class="cols">\
                                        <div class="name">来源:</div>\
                                        <div class="value" title="' + data['Source'] + '">' + data['Source'] + '</div>\
                                    </div>\
                                    <div class="cols">\
                                        <div class="name">记录时间:</div>\
                                        <div class="value" title="' + data['Date'] + '">' + data['Date'] + '</div>\
                                    </div>\
                                </div>\
                                <div class="rows">\
                                    <div class="cols">\
                                        <div class="name">事件ID:</div>\
                                        <div class="value" title="' + data['Event ID'] + '">' + data['Event ID'] + '</div>\
                                    </div>\
                                    <div class="cols">\
                                        <div class="name">任务类别:</div>\
                                        <div class="value" title="' + data['Task'] + '">' + data['Task'] + '</div>\
                                    </div>\
                                </div>\
                                <div class="rows">\
                                    <div class="cols">\
                                        <div class="name">级别:</div>\
                                        <div class="value" title="' + levelStr + '">' + levelStr + '</div>\
                                    </div>\
                                    <div class="cols">\
                                        <div class="name">关键字:</div>\
                                        <div class="value" title="' + data['Keyword'] + '">' + data['Keyword'] + '</div>\
                                    </div>\
                                </div>\
                                <div class="rows">\
                                    <div class="cols">\
                                        <div class="name">用户:</div>\
                                        <div class="value" title="' + data['User'] + '">' + data['User'] + '</div>\
                                    </div>\
                                    <div class="cols">\
                                        <div class="name">计算机:</div>\
                                        <div class="value" title="' + data['Computer'] + '">' + data['Computer'] + '</div>\
                                    </div>\
                                </div>\
                                <div class="rows">\
                                    <div class="cols">\
                                        <div class="name">操作代码:</div>\
                                        <div class="value" title="' + data['Opcode'] + '">' + data['Opcode'] + '</div>\
                                    </div>\
                                </div>\
                            </div>\
                        </div>\
                    </div>\
                '
            });
        },
        /**
         * @description 获取等级名称
         * @param {number} level 等级
         * @return 等级名称
         */
        get_level_str: function (level) {
            if (level == 1) return '关键';
            if (level == 2) return '错误';
            if (level == 3) return '警告';
            if (level == 4) return '信息';
            return '';
        },
        /**
         * @description 获取日志
         * @param {object} data 传入数据
         * @param {function} callback 回调
         * @return void
         */
        get_event_logs: function (data, callback) {
            this.request({
                tips: '正在获取日志，请稍候...',
                method: 'get_event_logs',
                data: {data: JSON.stringify(data)},
                success: function (res) {
                    if (callback) callback(res);
                }
            });
        },
        /**
         * 请求
         */
        request: function (obj) {
            var loadT = '';
            if (obj.load == undefined) obj.load = 0;
            if (obj.url == undefined) {
                if (obj.plugin_name === undefined && this.plugin_name !== undefined) obj.plugin_name = this.plugin_name;
                if (!obj.plugin_name || !obj.method) {
                    layer.msg('插件类名称，或插件方法名称缺失!', {
                        icon: 2
                    });
                    return false;
                }
            }
            if (obj.load === 0 || obj.tips != '') {
                loadT = layer.msg(obj.tips, {
                    icon: 16,
                    time: 0,
                    shade: 0.3
                });
            } else if (obj.load === 1 || (obj.tips == undefined && obj.load == undefined)) {
                loadT = layer.load();
            }
            $.ajax({
                type: 'POST',
                url: obj.url != undefined ? obj.url : ('/safe/syslog/' + obj.method),
                data: obj.data || {},
                timeout: obj.timeout || 99999999,
                complete: function (res) {
                    if (obj.load === 0 || obj.load === 1) layer.close(loadT);
                },
                success: function (rdata) {
                    if (obj.check) {
                        obj.success(rdata);
                        return false
                    }
                    if (rdata.status === false) {
                        layer.msg(rdata.msg, { icon: 2 });
                        return false;
                    }
                    obj.success(rdata);
                }
            });
        }
	},
	// 远程桌面登录日志
	loginLogs:{
        event: function() {
			var that = this;
			var type = $('.cutLoginLogsType button.btn-success').data('type')
			this.loginLogsTable({p:1, type: type? type : 0,filter: $('.cutLoginLogsType button.btn-success').parent().prev().find('[name=filter]').prop("checked")});
			 // 切换登录日志类型
			$('#loginLogsContent').unbind('click').on('click','.cutLoginLogsType button',function(){
				var type = $(this).data('type');
				$(this).addClass('btn-success').removeClass('btn-default').siblings().addClass('btn-default').removeClass('btn-success');
				$('#loginLogsContent>div:eq('+ type +')').show().siblings().hide();
				that.loginLogsTable({p:1,type: Number(type),filter: $(this).parent().prev().find('[name=filter]').prop("checked")});
			})
        },
		/**
		 * @description 登录日志
		 */
		loginLogsTable:function(param){
			if(!param) param = { p:1, type:0 };
			var logsList = [['All','日志','get_ssh_list'],['Success','成功日志','get_ssh_success'],['Error','失败日志','get_ssh_error']];
			var filter = param['filter'] === undefined ? false : param['filter']
			var type = logsList[param.type][0] , tips = logsList[param.type][1];
			var that = this;
			$('#login'+ type +'Logs').empty();
			var arry = ['全部','登录成功','登录失败'];
			var html = $('<div class="btn-group mr10 cutLoginLogsType"></div>');
			$.each(arry,function (i,v){
			  html.append('<button type="button" class="btn btn-sm btn-'+ (i === param.type ?'success':'default') +'" data-type="'+ i +'">'+ v +'</button>')
			})
			return bt_tools.table({
			  el: '#login'+ type +'Logs',
			  url: '/safe/syslog/' + logsList[param.type][2],
			  load: '获取SSH登录' + tips,
			  default: 'SSH登录'+ tips +'为空', // 数据为空时的默认提示
			  autoHeight: true,
			  dataVerify:false,
			  tootls: [
				{ // 按钮组
				  type: 'group',
				  positon: ['left', 'top'],
				  list: [{
					title: '刷新日志',
					active: true,
					event: function (ev,that) {
					  that.$refresh_table_list(true)
					}
				  }]
				},
				{ // 搜索内容
				  type: 'search',
				  positon: ['right', 'top'],
				  placeholder: '请输入登录IP/用户名',
				  searchParam: 'search', //搜索请求字段，默认为 search
				},{ //分页显示
				  type: 'page',
				  number: 20
				}
			  ],
			  dataFilter: function (data) {
				if(typeof data.status === "boolean" && !data.status){
				  $('#loginLogsContent').hide().next().show();
				  return { data: [] }
				}
				return {data:data}
			  },
			  beforeRequest: function (data) {
				  data['filter_invalid'] = filter ? 1 : 0
				if(typeof data.data === "string"){
				  delete data.data
				  return {data: JSON.stringify(data)}
				}
				return {data: JSON.stringify(data)}
			  },
			  column: [
				{title: 'IP地址:端口',fid: 'address',width:'150px', template:function (row){
					return '<span>'+ (row.address ? row.address : '--') + ':' + (row.port !== '0' && row.port !== '-' ? row.port : '--' ) + '</span>';
				  }},
				// {title: '登录端口',fid: 'port'},
				{title: '归属地',template:function (row){
					return '<span>'+ (row.area?'' + row.area.info + '':'-') +'</span>';
				  }},
				{title: '用户',fid: 'user'},
				{title: '状态', template: function (item) {
					var status = Boolean(item.status);
					return '<span style="color:'+ (status?'#20a53a;':'red') +'">'+ (status ? '登录成功' : '登录失败') +'</span>';
				  }},
				{title: '操作时间', fid: 'time', width:150}
			  ],
			  success:function (config){
				  $(config.config.el + ' .tootls_top .pull-right .btn-group').remove()
				  $('.bt_search').prev().remove()
				  var num = config.config.el.indexOf('All') > -1 ? 0 : config.config.el.indexOf('Success') > -1 ? 1 : 2
				  $(config.config.el + ' .tootls_top .pull-right').prepend('<div class="btn-group mr10" style="position: relative;vertical-align: middle;">\
					  <label class="mr20 cursor-pointer" for="filteruser_'+ num +'" style="font-weight:normal;display: inline-flex;width: 90px;justify-content: space-between;vertical-align: middle;">\
						  <input type="checkbox" class="filteruser cursor-pointer" style="margin:0;" id="filteruser_'+ num +'" name="filter">过滤无效用户\
					  </label>\
				  </div>')
				  $('.bt_search').before(html)
				  $(config.config.el+' [name=filter]').prop("checked",filter)
				  $(config.config.el+' [name=filter]').change(function () {
					  that.loginLogsTable({p:1,type: num,filter: $(config.config.el+' [name=filter]').prop('checked')});
				  })
				$('#login'+ type +'Page').html(logs.renderLogsPages(20,param.p,config.data.length))
			  }
			})
		},
    },
	//软件日志
	softwareLogs: {
		username: '',
		/**
		 * @description 事件绑定
		 */
		 event:function (){
			var that = this;
			$('#softwareLogs').unbind('click').on('click','.tab-nav-border span',function(){
			  var index = $(this).index();
			  $(this).addClass('on').siblings().removeClass('on');
			  $(this).parent().next().find('.tab-block').eq(index).addClass('on').siblings().removeClass('on');
			  that.cutLogsTab(index)
			})
			$('#softwareLogs .tab-nav-border span').eq(0).trigger('click');

			$('#softwareLogs .TabGroup .search-input').keyup(function (e) {
				var value = $(this).val()
				if(e.keyCode == 13) that.getFtpList(value)
			})
			$('#softwareLogs .TabGroup').on('click','.glyphicon-search',function(){
				var value = $('#softwareLogs .search-input').val()
				that.getFtpList(value)
			})
			$('#softwareLogs .Content .search-input').keyup(function (e) {
				var value = $(this).val()
				if(e.keyCode == 13) that.getFtpLogs(value)
			})
			$('#softwareLogs .Content').on('click','.glyphicon-search',function(){
				var value = $('#softwareLogs .Content .search-input').val()
				that.getFtpLogs(value)
			})
			$('#softwareLogs .Tab').unbind().on('click','.Item',function(){
				that.username = $(this).data('username')
				$(this).addClass('active').siblings().removeClass('active')
				that.getFtpLogs()
			})
			$('.refreshFtpLogs').click(function (){
				that.getFtpLogs()
			})
			$('.refreshMysqlSlow').click(function (){
				that.getMysqlSlowLogs()
			})
			$('.refreshMysqlError').click(function (){
				that.getMysqlErrorLogs()
			})
			$(window).unbind('resize').resize(function (){
				that.heightResize()
			})
			that.heightResize()
		},
		heightResize: function(){
			$('#softwareFtp .Tab').css('max-height',(window.innerHeight - 300) +'px')
			$('#softwareLogs').height((window.innerHeight - 200) +'px')
			$('#softwareLogs .crontab-log').height((window.innerHeight - 330) +'px')
		},
		/**
		 * @description 切换日志菜单
		 * @param {number} index 索引
		 */
		cutLogsTab:function(index){
			var that = this;
			switch (index) {
				case 0://FTP日志
					that.getFtpList('',function(rdata){
						$('#softwareLogs .Tab .Item').eq(0).trigger('click');
					})
					break;
				case 1://MySql慢日志
					that.getMysqlSlowLogs()
					break;
				case 2://MySql错误日志
					that.getMysqlErrorLogs()
					break;
			}
		},
		/**
		 * @description MySql慢日志
		*/
		getMysqlSlowLogs:function(){
			bt_tools.send({url: '/logs/panel/get_slow_logs'}, function (rdata) {
				$('#softwareMysqlSlow .crontab-log').html(rdata.length ? rdata.join('\n') : '当前没有日志.')
				var div = $('#softwareMysqlSlow .crontab-log')
				div.height((window.innerHeight - 330) +'px')
				div.scrollTop(div.prop('scrollHeight'))
			},'获取MySql慢日志')
		},
		/**
		 * @description MySql错误日志
		*/
		getMysqlErrorLogs:function(){
			var loadT = bt.load('正在获取MySql慢日志,请稍候...')
			$.post('/database?action=GetErrorLog', function (rdata) {
				loadT.close()
				$('#softwareMysqlError .crontab-log').html(rdata ? rdata : '当前没有日志.')
				var div = $('#softwareMysqlError .crontab-log')
				div.height((window.innerHeight - 330) +'px')
				div.scrollTop(div.prop('scrollHeight'))
			}) 
		},
		/**
		 * @description 获取FTP日志
		 * @param {string} search 搜索内容
		 */
		getFtpLogs:function(search){
			var that = this;
			search = search || ''
			$('#softwareFtp .Content .search-input').val(search)
			bt_tools.send({url: '/logs/panel/get_ftp_logs'}, { data: JSON.stringify({username: that.username,search: search})}, function (rdata) {
				$('#softwareFtp .crontab-log').html(rdata.length ? bt.reverseEscape(rdata.join('\n')) : '当前没有日志.')
				var div = $('#softwareFtp .crontab-log')
				div.height((window.innerHeight - 330) +'px')
				div.scrollTop(div.prop('scrollHeight'))
			},'获取FTP日志')
		},
		/**
		 * @description 获取网站列表
		*/
		getFtpList:function(search,callback){
			var that = this
			$('#softwareFtp .Tab').empty()
			bt_tools.send('/data?action=getData&table=ftps',{limit: 999999,p:1,search: search ? search : ''},function(rdata){
				var _html = search === '' || search.indexOf('全部') > -1 ? '<div class="Item '+ (that.username === '' ? 'active' : '' ) +'" title="全部' +'" data-username="">全部</div>' : ''
				$.each(rdata.data,function(index,item){
					_html += '<div class="Item '+ (that.username && that.username === item.name ? 'active' : '' ) +'" title="'+ item.name+'（'+ item.ps +'）' +'" data-username="'+ item.name +'">'+ item.name+'（'+ item.ps +'）' +'</div>'
				})
				$('#softwareFtp .Tab').html(_html)
				if(callback) callback(rdata)
			})
		},
	},
	/**
	 * @description 渲染日志分页
	 * @param pages
	 * @param p
	 * @param num
	 * @returns {string}
	*/
	renderLogsPages:function(pages,p,num){
		return (num >= pages?'<a class="nextPage" data-page="1">首页</a>':'') + (p !== 1?'<a class="nextPage" data-page="'+ (p-1) +'">上一页</a>':'') + (pages <= num?'<a class="nextPage" data-page="'+ (p+1) +'">下一页</a>':'')+'<span class="Pcount">第 '+ p +' 页</span>';
	}
}
logs.event();

//面板操作日志分页切换
function getLogs(page) {
	logs.panelLogs.getLogs(page,$('#operationLog .search_input').val())
}