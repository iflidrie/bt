import os,sys,re,json,shutil,psutil,time
from projectModel.base import projectBase
import public
try:
    from BTPanel import cache
except:
    pass

class main(projectBase):
    _panel_path = public.get_panel_path()

    #获取网站列表
    def get_site_list(self,get):
        return public.M('sites').field('name').select()

    #读取日志
    def get_log(self,get):
        if not 'domain' in get and not 'path' in get:return public.returnMsg(True,'请输入域名或者日志地址')
        if 'domain' in get:
            path = '/www/wwwlogs/' + get.domain.strip() + '.log'
            if not os.path.exists(get.path):return public.returnMsg(True,'日志文件不存在')
        elif 'path' in get:
            path = get.path.strip()
            if not os.path.exists(path):return public.returnMsg(True,'日志文件不存在')
        else:
            return public.returnMsg(True,'日志文件不存在')

        start_time=time.time()

        f =open(path,'r')
        for i in f:
            i=i.strip()
           
        return time.time()-start_time


