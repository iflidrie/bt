#coding: utf-8
#-------------------------------------------------------------------
# 宝塔Linux面板
#-------------------------------------------------------------------
# Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
#-------------------------------------------------------------------
# Author: hwliang <hwl@bt.cn>
#-------------------------------------------------------------------

# 系统日志
#------------------------------

import os,re,json,datetime,time,sys
from safeModel.base import safeBase
import public


class main(safeBase):

    _level_keys = {'关键':1,'错误':2,'信息':4,'警告':3}

    def __init__(self):
        pass


    #*********************************************** start ssh收费模块  ******************************************************


    def get_event_logs(self,get):
        """
        @获取事件查看器日志
        @event Application|Security|System|Setup|ForwardedEvents
        @level{
            2:错误
            4:信息
        }
        """


        level = ''
        search = ''
        p ,count = 1,20
        event = 'Application'

        if 'event' in get: event = get.event
        if 'search' in get: search = get.search
        if 'level' in get: level = get.level

        if 'count' in get: count = int(get['count'])
        if 'p' in get: p = int(get['p'])

        log_list = []
        min,max = (p -1) * count,  p * count

        idx = 0
        pre_time = time.time() + 86400
        while len(log_list) < count:


            slist = self.get_search_logs(limit=max,eventid = None,start=self.time_tu_utc(0),end = self.time_tu_utc(pre_time),level=level,event = event,search = search)
            if len(slist) <= 0:
                break

            for log in slist:
                if len(log_list) >= count:
                    break

                if idx >= min and idx < max:
                    log_list.append(log)
                idx += 1
                pre_time = public.to_date(times = log['Date'])
        return log_list


    def get_ssh_start(self):
        """
        @name 获取ssh登录日志开始时间
        @param
        """
        d_file = '{}/data/ssh/start_day.log'.format(public.get_panel_path())
        try:

            if os.path.exists(d_file):
                return int(public.readFile(d_file))
            return self.get_curr_day() - 180  * 86400
        except:
            return self.get_curr_day() - 180 * 86400

    def get_ssh_list(self,get):
        """
        @获取SSH登录
        @param get:
            count :数量
        """
        search = ''
        if 'search' in get: search = get.search

        filter_invalid = 0
        if 'filter_invalid' in get:
            filter_invalid = get.filter_invalid

        p ,count = 1,20
        if 'count' in get: count = int(get['count'])
        if 'p' in get: p = int(get['p'])


        log_list = []
        min,max = (p -1) * count,  p * count

        idx = 0
        pre_time = self.get_curr_day()
        while len(log_list) < count:
            if pre_time < self.get_ssh_start(): break

            slist = self.get_ssh_log_byday(pre_time,['4625','4624'],search,filter_invalid)
            for log in slist:
                if len(log_list) >= count:
                    break
                if idx >= min and idx < max:
                    log_list.append(log)
                idx += 1
            pre_time -= 86400
        return public.return_area(log_list,'address')


    def get_ssh_error(self,get):
        """
        @获取SSH错误次数
         @param get:
            count :数量
        """
        search = ''
        if 'search' in get: search = get.search

        filter_invalid = 0
        if 'filter_invalid' in get:
            filter_invalid = get.filter_invalid

        p ,count = 1,20
        if 'count' in get: count = int(get['count'])
        if 'p' in get: p = int(get['p'])


        log_list = []
        min,max = (p -1) * count,  p * count

        idx = 0
        pre_time = self.get_curr_day()
        while len(log_list) < count:
            if pre_time < self.get_ssh_start(): break

            slist = self.get_ssh_log_byday(pre_time,['4625'],search,filter_invalid)

            for log in slist:
                if len(log_list) >= count:
                    break
                if idx >= min and idx < max:
                    log_list.append(log)
                idx += 1

            pre_time -= 86400

        return public.return_area(log_list,'address')

    def get_ssh_success(self,get):
        """
        @获取SSH登录成功次数
        @param get:
            count :数量
        """

        search = ''
        if 'search' in get: search = get.search

        filter_invalid = 0
        if 'filter_invalid' in get:
            filter_invalid = get.filter_invalid

        p ,count = 1,20
        if 'count' in get: count = int(get['count'])
        if 'p' in get: p = int(get['p'])


        log_list = []
        min,max = (p -1) * count,  p * count

        idx = 0
        pre_time = self.get_curr_day()
        while len(log_list) < count:
            if pre_time < self.get_ssh_start(): break

            slist = self.get_ssh_log_byday(pre_time,['4624'],search,filter_invalid)

            for log in slist:
                if len(log_list) >= count:
                    break
                if idx >= min and idx < max:
                    log_list.append(log)
                idx += 1
            pre_time -= 86400

        return public.return_area(log_list,'address')



    def get_ssh_log_line(self,log,events = [] ,filter_invalid = 0):
        """
        @name 格式化登录日志
        """

        data = {}

        slist = log['info'].strip().split('\n')

        keys = ['Account Name','Date','Event ID','Source Port','源端口','\\t帐户名称','帐户名','Account Name']
        for key in keys:

            sTmp = re.findall('({}):\s*(.*)'.format(key),log['info'])
            if not sTmp: continue
            for s_val in sTmp:
                skye = s_val[0].replace('\t','').strip()
                sval = s_val[1].strip()

                if skye == 'Date':
                    sval = public.format_date(times = self.utc_to_time(sval))
                elif skye == 'Level':
                    sval = self._level_keys[sval]
                log[skye] = sval


        if str(log['Event ID']).strip() in events:

            data['port'] = ''
            if 'Source Port' in log: data['port'] += log['Source Port']
            if '源端口' in log: data['port'] += log['源端口']

            data['time'] = log['Date']

            data['user'] = ''
            if 'Account Name' in log:  data['user'] += log['Account Name']
            if '帐户名称' in log:  data['user'] += log['帐户名称']
            if '帐户名' in log:  data['user'] += log['帐户名']

            data['user'] = public.xsssec(data['user'].replace('\t','').strip())
            data['address'] = ''
            address =  self.get_logs_ip(log['info'])
            if address: data['address'] = address

            if filter_invalid:
                users = ['SYSTEM','www','mysql','redis']
                if data['user'] in users:  return False
                if data['user'].find("DWM-") >=0 : return False
                if not data['user']: return False
                if not public.check_ip(data['address']): return False

            data['event'] = log['Event ID'].strip()

            data['status'] = 0
            data['info'] = public.xsssec(log['info'])
            if data['event'] == '4624':
                data['status'] = 1

        return data


    def get_ssh_log_byday(self,stime,events,search,filter_invalid):
        """
        @获取ssh登录日志
        @stime: 时间戳
        """

        spath = '{}/data/ssh'.format(public.get_panel_path())
        if not os.path.exists(spath): os.makedirs(spath)

        sfile = '{}/{}.log'.format(spath,stime)

        if stime == self.get_curr_day():
            sfile = '{}/ssh.log'.format(spath)
            if os.path.exists(sfile):
                public.rmdir(sfile)

            shell = 'wevtutil qe Security "/q:*[System [(Level != -2) and (TimeCreated[@SystemTime >= \'{}\' ]) and (EventID=4624 or EventID=4625)]]" /rd:true /f:text'.format(self.time_tu_utc(stime))

            res = public.ExecShell(shell)

            public.writeFile(sfile,res[0])

        if not os.path.exists(sfile):
            return []

        conf = public.readFile(sfile)
        sdata = re.sub("Event\[\d*\]:",'_win_',conf)
        slist = sdata.split('_win_')

        result = []
        for x in slist:
            if not x: continue

            data = self.get_ssh_log_line({'info':x},events,filter_invalid)
            if not data: continue

            if search:
                if x.find(search) >=0:
                    result.append(data)
            else:
                result.append(data)

        return result




    def get_curr_day(self):
        """
        获取当天时间戳
        """
        return int(time.mktime(time.strptime(time.strftime("%Y-%m-%d", time.localtime(int(time.time()))), '%Y-%m-%d')))

    def cache_ssh_log(self,get):
        """
        @name 缓存登录日志
        """

        spath = '{}/data/ssh'.format(public.get_panel_path())
        if not os.path.exists(spath): os.makedirs(spath)

        day_time = self.get_curr_day()

        d_file = '{}/start_day.log'.format(spath)
        if not os.path.exists(d_file):
            public.writeFile(d_file,str(day_time - 365 * 2 * 86400))


        limit = 0
        for idx in range(1, 365 * 2):

            stime = day_time - idx * 86400
            start_time = self.time_tu_utc(stime)
            end_time = self.time_tu_utc(stime + 86400)

            sfile = '{}/{}.log'.format(spath,stime)
            if os.path.exists(sfile): continue

            search_time = '(TimeCreated[@SystemTime >= \'{}\' and @SystemTime <= \'{}\'])'.format(start_time,end_time)
            shell = 'wevtutil qe Security "/q:*[System [(Level != -2) and {} and (EventID=4624 or EventID=4625)]]" /rd:true /f:text > {} 2>&1'.format(search_time,sfile)
            os.system(shell)

            if not os.path.exists(sfile):
                public.writeFile(sfile,'')
            time.sleep(0.2)
            limit += 1
            if limit>20: break

        return True





    def get_search_logs(self,limit,eventid,start ,end,level,event = 'Security',search = None,query = 'ssh'):
        """
        @获取时间查看器日志
        @param limit: 查询条数
        @param search: 查询内容
        @param eventid: 事件ID
        @param start: 开始时间
        @param end: 结束时间
        @param level: 日志等级
        @param event: 事件类型
        """
        result = []

        event_str = '(EventID != -2)'
        if eventid:
            event_str = ''
            for x in eventid.split(','):
                event_str += 'EventID={} or '.format(x)
            event_str = '({})'.format(event_str[:-3])

        level_str = '(Level != -2)'
        if level:
            level_str = ''
            for x in level.split(','):
                level_str += 'Level={} or '.format(x)
            level_str = '({})'.format(level_str[:-3])

        search_time = '(TimeCreated[@SystemTime >= \'{}\' and @SystemTime <= \'{}\'])'.format(start,end)

        shell = 'wevtutil qe {} "/q:*[System [{} and {} and {}]]" /rd:true /f:text /c:{}'.format(event,level_str,search_time,event_str,limit)

        sdata = public.ExecShell(shell,None,None,None,True)[0]
        sdata = re.sub("Event\[\d*\]:",'_win_',sdata)
        slist = sdata.split('_win_')

        for x in slist:
            if not x: continue

            x = public.xsssec(x)
            data = {}
            data['info'] = x
            try:
                src_data = x.split('Description:')
                data['Description'] = src_data[1].strip()
            except :pass

            tmps = src_data[0].strip().split('\n')
            for tmp in tmps:
                sTmp = re.search('(.*?):\s*(.*)',tmp)
                if not sTmp: continue

                skye = sTmp.groups()[0].strip()
                sval = sTmp.groups()[1].strip()

                if skye == 'Date':
                    sval = public.format_date(times = self.utc_to_time(sval))
                elif skye == 'Level':
                    sval = self._level_keys[sval]
                data[skye] = sval
            if search:
                if data['info'].find(search) == -1 : continue

            result.append(data)
        return result


    def get_logs_ip(self,info):

        tmp = re.search('(((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?))',info)
        if tmp:
            return tmp.groups()[0]
        return False
    #时间戳转UTC
    def time_tu_utc(self,times):
        if times > 0:
            times = int(times) - 8 * 3600

        return time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime(times))


    # UTC时间转时间戳
    def utc_to_time(self, utc_string):
        try:
            utc_string = utc_string.split('.')[0]
            utc_date = datetime.datetime.strptime(utc_string, "%Y-%m-%dT%H:%M:%S")
            # 按北京时间返回
            return int(time.mktime(utc_date.timetuple()))
        except:
            return int(time.time() + 86400 * 7)